<?php
/**
 * KDMS Pro — Global Constants
 *
 * International Edition: KDMS used to hardcode an 8-city Bangladesh divisions
 * array independently inside every donors/recipients/hospitals add/edit/index
 * page. This file is the single source of truth for the 30-country / ~70-city
 * network now that the platform is a global hybrid system, plus the other
 * fixed vocabularies (blood groups, HLA types, specializations) that used to
 * be duplicated per-page too.
 */

declare(strict_types=1);

/**
 * country => [cities...]
 * Matches the countries/cities used to seed hospitals in sql/06_seed.sql.
 * Keep this list and the seed generator (gen_intl.py) in sync if more
 * countries/cities are added later.
 */
const KDMS_CITIES_BY_COUNTRY = [
    'Bangladesh'            => ['Dhaka','Chattogram','Sylhet','Rajshahi','Khulna','Gazipur','Mymensingh','Barishal'],
    'United States'         => ['New York','Los Angeles','Chicago','Houston','Boston'],
    'United Kingdom'        => ['London','Manchester','Birmingham','Edinburgh'],
    'Russia'                => ['Moscow','Saint Petersburg','Novosibirsk'],
    'China'                 => ['Beijing','Shanghai','Guangzhou'],
    'Germany'               => ['Berlin','Munich','Hamburg'],
    'Australia'             => ['Sydney','Melbourne','Brisbane'],
    'India'                 => ['New Delhi','Mumbai','Bengaluru'],
    'Japan'                 => ['Tokyo','Osaka'],
    'South Korea'           => ['Seoul','Busan'],
    'France'                => ['Paris','Lyon'],
    'Italy'                 => ['Rome','Milan'],
    'Spain'                 => ['Madrid','Barcelona'],
    'Canada'                => ['Toronto','Vancouver'],
    'Brazil'                => ['Sao Paulo','Rio de Janeiro'],
    'South Africa'          => ['Johannesburg','Cape Town'],
    'United Arab Emirates'  => ['Dubai','Abu Dhabi'],
    'Saudi Arabia'          => ['Riyadh','Jeddah'],
    'Singapore'             => ['Singapore'],
    'Malaysia'              => ['Kuala Lumpur'],
    'Thailand'              => ['Bangkok'],
    'Turkey'                => ['Istanbul','Ankara'],
    'Egypt'                 => ['Cairo'],
    'Nigeria'               => ['Lagos'],
    'Netherlands'           => ['Amsterdam'],
    'Sweden'                => ['Stockholm'],
    'Pakistan'              => ['Karachi','Lahore'],
    'Indonesia'             => ['Jakarta'],
    'Mexico'                => ['Mexico City'],
    'Switzerland'           => ['Zurich'],
];

const KDMS_COUNTRIES = [
    'Bangladesh','United States','United Kingdom','Russia','China','Germany','Australia','India',
    'Japan','South Korea','France','Italy','Spain','Canada','Brazil','South Africa',
    'United Arab Emirates','Saudi Arabia','Singapore','Malaysia','Thailand','Turkey','Egypt',
    'Nigeria','Netherlands','Sweden','Pakistan','Indonesia','Mexico','Switzerland',
];

/** Flat, de-duplicated, sorted list of every city across all countries — handy for a single search dropdown. */
function kdms_all_cities(): array
{
    $all = [];
    foreach (KDMS_CITIES_BY_COUNTRY as $cities) {
        $all = array_merge($all, $cities);
    }
    $all = array_unique($all);
    sort($all);
    return $all;
}

/** Cities for one country, or [] if unknown. */
function kdms_cities_for(string $country): array
{
    return KDMS_CITIES_BY_COUNTRY[$country] ?? [];
}

/**
 * Render a <select> of countries. $selected pre-selects a value.
 */
function kdms_country_select(string $name, ?string $selected = null, string $extraAttrs = '', bool $required = true): string
{
    $html = '<select name="' . htmlspecialchars($name, ENT_QUOTES) . '" id="' . htmlspecialchars($name, ENT_QUOTES) . '" ' . $extraAttrs . ($required ? ' required' : '') . '>';
    $html .= '<option value="">Select Country…</option>';
    foreach (KDMS_COUNTRIES as $country) {
        $sel = ($selected === $country) ? ' selected' : '';
        $html .= '<option value="' . htmlspecialchars($country, ENT_QUOTES) . '"' . $sel . '>' . htmlspecialchars($country, ENT_QUOTES) . '</option>';
    }
    $html .= '</select>';
    return $html;
}

/**
 * Render a <select> of cities for a given country (used on first paint;
 * assets/js/app.js re-populates this client-side via kdmsCityCascade() when
 * the country dropdown changes, using the same KDMS_CITIES_BY_COUNTRY data
 * exposed to JS — see kdms_cities_json()).
 */
function kdms_city_select(string $name, ?string $country, ?string $selected = null, string $extraAttrs = '', bool $required = true): string
{
    $cities = $country ? kdms_cities_for($country) : [];
    $html = '<select name="' . htmlspecialchars($name, ENT_QUOTES) . '" id="' . htmlspecialchars($name, ENT_QUOTES) . '" ' . $extraAttrs . ($required ? ' required' : '') . '>';
    $html .= '<option value="">' . ($cities ? 'Select City…' : 'Select country first…') . '</option>';
    foreach ($cities as $city) {
        $sel = ($selected === $city) ? ' selected' : '';
        $html .= '<option value="' . htmlspecialchars($city, ENT_QUOTES) . '"' . $sel . '>' . htmlspecialchars($city, ENT_QUOTES) . '</option>';
    }
    $html .= '</select>';
    return $html;
}

/** JSON payload for the client-side country -> city cascade script. */
function kdms_cities_json(): string
{
    return htmlspecialchars(json_encode(KDMS_CITIES_BY_COUNTRY, JSON_UNESCAPED_UNICODE) ?: '{}', ENT_QUOTES);
}

// ─── Other shared vocabularies (previously duplicated per-page) ─────────────
const KDMS_BLOOD_GROUPS    = ['A+','A-','B+','B-','O+','O-','AB+','AB-'];
const KDMS_HLA_TYPES       = ['DR1','DR3','DR4','DR7','DR11','DR13','DR15'];
const KDMS_SPECIALIZATIONS = ['Nephrology','Transplant Surgery','Urology','Immunology','Anesthesiology','Pathology','Other'];

/** ISO currency code most associated with a country (for transplant cost display). */
const KDMS_CURRENCY_BY_COUNTRY = [
    'Bangladesh' => 'BDT', 'United States' => 'USD', 'United Kingdom' => 'GBP', 'Russia' => 'RUB',
    'China' => 'CNY', 'Germany' => 'EUR', 'Australia' => 'AUD', 'India' => 'INR', 'Japan' => 'JPY',
    'South Korea' => 'KRW', 'France' => 'EUR', 'Italy' => 'EUR', 'Spain' => 'EUR', 'Canada' => 'CAD',
    'Brazil' => 'BRL', 'South Africa' => 'ZAR', 'United Arab Emirates' => 'AED', 'Saudi Arabia' => 'SAR',
    'Singapore' => 'SGD', 'Malaysia' => 'MYR', 'Thailand' => 'THB', 'Turkey' => 'TRY', 'Egypt' => 'EGP',
    'Nigeria' => 'NGN', 'Netherlands' => 'EUR', 'Sweden' => 'SEK', 'Pakistan' => 'PKR', 'Indonesia' => 'IDR',
    'Mexico' => 'MXN', 'Switzerland' => 'CHF',
];

function kdms_currency_for(string $country): string
{
    return KDMS_CURRENCY_BY_COUNTRY[$country] ?? 'USD';
}
