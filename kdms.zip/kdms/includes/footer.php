<?php
/**
 * KDMS Pro — Global Footer
 * Closes main wrapper, includes CDN libraries and app JS
 */
declare(strict_types=1);
?>

<?php if (is_logged_in()): ?>
</main><!-- /#main -->
<?php endif; ?>

<!-- ─── DELETE CONFIRMATION MODAL ────────────────────────────────────────── -->
<div class="modal-backdrop" id="deleteModal" role="dialog" aria-modal="true" aria-labelledby="deleteModalTitle" hidden>
    <div class="modal glass-card">
        <div class="modal-header">
            <div class="modal-icon modal-icon-danger"><i class="fa-solid fa-trash-can" aria-hidden="true"></i></div>
            <h2 class="modal-title" id="deleteModalTitle">Confirm Deletion</h2>
        </div>
        <div class="modal-body">
            <p id="deleteModalMessage" class="modal-message">Are you sure you want to delete this record? This action cannot be undone.</p>
            <div class="modal-record-detail glass-card" id="deleteRecordDetail" style="display:none;"></div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-ghost" id="deleteCancelBtn" aria-label="Cancel deletion">Cancel</button>
            <form id="deleteModalForm" method="POST" style="display:inline;">
                <input type="hidden" name="_csrf_token" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="id" id="deleteModalId">
                <button type="submit" class="btn btn-danger" id="deleteConfirmBtn">
                    <i class="fa-solid fa-trash-can" aria-hidden="true"></i> Delete
                </button>
            </form>
        </div>
    </div>
</div>

<!-- ─── GLOBAL TOAST CONTAINER ───────────────────────────────────────────── -->
<div class="toast-container" id="toastContainer" aria-live="polite" aria-atomic="false"></div>

<!-- ─── CDN LIBRARIES ─────────────────────────────────────────────────────── -->
<!-- Three.js r128 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<!-- GSAP 3 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<!-- Chart.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>

<!-- ─── APP SCRIPTS ───────────────────────────────────────────────────────── -->
<script>
// Global config passed from PHP to JS
window.KDMS = {
    baseUrl:   '<?= base_url() ?>',
    csrfToken: '<?= e(csrf_token()) ?>',
    role:      '<?= e(current_role()) ?>',
    userId:    <?= (int)(current_user()['user_id'] ?? 0) ?>,
    userName:  '<?= e(current_user()['full_name'] ?? '') ?>',
};
</script>

<script src="<?= base_url('/assets/js/app.js') ?>"></script>
<script src="<?= base_url('/assets/js/notifications.js') ?>"></script>

<?php if (isset($include_three_scene) && $include_three_scene): ?>
<script src="<?= base_url('/assets/js/three-scene.js') ?>"></script>
<?php endif; ?>

<?php if (isset($include_dashboard_charts) && $include_dashboard_charts): ?>
<script src="<?= base_url('/assets/js/dashboard-charts.js') ?>"></script>
<?php endif; ?>

<?php if (isset($include_compatibility) && $include_compatibility): ?>
<script src="<?= base_url('/assets/js/compatibility.js') ?>"></script>
<?php endif; ?>

<?php if (isset($extra_js)): ?>
<script><?= $extra_js ?></script>
<?php endif; ?>

<!-- ─── FOOTER ────────────────────────────────────────────────────────────── -->
<?php if (is_logged_in()): ?>
<footer class="app-footer" role="contentinfo">
    <span>KDMS Pro &copy; <?= date('Y') ?> &mdash; Global Kidney Donation Network</span>
    <span class="footer-version">v1.0.0</span>
</footer>
<?php endif; ?>

</body>
</html>
