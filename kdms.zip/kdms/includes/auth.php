<?php
/**
 * KDMS Pro — Authentication & Authorization
 * RBAC session management, CSRF protection, audit logging, brute-force protection
 */

declare(strict_types=1);

// Prevent direct access
if (!defined('KDMS_ROOT')) {
    define('KDMS_ROOT', dirname(__DIR__));
}

require_once KDMS_ROOT . '/config/database.php';

// ─── Security headers ─────────────────────────────────────────────────────────
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net https://fonts.googleapis.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com; font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; img-src 'self' data:; connect-src 'self';");

// ─── Session configuration ────────────────────────────────────────────────────
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.cookie_samesite', 'Strict');
    session_start();
}

// ─── Session timeout (30 min inactivity) ─────────────────────────────────────
const SESSION_TIMEOUT = 1800;

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > SESSION_TIMEOUT) {
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['flash'] = ['type' => 'warning', 'msg' => 'Your session has expired. Please log in again.'];
    header('Location: ' . base_url('/login.php'));
    exit;
}
$_SESSION['last_activity'] = time();

// ─── Base URL helper ──────────────────────────────────────────────────────────
function base_url(string $path = ''): string
{
    return '/kdms' . $path;
}

// ─── Current user ─────────────────────────────────────────────────────────────
/**
 * Returns the current logged-in user array or null.
 */
function current_user(): ?array
{
    return $_SESSION['user'] ?? null;
}

/**
 * Returns true if a user is logged in.
 */
function is_logged_in(): bool
{
    return !empty($_SESSION['user']['user_id']);
}

/**
 * Returns the current user's role name.
 */
function current_role(): string
{
    return $_SESSION['user']['role_name'] ?? 'guest';
}

// ─── Role guard ───────────────────────────────────────────────────────────────
/**
 * Enforce role-based access. Redirects to 403 or login if unauthorized.
 *
 * @param string[] $allowed_roles  e.g. ['admin','superadmin','doctor']
 */
function require_role(array $allowed_roles): void
{
    if (!is_logged_in()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        redirect('/login.php');
    }
    if (!in_array(current_role(), $allowed_roles, true)) {
        http_response_code(403);
        include KDMS_ROOT . '/pages/errors/403.php';
        exit;
    }
}

/**
 * Check if the current user has a specific role.
 */
function has_role(array $roles): bool
{
    return in_array(current_role(), $roles, true);
}

/**
 * Check if user can perform an action (checks JSON permissions field).
 */
function has_permission(string $resource, string $action): bool
{
    $user = current_user();
    if (!$user) return false;
    if ($user['role_name'] === 'superadmin') return true;

    $perms = json_decode($user['permissions'] ?? '{}', true);
    $allowed = $perms[$resource] ?? [];
    return in_array($action, $allowed, true) ||
           in_array($action . '_own', $allowed, true);
}

// ─── Redirect helper ──────────────────────────────────────────────────────────
function redirect(string $path): never
{
    header('Location: ' . base_url($path));
    exit;
}

// ─── CSRF Protection ──────────────────────────────────────────────────────────
/**
 * Generate or return existing CSRF token (stored in session).
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF token from POST. Dies with 403 on failure.
 */
function csrf_verify(): void
{
    $posted = $_POST['_csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals(csrf_token(), $posted)) {
        http_response_code(403);
        log_action('SYSTEM', null, null, null, null, 'CSRF token validation failed');
        die(json_encode(['success' => false, 'message' => 'Invalid security token. Please refresh and try again.']));
    }
}

/**
 * Output the hidden CSRF input field.
 */
function csrf_field(): string
{
    return '<input type="hidden" name="_csrf_token" value="' . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

// ─── Audit Logging ────────────────────────────────────────────────────────────
/**
 * Insert a record into audit_log.
 *
 * @param string      $action     CREATE|READ|UPDATE|DELETE|LOGIN|LOGOUT|APPROVE|REJECT|EXPORT|SYSTEM
 * @param string|null $table      Table name affected
 * @param int|null    $record_id  PK of affected record
 * @param mixed       $old        Old values (will be JSON-encoded)
 * @param mixed       $new        New values (will be JSON-encoded)
 * @param string|null $notes      Free text notes
 */
function log_action(
    string  $action,
    ?string $table     = null,
    ?int    $record_id = null,
    mixed   $old       = null,
    mixed   $new       = null,
    ?string $notes     = null
): void {
    try {
        $user = current_user();
        Database::execute(
            "INSERT INTO audit_log
               (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent, notes)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            [
                $user['user_id']   ?? null,
                strtoupper($action),
                $table,
                $record_id,
                $old !== null ? json_encode($old, JSON_UNESCAPED_UNICODE) : null,
                $new !== null ? json_encode($new, JSON_UNESCAPED_UNICODE) : null,
                $_SERVER['REMOTE_ADDR']    ?? null,
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
                $notes,
            ]
        );
    } catch (Throwable $e) {
        error_log('[KDMS AUDIT ERROR] ' . $e->getMessage());
    }
}

// ─── Flash Messages ───────────────────────────────────────────────────────────
/**
 * Set a one-time flash message.
 */
function flash(string $type, string $msg): void
{
    $_SESSION['flash'] = ['type' => $type, 'msg' => $msg];
}

/**
 * Retrieve and clear flash message.
 */
function get_flash(): ?array
{
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

// ─── XSS escaping ────────────────────────────────────────────────────────────
function e(mixed $val): string
{
    return htmlspecialchars((string)($val ?? ''), ENT_QUOTES, 'UTF-8');
}

// ─── Brute-force check ────────────────────────────────────────────────────────
/**
 * Check if an account is currently locked.
 * Returns true if locked (cannot attempt login).
 */
function is_account_locked(array $user): bool
{
    if ($user['locked_until'] === null) return false;
    return strtotime($user['locked_until']) > time();
}

// ─── Login handler ────────────────────────────────────────────────────────────
/**
 * Attempt login. Returns ['success'=>bool, 'message'=>string].
 */
function attempt_login(string $username, string $password, bool $remember = false): array
{
    $user = Database::fetchOne(
        "SELECT u.*, r.role_name, r.permissions
         FROM users u
         JOIN roles r ON u.role_id = r.role_id
         WHERE (u.username = ? OR u.email = ?) AND u.is_active = 1
         LIMIT 1",
        [$username, $username]
    );

    if (!$user) {
        return ['success' => false, 'message' => 'Invalid username or password.'];
    }

    // Check lockout
    if (is_account_locked($user)) {
        $until = date('H:i', strtotime($user['locked_until']));
        return ['success' => false, 'message' => "Account locked until {$until}. Too many failed attempts."];
    }

    // Verify password — seed uses password_hash('password123')
    // The seed file stores the Laravel/known test hash; in production use password_hash()
    $valid = password_verify($password, $user['password_hash']);

    // Fallback for demo: allow plain-text match stored in seed (for university demo)
    if (!$valid) {
        // Increment failed attempts
        $newFailed = ($user['failed_logins'] ?? 0) + 1;
        $lockUntil = null;
        if ($newFailed >= 5) {
            $lockUntil = date('Y-m-d H:i:s', time() + 900); // 15 min
        }
        Database::execute(
            "UPDATE users SET failed_logins = ?, locked_until = ? WHERE user_id = ?",
            [$newFailed, $lockUntil, $user['user_id']]
        );
        log_action('LOGIN', 'users', (int)$user['user_id'], null, null,
                   'Failed login attempt #' . $newFailed);
        return ['success' => false, 'message' => 'Invalid username or password.'];
    }

    // Success — reset failed logins, update last_login
    Database::execute(
        "UPDATE users SET failed_logins = 0, locked_until = NULL, last_login_at = CURRENT_TIMESTAMP WHERE user_id = ?",
        [$user['user_id']]
    );

    // Regenerate session ID (prevent fixation)
    session_regenerate_id(true);

    // Store user in session (exclude password hash)
    $_SESSION['user'] = [
        'user_id'     => (int)$user['user_id'],
        'username'    => $user['username'],
        'email'       => $user['email'],
        'full_name'   => $user['full_name'],
        'role_id'     => (int)$user['role_id'],
        'role_name'   => $user['role_name'],
        'permissions' => $user['permissions'],
        'linked_id'   => $user['linked_id'],
        'linked_type' => $user['linked_type'],
        'avatar_url'  => $user['avatar_url'],
    ];

    // Remember Me cookie (30 days)
    if ($remember) {
        $token = bin2hex(random_bytes(32));
        Database::execute(
            "UPDATE users SET remember_token = ? WHERE user_id = ?",
            [hash('sha256', $token), $user['user_id']]
        );
        setcookie('kdms_remember', $user['user_id'] . ':' . $token, [
            'expires'  => time() + 86400 * 30,
            'path'     => '/kdms',
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
    }

    log_action('LOGIN', 'users', (int)$user['user_id'], null,
               ['username' => $user['username'], 'role' => $user['role_name']],
               'Successful login');

    return ['success' => true, 'message' => 'Login successful.'];
}

// ─── Remember-me auto-login ───────────────────────────────────────────────────
if (!is_logged_in() && !empty($_COOKIE['kdms_remember'])) {
    $parts = explode(':', $_COOKIE['kdms_remember'], 2);
    if (count($parts) === 2) {
        [$uid, $token] = $parts;
        $remembered = Database::fetchOne(
            "SELECT u.*, r.role_name, r.permissions
             FROM users u JOIN roles r ON u.role_id = r.role_id
             WHERE u.user_id = ? AND u.is_active = 1 AND u.remember_token = ?",
            [(int)$uid, hash('sha256', $token)]
        );
        if ($remembered) {
            session_regenerate_id(true);
            $_SESSION['user'] = [
                'user_id'     => (int)$remembered['user_id'],
                'username'    => $remembered['username'],
                'email'       => $remembered['email'],
                'full_name'   => $remembered['full_name'],
                'role_id'     => (int)$remembered['role_id'],
                'role_name'   => $remembered['role_name'],
                'permissions' => $remembered['permissions'],
                'linked_id'   => $remembered['linked_id'],
                'linked_type' => $remembered['linked_type'],
                'avatar_url'  => $remembered['avatar_url'],
            ];
        }
    }
}

// ─── Utility helpers ──────────────────────────────────────────────────────────
/**
 * Paginate a query. Returns ['data'=>[], 'total'=>int, 'pages'=>int, 'page'=>int].
 */
function paginate(string $sql, array $params, int $page = 1, int $per_page = 20): array
{
    $page     = max(1, $page);
    $offset   = ($page - 1) * $per_page;
    $countSql = "SELECT COUNT(*) as cnt FROM ({$sql}) as sub";
    $total    = (int)(Database::fetchOne($countSql, $params)['cnt'] ?? 0);
    $pages    = (int)ceil($total / $per_page);
    $data     = Database::fetchAll("{$sql} LIMIT {$per_page} OFFSET {$offset}", $params);
    return compact('data', 'total', 'pages', 'page', 'per_page');
}

/**
 * Format a date for display.
 */
function fmt_date(mixed $date, string $format = 'M d, Y'): string
{
    if (!$date) return '—';
    $ts = is_numeric($date) ? (int)$date : strtotime((string)$date);
    return date($format, $ts);
}

/**
 * Format datetime for display.
 */
function fmt_datetime(mixed $date): string
{
    return fmt_date($date, 'M d, Y H:i');
}

/**
 * Calculate age from DOB.
 */
function calc_age(?string $dob): string
{
    if (!$dob) return '—';
    return (string)(int)((time() - strtotime($dob)) / 31557600) . ' yrs';
}

/** Parse and round a decimal form value to the project's 10-place precision. */
function decimal_value(mixed $value): ?float
{
    if ($value === null || $value === '' || !is_numeric($value)) return null;
    return round((float)$value, 10);
}

/** Display a numeric clinical value at exactly 10 decimal places. */
function fmt_decimal10(mixed $value): string
{
    if ($value === null || $value === '' || !is_numeric($value)) return '—';
    return number_format((float)$value, 10, '.', '');
}

/**
 * Returns a CSS class for a status badge.
 */
function status_class(string $status): string
{
    return match(strtolower($status)) {
        'available', 'stable', 'approved', 'successful', 'negative', 'clear'   => 'badge-success',
        'waiting', 'pending', 'ongoing', 'recovering'                           => 'badge-warning',
        'critical', 'failed', 'rejected', 'positive', 'flagged', 'suspended'   => 'badge-danger',
        'transplanted', 'discharged', 'matched'                                 => 'badge-info',
        'unavailable', 'withdrawn', 'cancelled'                                 => 'badge-muted',
        default                                                                 => 'badge-secondary',
    };
}

/**
 * Unread notification count for current user.
 */
function unread_notification_count(): int
{
    $user = current_user();
    if (!$user) return 0;
    $row = Database::fetchOne(
        "SELECT COUNT(*) AS cnt FROM notifications WHERE user_id = ? AND is_read = 0",
        [$user['user_id']]
    );
    return (int)($row['cnt'] ?? 0);
}
