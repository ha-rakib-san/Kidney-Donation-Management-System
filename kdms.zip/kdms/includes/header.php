<?php
/**
 * KDMS Pro — Global Header & Navigation
 * Role-aware sidebar, notification bell, user avatar
 */
declare(strict_types=1);

if (!defined('KDMS_ROOT')) {
    define('KDMS_ROOT', dirname(__DIR__));
}
require_once KDMS_ROOT . '/includes/auth.php';

$user          = current_user();
$role          = current_role();
$unread_count  = is_logged_in() ? unread_notification_count() : 0;
$current_path  = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$page_title    = $page_title ?? 'KDMS Pro';
$flash         = get_flash();

// ─── Nav items per role ───────────────────────────────────────────────────────
$nav_all = [
    ['icon' => 'fa-gauge-high',      'label' => 'Dashboard',      'href' => '/pages/dashboard.php',        'roles' => ['superadmin','admin','doctor','donor','recipient','auditor']],
    ['icon' => 'fa-hospital',        'label' => 'Hospitals',       'href' => '/pages/hospitals/index.php',  'roles' => ['superadmin','admin','auditor']],
    ['icon' => 'fa-user-doctor',     'label' => 'Doctors',         'href' => '/pages/doctors/index.php',    'roles' => ['superadmin','admin','auditor']],
    ['icon' => 'fa-heart-pulse',     'label' => 'Donors',          'href' => '/pages/donors/index.php',     'roles' => ['superadmin','admin','doctor','auditor']],
    ['icon' => 'fa-bed-pulse',       'label' => 'Recipients',      'href' => '/pages/recipients/index.php', 'roles' => ['superadmin','admin','doctor','auditor']],
    ['icon' => 'fa-flask-vial',      'label' => 'Medical Tests',   'href' => '/pages/tests/index.php',      'roles' => ['superadmin','admin','doctor','auditor']],
    ['icon' => 'fa-dna',             'label' => 'Matches',         'href' => '/pages/matches/index.php',    'roles' => ['superadmin','admin','doctor','auditor']],
    ['icon' => 'fa-scalpel',         'label' => 'Transplants',     'href' => '/pages/transplants/index.php','roles' => ['superadmin','admin','doctor','auditor']],
    ['icon' => 'fa-clipboard-list',  'label' => 'Follow-Ups',      'href' => '/pages/followups/index.php',  'roles' => ['superadmin','admin','doctor','auditor']],
    ['icon' => 'fa-magnifying-glass-chart', 'label' => 'Donor Search', 'href' => '/pages/search.php',     'roles' => ['superadmin','admin','doctor','auditor']],
    ['icon' => 'fa-list-check',      'label' => 'Match Summary',   'href' => '/pages/match_summary.php',   'roles' => ['superadmin','admin','doctor','auditor']],
    ['icon' => 'fa-chart-line',      'label' => 'Reports',         'href' => '/pages/reports.php',         'roles' => ['superadmin','admin','auditor']],
    ['icon' => 'fa-shield-halved',   'label' => 'Audit Log',       'href' => '/pages/audit_log.php',       'roles' => ['superadmin','admin','auditor']],
];

// Self-service nav for donors/recipients
$nav_self = [
    ['icon' => 'fa-gauge-high',   'label' => 'My Dashboard', 'href' => '/pages/dashboard.php', 'roles' => ['donor','recipient']],
    ['icon' => 'fa-user-circle',  'label' => 'My Profile',   'href' => '/pages/profile.php',   'roles' => ['donor','recipient']],
];

$nav_items = in_array($role, ['donor','recipient']) ? $nav_self : $nav_all;

// Role badge color
$role_colors = [
    'superadmin' => '#FF2D55',
    'admin'      => '#00D4FF',
    'doctor'     => '#00E5A0',
    'donor'      => '#FFB800',
    'recipient'  => '#8B5CF6',
    'auditor'    => '#6B7280',
];
$role_color = $role_colors[$role] ?? '#445577';
$role_label = ucfirst($role);

// Avatar initials
$initials = '';
if ($user) {
    $parts = explode(' ', $user['full_name']);
    $initials = strtoupper(substr($parts[0] ?? 'U', 0, 1) . substr($parts[1] ?? '', 0, 1));
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="KDMS Pro — Kidney Donation Management System">
<title><?= e($page_title) ?> | KDMS Pro</title>

<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&family=Inter:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

<!-- Font Awesome 6.5 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<!-- KDMS CSS -->
<link rel="stylesheet" href="<?= base_url('/assets/css/main.css') ?>">
<link rel="stylesheet" href="<?= base_url('/assets/css/animations.css') ?>">
<link rel="stylesheet" href="<?= base_url('/assets/css/print.css') ?>" media="print">
</head>
<body class="kdms-body">

<?php if (is_logged_in()): ?>
<!-- ─── SIDEBAR ──────────────────────────────────────────────────────────── -->
<aside class="sidebar" id="sidebar" aria-label="Main navigation">
    <!-- Logo -->
    <div class="sidebar-logo">
        <a href="<?= base_url('/pages/dashboard.php') ?>" class="logo-link" aria-label="KDMS Pro Home">
            <div class="logo-icon" aria-hidden="true">
                <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <ellipse cx="24" cy="24" rx="14" ry="20" stroke="var(--accent-cyan)" stroke-width="2.5" fill="none"/>
                    <ellipse cx="24" cy="24" rx="7"  ry="12" stroke="var(--accent-cyan)" stroke-width="1.5" fill="none" opacity="0.5"/>
                    <path d="M10 24 Q18 18 24 24 Q30 30 38 24" stroke="var(--accent-crimson)" stroke-width="2" fill="none" stroke-linecap="round">
                        <animate attributeName="stroke-dashoffset" from="100" to="0" dur="2s" repeatCount="indefinite"/>
                    </path>
                </svg>
            </div>
            <span class="logo-text">KDMS <span class="logo-pro">Pro</span></span>
        </a>
    </div>

    <!-- User card -->
    <div class="sidebar-user">
        <div class="user-avatar" style="background: <?= e($role_color) ?>22; border: 2px solid <?= e($role_color) ?>44;"
             title="<?= e($user['full_name'] ?? '') ?>">
            <?= e($initials) ?>
        </div>
        <div class="user-info">
            <div class="user-name"><?= e($user['full_name'] ?? '') ?></div>
            <span class="role-badge" style="background: <?= e($role_color) ?>22; color: <?= e($role_color) ?>; border: 1px solid <?= e($role_color) ?>44;">
                <?= e($role_label) ?>
            </span>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="sidebar-nav" role="navigation" aria-label="Site navigation">
        <ul class="nav-list" role="list">
            <?php foreach ($nav_items as $item): ?>
                <?php if (!in_array($role, $item['roles'], true)) continue; ?>
                <?php
                $is_active = str_contains($current_path, dirname($item['href'])) ||
                             str_ends_with($current_path, $item['href']);
                ?>
                <li class="nav-item" role="listitem">
                    <a href="<?= base_url($item['href']) ?>"
                       class="nav-link <?= $is_active ? 'active' : '' ?>"
                       aria-current="<?= $is_active ? 'page' : 'false' ?>">
                        <span class="nav-icon" aria-hidden="true"><i class="fa-solid <?= e($item['icon']) ?>"></i></span>
                        <span class="nav-label"><?= e($item['label']) ?></span>
                        <?php if ($is_active): ?>
                            <span class="nav-active-indicator" aria-hidden="true"></span>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </nav>

    <!-- Sidebar footer -->
    <div class="sidebar-footer">
        <!-- Notification bell -->
        <a href="<?= base_url('/pages/profile.php') ?>#notifications" class="nav-link notif-link" aria-label="Notifications (<?= $unread_count ?> unread)">
            <span class="nav-icon" aria-hidden="true">
                <i class="fa-solid fa-bell"></i>
                <?php if ($unread_count > 0): ?>
                    <span class="notif-badge" aria-label="<?= $unread_count ?> unread"><?= $unread_count > 99 ? '99+' : $unread_count ?></span>
                <?php endif; ?>
            </span>
            <span class="nav-label">Notifications</span>
        </a>

        <!-- Profile -->
        <a href="<?= base_url('/pages/profile.php') ?>" class="nav-link">
            <span class="nav-icon" aria-hidden="true"><i class="fa-solid fa-user-gear"></i></span>
            <span class="nav-label">My Profile</span>
        </a>

        <!-- Logout -->
        <a href="<?= base_url('/logout.php') ?>" class="nav-link nav-logout">
            <span class="nav-icon" aria-hidden="true"><i class="fa-solid fa-right-from-bracket"></i></span>
            <span class="nav-label">Log Out</span>
        </a>

        <!-- Collapse toggle -->
        <button class="sidebar-toggle" id="sidebarToggle" aria-label="Collapse sidebar" title="Collapse sidebar">
            <i class="fa-solid fa-chevron-left" id="toggleIcon"></i>
        </button>
    </div>
</aside>

<!-- ─── MOBILE OVERLAY ────────────────────────────────────────────────────── -->
<div class="sidebar-overlay" id="sidebarOverlay" aria-hidden="true"></div>

<!-- ─── TOPBAR (mobile hamburger + breadcrumb) ───────────────────────────── -->
<header class="topbar" role="banner">
    <button class="hamburger" id="hamburger" aria-label="Open navigation" aria-expanded="false" aria-controls="sidebar">
        <i class="fa-solid fa-bars"></i>
    </button>
    <div class="topbar-title"><?= e($page_title) ?></div>
    <div class="topbar-right">
        <button class="topbar-notif" id="topbarNotif" aria-label="Notifications">
            <i class="fa-solid fa-bell"></i>
            <?php if ($unread_count > 0): ?>
                <span class="notif-badge-sm"><?= $unread_count ?></span>
            <?php endif; ?>
        </button>
        <div class="topbar-avatar" style="background: <?= e($role_color) ?>33; border: 1.5px solid <?= e($role_color) ?>66;">
            <?= e($initials) ?>
        </div>
    </div>
</header>

<!-- ─── NOTIFICATION DROPDOWN ────────────────────────────────────────────── -->
<div class="notif-dropdown glass-card" id="notifDropdown" aria-live="polite" aria-label="Notifications" hidden>
    <div class="notif-header">
        <span>Notifications</span>
        <button class="notif-mark-all" id="markAllRead" aria-label="Mark all as read">Mark all read</button>
    </div>
    <ul class="notif-list" id="notifList" role="list">
        <li class="notif-loading"><i class="fa-solid fa-spinner fa-spin"></i> Loading…</li>
    </ul>
    <div class="notif-footer">
        <a href="<?= base_url('/pages/profile.php') ?>#notifications">View all</a>
    </div>
</div>

<!-- ─── MAIN CONTENT WRAPPER ─────────────────────────────────────────────── -->
<main class="main-content" id="main" role="main">
<?php endif; ?>

<!-- ─── FLASH MESSAGE ─────────────────────────────────────────────────────── -->
<?php if ($flash): ?>
<div class="flash-message flash-<?= e($flash['type']) ?>" role="alert" aria-live="assertive" id="flashMsg">
    <span class="flash-icon">
        <?php echo match($flash['type']) {
            'success' => '<i class="fa-solid fa-circle-check"></i>',
            'warning' => '<i class="fa-solid fa-triangle-exclamation"></i>',
            'danger'  => '<i class="fa-solid fa-circle-xmark"></i>',
            default   => '<i class="fa-solid fa-circle-info"></i>',
        }; ?>
    </span>
    <span class="flash-text"><?= e($flash['msg']) ?></span>
    <button class="flash-close" aria-label="Dismiss" onclick="this.parentElement.remove()">
        <i class="fa-solid fa-xmark"></i>
    </button>
    <div class="flash-progress"></div>
</div>
<?php endif; ?>
