<?php
/**
 * KDMS Pro — Scheduler
 *
 * SQLite has no background process and therefore no event scheduler, so the
 * four MySQL `CREATE EVENT` jobs documented in sql/05_events.sql run here
 * instead, using a "due job" pattern: each job's last-run timestamp is
 * stored in system_settings, and Scheduler::runDueJobs() (called once near
 * the top of pages/dashboard.php) runs any job whose interval has elapsed.
 *
 * For a real OS-level cron/Task Scheduler entry instead of this page-load
 * trigger, call the same methods from cron/maintenance.php.
 */
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../lib/Procedures.php';

class Scheduler
{
    private const JOBS = [
        'daily_waitlist_reprioritize'  => 86400,        // 1 day
        'weekly_match_suggestions'     => 604800,       // 1 week
        'monthly_cleanup'               => 2592000,      // 30 days
        'hourly_stats_cache'            => 3600,         // 1 hour
    ];

    /** Run every job whose interval has elapsed since its last run. Safe to call on every page load. */
    public static function runDueJobs(): array
    {
        $ran = [];
        foreach (self::JOBS as $job => $intervalSeconds) {
            if (self::isDue($job, $intervalSeconds)) {
                self::run($job);
                self::markRan($job);
                $ran[] = $job;
            }
        }
        return $ran;
    }

    private static function isDue(string $job, int $intervalSeconds): bool
    {
        $row = Database::fetchOne('SELECT setting_value FROM system_settings WHERE setting_key = ?', ["last_run:{$job}"]);
        if (!$row) {
            return true; // never run before
        }
        $lastRun = strtotime((string) $row['setting_value']);
        return $lastRun === false || (time() - $lastRun) >= $intervalSeconds;
    }

    private static function markRan(string $job): void
    {
        $key = "last_run:{$job}";
        $exists = Database::fetchOne('SELECT setting_key FROM system_settings WHERE setting_key = ?', [$key]);
        if ($exists) {
            Database::execute('UPDATE system_settings SET setting_value = ?, updated_at = CURRENT_TIMESTAMP WHERE setting_key = ?', [date('Y-m-d H:i:s'), $key]);
        } else {
            Database::execute(
                'INSERT INTO system_settings (setting_key, setting_value, setting_type, description) VALUES (?, ?, ?, ?)',
                [$key, date('Y-m-d H:i:s'), 'string', "Last run timestamp for scheduled job '{$job}'"]
            );
        }
    }

    private static function run(string $job): void
    {
        try {
            match ($job) {
                'daily_waitlist_reprioritize' => Procedures::prioritizeWaitlist(),
                'weekly_match_suggestions'    => self::weeklyMatchSuggestions(),
                'monthly_cleanup'              => self::monthlyCleanup(),
                'hourly_stats_cache'           => self::hourlyStatsCache(),
                default => null,
            };
        } catch (Throwable $e) {
            error_log("[KDMS Scheduler] job '{$job}' failed: " . $e->getMessage());
        }
    }

    /** evt_weekly_match_suggestions — AI-suggest matches for every Critical recipient still Waiting. */
    private static function weeklyMatchSuggestions(): void
    {
        $critical = Database::fetchAll("SELECT recipient_id FROM recipients WHERE urgency_level = 'Critical' AND wait_status = 'Waiting'");
        foreach ($critical as $r) {
            Procedures::autoMatchDonorsForRecipient((int) $r['recipient_id'], 60);
        }
    }

    /** evt_monthly_cleanup — archive old read notifications, expire password resets, vacuum-ish audit trim. */
    private static function monthlyCleanup(): void
    {
        Database::execute("DELETE FROM notifications WHERE is_read = 1 AND created_at < DATE('now', '-90 days')");
        Database::execute("DELETE FROM password_resets WHERE expires_at < CURRENT_TIMESTAMP");
    }

    /** evt_hourly_stats_cache — cache dashboard counts into system_settings as JSON. */
    private static function hourlyStatsCache(): void
    {
        $stats = Procedures::getDashboardStats();
        $key = 'cached_dashboard_stats';
        $value = json_encode($stats);
        $exists = Database::fetchOne('SELECT setting_key FROM system_settings WHERE setting_key = ?', [$key]);
        if ($exists) {
            Database::execute('UPDATE system_settings SET setting_value = ?, updated_at = CURRENT_TIMESTAMP WHERE setting_key = ?', [$value, $key]);
        } else {
            Database::execute(
                'INSERT INTO system_settings (setting_key, setting_value, setting_type, description) VALUES (?, ?, ?, ?)',
                [$key, $value, 'json', 'Cached dashboard KPI snapshot, refreshed hourly']
            );
        }
    }
}
