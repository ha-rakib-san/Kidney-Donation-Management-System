<?php
/**
 * KDMS Pro — login.php
 * Login page with Three.js DNA helix animation
 */
declare(strict_types=1);

define('KDMS_ROOT', __DIR__);
require_once KDMS_ROOT . '/includes/auth.php';

// Already logged in → redirect to dashboard
if (is_logged_in()) {
    redirect('/pages/dashboard.php');
}

$error   = '';
$success = '';

// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate CSRF
    $posted_token = $_POST['_csrf_token'] ?? '';
    if (!hash_equals(csrf_token(), $posted_token)) {
        $error = 'Invalid security token. Please refresh the page.';
    } else {
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password']       ?? '';
        $remember = !empty($_POST['remember_me']);

        if (!$username || !$password) {
            $error = 'Please enter your username and password.';
        } else {
            $result = attempt_login($username, $password, $remember);
            if ($result['success']) {
                $redirect = $_SESSION['redirect_after_login'] ?? base_url('/pages/dashboard.php');
                unset($_SESSION['redirect_after_login']);
                header('Location: ' . $redirect);
                exit;
            } else {
                $error = $result['message'];
            }
        }
    }
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — KDMS Pro</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;700&family=Inter:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= base_url('/assets/css/main.css') ?>">
<link rel="stylesheet" href="<?= base_url('/assets/css/animations.css') ?>">
</head>
<body style="overflow:hidden;">

<?php if ($flash): ?>
<div class="flash-message flash-<?= e($flash['type']) ?>" role="alert" id="flashMsg">
    <span class="flash-icon">
        <?= $flash['type'] === 'success' ? '<i class="fa-solid fa-circle-check"></i>' : '<i class="fa-solid fa-triangle-exclamation"></i>' ?>
    </span>
    <span class="flash-text"><?= e($flash['msg']) ?></span>
    <button class="flash-close" onclick="this.parentElement.remove()"><i class="fa-solid fa-xmark"></i></button>
    <div class="flash-progress"></div>
</div>
<?php endif; ?>

<div class="login-page">
    <!-- Three.js DNA panel -->
    <div class="login-three-panel">
        <canvas id="loginCanvas"></canvas>
        <!-- Overlay text -->
        <div style="position:absolute;bottom:40px;left:40px;z-index:10;max-width:360px;">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
                <div style="width:3px;height:32px;background:var(--accent-cyan);border-radius:2px;"></div>
                <span style="font-family:var(--font-display);font-size:0.78rem;color:var(--text-muted);letter-spacing:0.12em;text-transform:uppercase;">International Healthcare Technology</span>
            </div>
            <h2 style="font-family:var(--font-display);font-size:2.2rem;color:var(--text-primary);line-height:1.15;margin-bottom:12px;">
                Saving Lives<br>Through <span style="color:var(--accent-cyan);">Smart Matching</span>
            </h2>
            <p style="color:var(--text-secondary);font-size:0.9rem;line-height:1.6;">
                The KDMS Pro platform connects organ donors with recipients across 30+ countries using advanced compatibility algorithms and real-time medical intelligence.
            </p>
            <div style="display:flex;gap:24px;margin-top:20px;">
                <div><div style="font-family:var(--font-mono);font-size:1.5rem;font-weight:700;color:var(--accent-cyan);">25+</div><div style="font-size:0.75rem;color:var(--text-muted);">Active Donors</div></div>
                <div><div style="font-family:var(--font-mono);font-size:1.5rem;font-weight:700;color:var(--accent-green);">8</div><div style="font-size:0.75rem;color:var(--text-muted);">Hospitals</div></div>
                <div><div style="font-family:var(--font-mono);font-size:1.5rem;font-weight:700;color:var(--accent-gold);">12</div><div style="font-size:0.75rem;color:var(--text-muted);">Specialists</div></div>
            </div>
        </div>
    </div>

    <!-- Login form panel -->
    <div class="login-form-panel">
        <div class="login-card glass-card no-hover" style="position:relative;">
            <div class="login-card-border"></div>

            <!-- Logo -->
            <div class="login-logo">
                <div class="login-logo-icon">
                    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <ellipse cx="32" cy="32" rx="18" ry="26" stroke="var(--accent-cyan)" stroke-width="3" fill="rgba(0,212,255,0.06)"/>
                        <ellipse cx="32" cy="32" rx="9"  ry="15" stroke="var(--accent-cyan)" stroke-width="1.5" fill="none" opacity="0.4"/>
                        <path d="M14 32 Q22 24 32 32 Q42 40 50 32" stroke="var(--accent-crimson)" stroke-width="2.5" fill="none" stroke-linecap="round"/>
                        <circle cx="32" cy="32" r="3" fill="var(--accent-cyan)" opacity="0.8">
                            <animate attributeName="r" values="3;5;3" dur="1.5s" repeatCount="indefinite"/>
                            <animate attributeName="opacity" values="0.8;0.3;0.8" dur="1.5s" repeatCount="indefinite"/>
                        </circle>
                    </svg>
                </div>
                <h1>KDMS <span style="color:var(--accent-cyan);">Pro</span></h1>
                <p>Kidney Donation Management System</p>
            </div>

            <?php if ($error): ?>
            <div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:16px;animation:fadeUp 0.3s ease;" role="alert">
                <span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span>
                <span class="flash-text"><?= e($error) ?></span>
            </div>
            <?php endif; ?>

            <form method="POST" class="login-form" id="loginForm" novalidate>
                <?= csrf_field() ?>

                <div class="form-group">
                    <label for="username">Username or Email</label>
                    <div class="input-group">
                        <input type="text" id="username" name="username"
                               value="<?= e($_POST['username'] ?? '') ?>"
                               placeholder="Enter username or email"
                               autocomplete="username"
                               required
                               aria-required="true">
                        <span class="input-icon"><i class="fa-solid fa-user"></i></span>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-group">
                        <input type="password" id="password" name="password"
                               placeholder="Enter password"
                               autocomplete="current-password"
                               required
                               aria-required="true">
                        <span class="input-icon" id="togglePwd" style="cursor:pointer;" title="Show/hide password">
                            <i class="fa-solid fa-eye" id="pwdIcon"></i>
                        </span>
                    </div>
                </div>

                <label class="login-remember">
                    <input type="checkbox" name="remember_me" value="1" <?= !empty($_POST['remember_me']) ? 'checked' : '' ?>>
                    Remember me for 30 days
                </label>

                <button type="submit" class="btn btn-primary login-submit" id="loginBtn">
                    <i class="fa-solid fa-right-to-bracket"></i>
                    Sign In to KDMS Pro
                </button>
            </form>

            <!-- Demo credentials -->
            <div class="demo-creds">
                <h4><i class="fa-solid fa-flask-vial"></i> DEMO CREDENTIALS</h4>
                <table>
                    <tr><td>Superadmin</td><td>superadmin</td><td>password</td></tr>
                    <tr><td>Doctor</td>    <td>dr_aminul</td> <td>password</td></tr>
                    <tr><td>Donor</td>     <td>donor_rakib</td><td>password</td></tr>
                    <tr><td>Recipient</td> <td>recipient_kalam</td><td>password</td></tr>
                    <tr><td>Auditor</td>   <td>auditor_user</td><td>password</td></tr>
                </table>
                <p style="margin-top:8px;font-size:0.7rem;color:var(--text-muted);">
                    <i class="fa-solid fa-circle-info"></i> Click a row to auto-fill credentials
                </p>
            </div>

            <p style="text-align:center;margin-top:20px;font-size:0.78rem;color:var(--text-muted);">
                Secure access powered by KDMS Pro &bull; Global Hybrid Healthcare Platform
            </p>
        </div>
    </div>
</div>

<!-- Three.js + GSAP + App scripts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<script>
window.KDMS = {
    baseUrl:   '<?= base_url() ?>',
    csrfToken: '<?= e(csrf_token()) ?>',
    role:      'guest',
    userId:    0,
};
</script>
<script src="<?= base_url('/assets/js/three-scene.js') ?>"></script>
<script src="<?= base_url('/assets/js/app.js') ?>"></script>
<script>
// Password toggle
const togglePwd = document.getElementById('togglePwd');
const pwdInput  = document.getElementById('password');
const pwdIcon   = document.getElementById('pwdIcon');
togglePwd && togglePwd.addEventListener('click', () => {
    const isText = pwdInput.type === 'text';
    pwdInput.type = isText ? 'password' : 'text';
    pwdIcon.className = isText ? 'fa-solid fa-eye' : 'fa-solid fa-eye-slash';
});

// Click demo row to auto-fill
document.querySelectorAll('.demo-creds tr').forEach(row => {
    row.style.cursor = 'pointer';
    row.addEventListener('click', () => {
        const cells = row.querySelectorAll('td');
        if (cells.length >= 3) {
            document.getElementById('username').value = cells[1].textContent.trim();
            document.getElementById('password').value = cells[2].textContent.trim();
        }
    });
});

// Login button loading state
document.getElementById('loginForm').addEventListener('submit', (e) => {
    const btn = document.getElementById('loginBtn');
    btn.innerHTML = '<i class="fa-solid fa-spinner anim-spin"></i> Signing in…';
    btn.disabled  = true;
});

// GSAP entrance
if (typeof gsap !== 'undefined') {
    gsap.from('.login-card', { y: 40, opacity: 0, duration: 0.8, ease: 'power3.out', delay: 0.2 });
    gsap.from('.login-logo',  { y: 20, opacity: 0, duration: 0.6, ease: 'power2.out', delay: 0.5 });
    gsap.from('.login-form > *', { y: 16, opacity: 0, duration: 0.5, stagger: 0.08, ease: 'power2.out', delay: 0.7 });
}

// Flash auto-dismiss
setTimeout(() => {
    const f = document.getElementById('flashMsg');
    if (f) { f.style.animation = 'slideInRight 0.3s reverse forwards'; setTimeout(() => f?.remove(), 300); }
}, 4000);
</script>
</body>
</html>
