<?php
/**
 * KDMS Pro — Database Configuration
 * PDO SQLite Singleton with helper methods
 *
 * KDMS Pro previously targeted MySQL 8.0 via XAMPP. It now runs on SQLite —
 * a single embedded database file, no MySQL server/service required at all.
 * This keeps the original PSR-12 PDO helper API (query/fetchAll/fetchOne/
 * execute/transactions) so every page that already called Database::* keeps
 * working unchanged. The one method that COULD NOT be preserved is
 * callProcedure() — SQLite has no stored-procedure language — its eight call
 * sites now call the equivalent static methods on lib/Procedures.php instead.
 */

declare(strict_types=1);

// ─── Connection constants ─────────────────────────────────────────────────────
define('DB_DRIVER', 'sqlite');
define('DB_DIR',     __DIR__ . '/../storage');
define('DB_PATH',    DB_DIR . '/kdms.sqlite');

// ─── SQL bootstrap files, in dependency order ────────────────────────────────
// NOTE: seed data (06) is intentionally loaded BEFORE the validation/cascade
// triggers (03). Seed rows represent an already-resolved historical snapshot
// (e.g. a recipient who is already "Transplanted" referencing a match that
// was created back when they were still "Waiting") — running the donor/
// recipient status guard triggers against that snapshot would reject valid
// historical rows. Loading triggers last means they protect every write the
// running application makes from this point forward, which is what matters.
const DB_BOOTSTRAP_FILES = [
    '01_schema.sql',
    '02_procedures.sql',
    '04_views.sql',
    '06_seed.sql',
    '03_triggers.sql',
    '05_events.sql',
];

/**
 * Database — PDO singleton (SQLite)
 */
class Database
{
    private static ?PDO $instance = null;

    private function __construct() {}
    private function __clone()    {}

    /** @return PDO */
    public static function getInstance(): PDO
    {
        if (self::$instance === null) {
            $isNew = !is_file(DB_PATH);
            if (!is_dir(DB_DIR)) {
                @mkdir(DB_DIR, 0775, true);
            }

            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ];

            try {
                self::$instance = new PDO('sqlite:' . DB_PATH, null, null, $options);
                self::$instance->exec('PRAGMA foreign_keys = ON');
                self::$instance->exec('PRAGMA busy_timeout = 5000');

                if ($isNew) {
                    self::bootstrap();
                } else {
                    self::migratePrecisionSchema(self::$instance);
                }
            } catch (PDOException $e) {
                error_log('[KDMS DB ERROR] ' . $e->getMessage());
                http_response_code(500);
                die(json_encode(['success' => false, 'message' => 'Database connection failed.']));
            }
        }
        return self::$instance;
    }

    /**
     * Run the full SQL bootstrap (schema + procedures-doc + views + seed +
     * triggers + events-doc) against a brand-new database file. Called
     * automatically the first time the app connects to a missing
     * storage/kdms.sqlite, and also exposed for install.php to call directly
     * with progress output.
     */
    public static function bootstrap(): void
    {
        $pdo = self::$instance ?? new PDO('sqlite:' . DB_PATH);
        foreach (DB_BOOTSTRAP_FILES as $file) {
            $path = __DIR__ . '/../sql/' . $file;
            if (!is_file($path)) {
                continue;
            }
            $pdo->exec((string) file_get_contents($path));
        }
        self::migratePrecisionSchema($pdo);
        self::recalculateStoredCompatibility();
    }

    /** Add KDMS 2.0 precision columns without removing or renaming old data. */
    private static function migratePrecisionSchema(PDO $pdo): void
    {
        $medicalColumns = [
            'height_cm'      => 'NUMERIC',
            'weight_kg'      => 'NUMERIC',
            'bmi'            => 'NUMERIC',
            'systolic_bp'    => 'NUMERIC',
            'diastolic_bp'   => 'NUMERIC',
            'diabetes'       => 'INTEGER DEFAULT NULL',
            'hypertension'   => 'INTEGER DEFAULT NULL',
            'pra_percentage' => 'NUMERIC',
        ];
        $matchColumns = [
            'medical_score'        => 'NUMERIC NOT NULL DEFAULT 0',
            'age_score'            => 'NUMERIC NOT NULL DEFAULT 0',
            'bmi_score'            => 'NUMERIC NOT NULL DEFAULT 0',
            'creatinine_score'     => 'NUMERIC NOT NULL DEFAULT 0',
            'gfr_score'            => 'NUMERIC NOT NULL DEFAULT 0',
            'blood_pressure_score' => 'NUMERIC NOT NULL DEFAULT 0',
            'hemoglobin_score'     => 'NUMERIC NOT NULL DEFAULT 0',
            'diabetes_score'       => 'NUMERIC NOT NULL DEFAULT 0',
            'hypertension_score'   => 'NUMERIC NOT NULL DEFAULT 0',
            'pra_score'            => 'NUMERIC NOT NULL DEFAULT 0',
            'distance_km'          => 'NUMERIC',
            'age_difference_years' => 'NUMERIC',
            'data_completeness'    => 'NUMERIC NOT NULL DEFAULT 0',
            'is_eligible'          => 'INTEGER NOT NULL DEFAULT 0',
            'score_version'        => "TEXT NOT NULL DEFAULT 'KDMS-2.0'",
            'score_detail_json'    => 'TEXT',
        ];
        self::addMissingColumns($pdo, 'medical_tests', $medicalColumns);
        self::addMissingColumns($pdo, 'compatibility_matches', $matchColumns);
    }

    private static function addMissingColumns(PDO $pdo, string $table, array $columns): void
    {
        $existing = [];
        foreach ($pdo->query('PRAGMA table_info(' . $table . ')')->fetchAll(PDO::FETCH_ASSOC) as $column) {
            $existing[(string)$column['name']] = true;
        }
        foreach ($columns as $name => $definition) {
            if (!isset($existing[$name])) {
                $pdo->exec('ALTER TABLE ' . $table . ' ADD COLUMN ' . $name . ' ' . $definition);
            }
        }
    }

    private static function recalculateStoredCompatibility(): void
    {
        $procedures = __DIR__ . '/../lib/Procedures.php';
        if (!is_file($procedures)) {
            return;
        }
        require_once $procedures;
        if (class_exists('Procedures')) {
            Procedures::recalculateAllMatches();
        }
    }

    /**
     * Execute a query and return a PDOStatement
     */
    public static function query(string $sql, array $params = []): PDOStatement
    {
        $stmt = self::getInstance()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    /**
     * Fetch all rows as associative arrays
     */
    public static function fetchAll(string $sql, array $params = []): array
    {
        return self::query($sql, $params)->fetchAll();
    }

    /**
     * Fetch a single row or null
     */
    public static function fetchOne(string $sql, array $params = []): ?array
    {
        $row = self::query($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    /**
     * Execute a write query; returns lastInsertId for INSERT, rowCount for others
     */
    public static function execute(string $sql, array $params = []): string|int
    {
        $stmt = self::query($sql, $params);
        $verb = strtoupper(substr(ltrim($sql), 0, 6));
        return ($verb === 'INSERT') ? self::getInstance()->lastInsertId() : $stmt->rowCount();
    }

    /** Begin transaction */
    public static function beginTransaction(): bool
    {
        return self::getInstance()->beginTransaction();
    }

    /** Commit transaction */
    public static function commit(): bool
    {
        return self::getInstance()->commit();
    }

    /** Rollback transaction */
    public static function rollback(): bool
    {
        return self::getInstance()->rollBack();
    }

    /**
     * Quote an identifier list for IN(...) clauses safely with PDO params.
     * (Small helper used by lib/Procedures.php; kept here so every page that
     * already does `require_once __DIR__.'/../config/database.php'` gets it
     * for free.)
     */
    public static function placeholders(int $count): string
    {
        return implode(', ', array_fill(0, max($count, 0), '?'));
    }
}
