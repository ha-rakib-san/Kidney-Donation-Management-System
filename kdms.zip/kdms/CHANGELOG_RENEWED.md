# Renewed Project Changes

## KDMS 2.0 precision scoring

- Replaced the old four-factor integer-style score with a centralized continuous 100-point model.
- Added age difference, BMI, creatinine, GFR, blood pressure, hemoglobin, diabetes, hypertension, and PRA/cPRA.
- Added ten-decimal input, storage rounding, API output, score persistence, and detailed display.
- Added medical-data completeness, warnings, hard stops, eligibility, formula version, and JSON score details.
- Improved ABO handling and combined donor-recipient crossmatch validation.
- Added continuous HLA token similarity instead of exact text equality only.

## Dynamic distance

- Added Haversine hospital-to-hospital distance.
- Added continuous scoring across 0, 20, 50, 100, 250, 500, and 1,000 km anchors.
- Preserved city/country fallback when coordinates are unavailable.

## Medical tests

- Added height, weight, BMI, systolic pressure, diastolic pressure, diabetes, hypertension, and PRA/cPRA fields.
- Added strict input ranges and server-side BMI calculation.
- Updated create, edit, list, donor view, and recipient view pages.
- Recalculate affected matches after every test create, update, or delete.

## Dashboard

- Fixed the GSAP counter direction bug that animated real values down to zero.
- Preserved the existing dashboard queries, charts, polling, and visual structure.

## Database and compatibility workflow

- Added non-destructive precision-column migration support.
- Added precision columns to views and seeded demonstration records.
- Recalculate stored matches on a fresh install.
- Prevent match approval when required testing is incomplete or a hard stop exists.
- Added precision score review, warnings, distance, age difference, and component breakdown.

## Validation

- PHP syntax validation passed for all PHP files.
- JavaScript syntax validation passed for all JavaScript files.
- SQLite integrity and foreign-key checks passed.
- Schema bootstrap produced the expected seeded records.
- Independent scoring tests passed for eligible and positive-crossmatch cases.
