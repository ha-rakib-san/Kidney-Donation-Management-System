<?php
declare(strict_types=1);
if (!defined('KDMS_ROOT')) { define('KDMS_ROOT', dirname(dirname(__DIR__))); }
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>403 Forbidden | KDMS Pro</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@700&family=Inter:wght@400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="/kdms/assets/css/main.css">
<link rel="stylesheet" href="/kdms/assets/css/animations.css">
</head>
<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;">
<div class="glass-card no-hover anim-fade-up" style="max-width:440px;padding:48px 40px;text-align:center;">
    <div style="font-size:4rem;color:var(--accent-crimson);margin-bottom:16px;"><i class="fa-solid fa-shield-halved"></i></div>
    <h1 style="font-size:2.5rem;margin-bottom:8px;">403</h1>
    <h2 style="font-size:1.2rem;color:var(--text-secondary);margin-bottom:16px;">Access Forbidden</h2>
    <p style="margin-bottom:24px;">You don't have permission to access this resource. Your current role does not include this capability.</p>
    <a href="/kdms/pages/dashboard.php" class="btn btn-primary"><i class="fa-solid fa-house"></i> Back to Dashboard</a>
</div>
</body>
</html>
