<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('/pages/recipients/index.php'); }
csrf_verify();
$id = (int)($_POST['id'] ?? 0);
if (!$id) { flash('danger','Invalid ID.'); redirect('/pages/recipients/index.php'); }
$rec = Database::fetchOne("SELECT name FROM recipients WHERE recipient_id=?", [$id]);
if (!$rec) { flash('danger','Recipient not found.'); redirect('/pages/recipients/index.php'); }
try {
    Database::execute("DELETE FROM recipients WHERE recipient_id=?", [$id]);
    log_action('DELETE','recipients',$id,['name'=>$rec['name']]);
    flash('success',"Recipient '{$rec['name']}' deleted.");
} catch (PDOException $e) {
    flash('danger','Cannot delete: '.$e->getMessage());
}
redirect('/pages/recipients/index.php');
