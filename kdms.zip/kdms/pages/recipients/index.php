<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_role(['superadmin','admin','doctor','recipient','auditor']);

$page_title = 'Recipients';
$filter_blood   = trim($_GET['blood_group']   ?? '');
$filter_country = trim($_GET['country']       ?? '');
$filter_city    = trim($_GET['city']          ?? '');
$filter_urgency = trim($_GET['urgency_level'] ?? '');
$filter_status  = trim($_GET['wait_status']   ?? '');
$filter_search  = trim($_GET['search']        ?? '');
$page     = max(1,(int)($_GET['page'] ?? 1));
$per_page = 20;

if (current_role() === 'recipient') {
    $u = current_user();
    $where = ['r.recipient_id=?']; $params = [(int)($u['linked_id']??0)];
} else {
    $where = ['1=1']; $params = [];
    if ($filter_blood)   { $where[] = 'r.blood_group=?';   $params[] = $filter_blood; }
    if ($filter_country) { $where[] = 'r.country=?';       $params[] = $filter_country; }
    if ($filter_city)    { $where[] = 'r.city=?';          $params[] = $filter_city; }
    if ($filter_urgency) { $where[] = 'r.urgency_level=?'; $params[] = $filter_urgency; }
    if ($filter_status)  { $where[] = 'r.wait_status=?';   $params[] = $filter_status; }
    if ($filter_search)  { $where[] = 'r.name LIKE ?';     $params[] = '%'.$filter_search.'%'; }
}
$ws     = implode(' AND ', $where);
$total  = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM recipients r WHERE $ws",$params)['c']??0);
$pages  = (int)ceil($total/$per_page);
$offset = ($page-1)*$per_page;

$recipients = Database::fetchAll("
    SELECT r.*, h.name AS hospital_name,
           CAST(julianday('now') - julianday(r.wait_since) AS INTEGER) AS days_waiting,
           wq.queue_position
    FROM recipients r
    LEFT JOIN hospitals h  ON r.hospital_id=h.hospital_id
    LEFT JOIN waitlist_queue wq ON r.recipient_id=wq.recipient_id
    WHERE $ws
    ORDER BY CASE r.urgency_level WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END, r.wait_since ASC
    LIMIT $per_page OFFSET $offset", $params);

$blood_groups = KDMS_BLOOD_GROUPS;
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Recipients</span></div>
<div class="page-header">
    <div class="page-header-left">
        <div class="page-icon" style="color:var(--accent-crimson);background:rgba(255,45,85,0.1);"><i class="fa-solid fa-bed-pulse"></i></div>
        <div><h1>Recipients</h1><p class="text-sm text-muted">Kidney recipient waitlist</p></div>
        <span class="count-badge"><?=$total?></span>
    </div>
    <div class="page-actions">
        <?php if(has_role(['superadmin','admin','doctor'])): ?>
        <a href="<?=base_url('/pages/recipients/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Recipient</a>
        <?php endif; ?>
        <?php if(has_role(['superadmin','admin'])): ?>
        <button class="btn btn-ghost" data-export-csv="mainTable" data-filename="recipients-<?=date('Y-m-d')?>.csv"><i class="fa-solid fa-file-csv"></i> Export</button>
        <?php endif; ?>
    </div>
</div>
<div class="glass-card no-hover">
    <?php if(!has_role(['recipient'])): ?>
    <form method="GET">
        <div class="filter-bar">
            <div class="form-group"><label>Search</label><input type="text" name="search" value="<?=e($filter_search)?>" placeholder="Search recipients…"></div>
            <div class="form-group"><label>Blood Group</label><select name="blood_group"><option value="">All</option><?php foreach($blood_groups as $bg): ?><option value="<?=e($bg)?>" <?=$filter_blood===$bg?'selected':''?>><?=e($bg)?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>Country</label><select name="country" id="filterCountryR" onchange="kdmsCityCascade('filterCountryR','filterCityR', true)"><option value="">All</option><?php foreach(KDMS_COUNTRIES as $c): ?><option value="<?=e($c)?>" <?=$filter_country===$c?'selected':''?>><?=e($c)?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>City</label><select name="city" id="filterCityR"><option value="">All</option><?php foreach(($filter_country?kdms_cities_for($filter_country):kdms_all_cities()) as $c): ?><option value="<?=e($c)?>" <?=$filter_city===$c?'selected':''?>><?=e($c)?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>Urgency</label><select name="urgency_level"><option value="">All</option><?php foreach(['Low','Medium','High','Critical'] as $u): ?><option value="<?=$u?>" <?=$filter_urgency===$u?'selected':''?>><?=$u?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>Status</label><select name="wait_status"><option value="">All</option><?php foreach(['Waiting','Matched','Transplanted','Withdrawn'] as $s): ?><option value="<?=$s?>" <?=$filter_status===$s?'selected':''?>><?=$s?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>&nbsp;</label><div class="btn-group"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button><a href="<?=base_url('/pages/recipients/index.php')?>" class="btn btn-ghost btn-sm">Clear</a></div></div>
        </div>
    </form>
    <?php endif; ?>
    <div class="table-wrap">
        <?php if($recipients): ?>
        <table id="mainTable">
            <thead><tr>
                <th data-sort="name">Recipient</th>
                <th data-sort="blood_group">Blood</th>
                <th data-sort="urgency_level">Urgency</th>
                <th data-sort="wait_status">Status</th>
                <th>Days Waiting</th>
                <th>Queue #</th>
                <th>Country / City</th>
                <th data-sort="hospital_name">Hospital</th>
                <th class="no-export">Actions</th>
            </tr></thead>
            <tbody>
            <?php foreach($recipients as $r):
                $isCrit = $r['urgency_level']==='Critical';
                $bgClass = 'bg-'.str_replace(['+','-'],['pos','neg'],$r['blood_group']);
            ?>
            <tr <?=$isCrit?'class="critical-row"':''?>>
                <td>
                    <div class="d-flex align-center gap-2">
                        <div class="avatar-circle" style="background:rgba(<?=$isCrit?'255,45,85':'0,212,255'?>,0.12);color:var(--<?=$isCrit?'accent-crimson':'accent-cyan'?>);">
                            <?=strtoupper(substr($r['name'],0,2))?>
                        </div>
                        <div>
                            <div style="font-weight:600;font-size:.88rem;" data-col="name"><?=e($r['name'])?></div>
                            <div style="font-size:.72rem;color:var(--text-muted);"><?=e($r['contact']??'')?></div>
                        </div>
                    </div>
                </td>
                <td><span class="badge <?=e($bgClass)?>" data-col="blood_group"><?=e($r['blood_group'])?></span></td>
                <td data-col="urgency_level"><span class="badge <?=status_class($r['urgency_level'])?> <?=$isCrit?'badge-critical':''?>"><?=e($r['urgency_level'])?></span></td>
                <td data-col="wait_status"><span class="badge <?=status_class($r['wait_status'])?>"><?=e($r['wait_status'])?></span></td>
                <td class="td-mono <?=(int)$r['days_waiting']>365?'text-red':''?>"><?=(int)$r['days_waiting']?>d</td>
                <td class="td-mono text-cyan"><?=$r['queue_position']?'#'.(int)$r['queue_position']:'—'?></td>
                <td><?=e($r['city'])?>, <?=e($r['country'])?></td>
                <td style="font-size:.82rem;color:var(--text-secondary);" data-col="hospital_name"><?=e($r['hospital_name']??'—')?></td>
                <td class="no-export">
                    <div class="btn-group">
                        <a href="<?=base_url('/pages/recipients/view.php?id='.(int)$r['recipient_id'])?>" class="btn btn-info btn-xs" title="View"><i class="fa-solid fa-eye"></i></a>
                        <?php if(has_role(['superadmin','admin','doctor'])): ?>
                        <a href="<?=base_url('/pages/recipients/edit.php?id='.(int)$r['recipient_id'])?>" class="btn btn-ghost btn-xs" title="Edit"><i class="fa-solid fa-pen"></i></a>
                        <?php endif; ?>
                        <?php if(has_role(['superadmin','admin'])): ?>
                        <button class="btn btn-danger btn-xs" data-delete="<?=base_url('/pages/recipients/delete.php')?>" data-id="<?=(int)$r['recipient_id']?>" data-msg="Delete recipient '<?=e($r['name'])?>'? Cannot undo."><i class="fa-solid fa-trash-can"></i></button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state">
            <div class="empty-icon"><i class="fa-solid fa-bed-pulse"></i></div>
            <div class="empty-title">No Recipients Found</div>
            <div class="empty-message">No recipients match your current filters.</div>
            <?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/recipients/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Recipient</a><?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php if($pages>1): ?>
    <div class="pagination">
        <?php if($page>1): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page-1]))?>" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a><?php else: ?><span class="page-btn disabled"><i class="fa-solid fa-chevron-left"></i></span><?php endif; ?>
        <?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$p]))?>" class="page-btn <?=$p===$page?'active':''?>"><?=$p?></a><?php endfor; ?>
        <?php if($page<$pages): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page+1]))?>" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a><?php else: ?><span class="page-btn disabled"><i class="fa-solid fa-chevron-right"></i></span><?php endif; ?>
        <span class="pagination-info">Page <?=$page?> of <?=$pages?> &bull; <?=$total?> records</span>
    </div>
    <?php endif; ?>
</div>
<script>window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
