<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin','doctor']);

$page_title = 'Edit Recipient';
$id         = (int)($_GET['id'] ?? 0);
if (!$id) { flash('danger','Invalid ID.'); redirect('/pages/recipients/index.php'); }
$rec = Database::fetchOne("SELECT * FROM recipients WHERE recipient_id=?", [$id]);
if (!$rec) { flash('danger','Recipient not found.'); redirect('/pages/recipients/index.php'); }

$errors    = [];
$hospitals = Database::fetchAll("SELECT hospital_id,name,city,country FROM hospitals WHERE is_active=1 ORDER BY name");
$blood_groups = KDMS_BLOOD_GROUPS;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $old = $rec;
    $name    = trim($_POST['name']          ?? '');
    $dob     = trim($_POST['dob']           ?? '');
    $gender  = trim($_POST['gender']        ?? '');
    $blood   = trim($_POST['blood_group']   ?? '');
    $country = trim($_POST['country']       ?? '');
    $city    = trim($_POST['city']          ?? '');
    $address = trim($_POST['address']       ?? '');
    $contact = trim($_POST['contact']       ?? '');
    $email   = trim($_POST['email']         ?? '');
    $emerg   = trim($_POST['emergency_contact'] ?? '');
    $urgency = trim($_POST['urgency_level'] ?? 'Medium');
    $status  = trim($_POST['wait_status']   ?? 'Waiting');
    $hosp_id = (int)($_POST['hospital_id']  ?? 0) ?: null;
    $diag    = trim($_POST['diagnosis']     ?? '');
    $dial    = trim($_POST['dialysis_start'] ?? '') ?: null;
    $gfr     = trim($_POST['gfr_level']     ?? '') ?: null;
    $med_hist= trim($_POST['medical_history'] ?? '');
    $insur   = trim($_POST['insurance_info'] ?? '');
    $notes   = trim($_POST['notes']          ?? '');
    $nid     = trim($_POST['nid']            ?? '') ?: null;

    if (!$name)    $errors[] = 'Name required.';
    if (!$blood)   $errors[] = 'Blood group required.';
    if (!$country) $errors[] = 'Country required.';
    if (!$city)    $errors[] = 'City required.';

    if (!$errors) {
        try {
            Database::execute(
                "UPDATE recipients SET name=?,dob=?,gender=?,blood_group=?,country=?,city=?,address=?,contact=?,
                 email=?,emergency_contact=?,urgency_level=?,wait_status=?,hospital_id=?,diagnosis=?,
                 dialysis_start=?,gfr_level=?,medical_history=?,insurance_info=?,notes=?,nid=?,updated_at=CURRENT_TIMESTAMP
                 WHERE recipient_id=?",
                [$name,$dob?:null,$gender,$blood,$country,$city,$address,$contact,$email,
                 $emerg,$urgency,$status,$hosp_id,$diag,$dial,$gfr,
                 $med_hist,$insur,$notes,$nid,$id]
            );
            Procedures::recalculateMatchesForPerson($id, 'Recipient');
            log_action('UPDATE','recipients',$id,$old,
                ['name'=>$name,'urgency_level'=>$urgency,'wait_status'=>$status]);
            flash('success',"Recipient '{$name}' updated.");
            redirect('/pages/recipients/view.php?id='.$id);
        } catch (PDOException $e) {
            $errors[] = 'DB error: '.$e->getMessage();
        }
    }
    $rec = array_merge($rec, $_POST);
}

require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/recipients/index.php')?>">Recipients</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/recipients/view.php?id='.$id)?>"><?=e($rec['name'])?></a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Edit</span></div>
<div class="page-header">
    <div class="page-header-left">
        <div class="page-icon" style="color:var(--accent-crimson);background:rgba(255,45,85,0.1);"><i class="fa-solid fa-pen-to-square"></i></div>
        <div><h1>Edit Recipient</h1><p class="text-sm text-muted"><?=e($rec['name'])?></p></div>
    </div>
    <div class="page-actions"><a href="<?=base_url('/pages/recipients/view.php?id='.$id)?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if($errors): ?>
<div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;" role="alert">
    <span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span>
    <div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div>
</div>
<?php endif; ?>
<div class="glass-card no-hover">
    <div class="card-header"><h3><i class="fa-solid fa-bed-pulse text-red" style="margin-right:8px;"></i>Update Recipient Information</h3></div>
    <div class="card-body">
        <form method="POST" class="kdms-form" novalidate>
            <?=csrf_field()?>
            <div class="form-grid form-grid-3">
                <div class="form-group"><label>Full Name <span class="req">*</span></label><input type="text" name="name" value="<?=e($rec['name'])?>" required maxlength="100"></div>
                <div class="form-group"><label>NID</label><input type="text" name="nid" value="<?=e($rec['nid']??'')?>" maxlength="20"></div>
                <div class="form-group"><label>Date of Birth</label><input type="date" name="dob" value="<?=e($rec['dob']??'')?>"></div>
                <div class="form-group"><label>Gender <span class="req">*</span></label><select name="gender" required><?php foreach(['Male','Female','Other'] as $g): ?><option value="<?=$g?>" <?=$rec['gender']===$g?'selected':''?>><?=$g?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Blood Group <span class="req">*</span></label><select name="blood_group" required><?php foreach($blood_groups as $bg): ?><option value="<?=$bg?>" <?=$rec['blood_group']===$bg?'selected':''?>><?=$bg?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Country <span class="req">*</span></label><?= kdms_country_select('country', $rec['country'] ?? null, 'onchange="kdmsCityCascade(\'country\',\'city\')"') ?></div>
                <div class="form-group"><label>City <span class="req">*</span></label><?= kdms_city_select('city', $rec['country'] ?? null, $rec['city'] ?? null) ?></div>
                <div class="form-group"><label>Phone</label><input type="tel" name="contact" value="<?=e($rec['contact']??'')?>" maxlength="20"></div>
                <div class="form-group"><label>Email</label><input type="email" name="email" value="<?=e($rec['email']??'')?>" maxlength="120"></div>
                <div class="form-group"><label>Emergency Contact</label><input type="tel" name="emergency_contact" value="<?=e($rec['emergency_contact']??'')?>" maxlength="20"></div>
                <div class="form-group"><label>Urgency Level</label><select name="urgency_level"><?php foreach(['Low','Medium','High','Critical'] as $u): ?><option value="<?=$u?>" <?=$rec['urgency_level']===$u?'selected':''?>><?=$u?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Wait Status</label><select name="wait_status"><?php foreach(['Waiting','Matched','Transplanted','Withdrawn'] as $s): ?><option value="<?=$s?>" <?=$rec['wait_status']===$s?'selected':''?>><?=$s?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Hospital</label><select name="hospital_id"><option value="">— None —</option><?php foreach($hospitals as $h): ?><option value="<?=(int)$h['hospital_id']?>" <?=((int)$rec['hospital_id'])===(int)$h['hospital_id']?'selected':''?>><?=e($h['name'])?> (<?=e($h['city'])?>, <?=e($h['country'])?>)</option><?php endforeach; ?></select></div>
                <div class="form-group"><label>GFR Level (mL/min)</label><input type="number" id="gfr_level" name="gfr_level" value="<?=e($rec['gfr_level']??'')?>" step="0.01" min="0" max="150"><div class="gfr-indicator" id="gfrStageDisplay"></div></div>
                <div class="form-group"><label>Dialysis Start</label><input type="date" name="dialysis_start" value="<?=e($rec['dialysis_start']??'')?>"></div>
                <div class="form-group"><label>Insurance Info</label><input type="text" name="insurance_info" value="<?=e($rec['insurance_info']??'')?>" maxlength="100"></div>
                <div class="form-group full"><label>Address</label><textarea name="address" rows="2"><?=e($rec['address']??'')?></textarea></div>
                <div class="form-group full"><label>Diagnosis</label><textarea name="diagnosis" rows="2"><?=e($rec['diagnosis']??'')?></textarea></div>
                <div class="form-group full"><label>Medical History</label><textarea name="medical_history" rows="3"><?=e($rec['medical_history']??'')?></textarea></div>
                <div class="form-group full"><label>Notes</label><textarea name="notes" rows="2"><?=e($rec['notes']??'')?></textarea></div>
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;">
                <a href="<?=base_url('/pages/recipients/view.php?id='.$id)?>" class="btn btn-ghost">Cancel</a>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button>
            </div>
        </form>
    </div>
</div>
<script>
window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;
const gfrInput=document.getElementById('gfr_level'),gfrDisplay=document.getElementById('gfrStageDisplay');
function updateGFR(v){const g=parseFloat(v);if(isNaN(g)||g<=0){gfrDisplay.innerHTML='';return;}const s=g>=90?{s:'Stage 1',c:'#00E5A0'}:g>=60?{s:'Stage 2',c:'#00D4FF'}:g>=45?{s:'Stage 3a',c:'#FFB800'}:g>=30?{s:'Stage 3b',c:'#FF8800'}:g>=15?{s:'Stage 4',c:'#FF2D55'}:{s:'Stage 5',c:'#CC0033'};gfrDisplay.innerHTML=`<span class="gfr-dot" style="background:${s.c}"></span><span style="color:${s.c};font-weight:600">${s.s}</span>`;}
gfrInput&&gfrInput.addEventListener('input',()=>updateGFR(gfrInput.value));updateGFR(gfrInput?.value);
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
