<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_role(['superadmin','admin','doctor']);

$page_title = 'Add Recipient';
$errors     = [];
$hospitals  = Database::fetchAll("SELECT hospital_id,name,city,country FROM hospitals WHERE is_active=1 ORDER BY name");
$blood_groups = KDMS_BLOOD_GROUPS;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $name    = trim($_POST['name']      ?? '');
    $dob     = trim($_POST['dob']       ?? '');
    $gender  = trim($_POST['gender']    ?? '');
    $blood   = trim($_POST['blood_group'] ?? '');
    $country = trim($_POST['country']   ?? '');
    $city    = trim($_POST['city']      ?? '');
    $address = trim($_POST['address']   ?? '');
    $contact = trim($_POST['contact']   ?? '');
    $email   = trim($_POST['email']     ?? '');
    $emerg   = trim($_POST['emergency_contact'] ?? '');
    $urgency = trim($_POST['urgency_level'] ?? 'Medium');
    $status  = trim($_POST['wait_status']   ?? 'Waiting');
    $hosp_id = (int)($_POST['hospital_id']  ?? 0) ?: null;
    $diag    = trim($_POST['diagnosis']     ?? '');
    $dial    = trim($_POST['dialysis_start'] ?? '') ?: null;
    $gfr     = trim($_POST['gfr_level']     ?? '') ?: null;
    $med_hist= trim($_POST['medical_history'] ?? '');
    $insur   = trim($_POST['insurance_info'] ?? '');
    $notes   = trim($_POST['notes']          ?? '');
    $nid     = trim($_POST['nid']            ?? '') ?: null;

    if (!$name)   $errors[] = 'Full name is required.';
    if (!$blood || !in_array($blood, $blood_groups)) $errors[] = 'Valid blood group is required.';
    if (!$gender)  $errors[] = 'Gender is required.';
    if (!$country) $errors[] = 'Country is required.';
    if (!$city)    $errors[] = 'City is required.';

    if (!$errors) {
        try {
            $id = Database::execute(
                "INSERT INTO recipients (name,dob,gender,blood_group,country,city,address,contact,email,
                 emergency_contact,urgency_level,wait_status,hospital_id,registered_by,diagnosis,
                 dialysis_start,gfr_level,medical_history,insurance_info,notes,nid)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [$name,$dob?:null,$gender,$blood,$country,$city,$address,$contact,$email,
                 $emerg,$urgency,$status,$hosp_id,current_user()['user_id'],
                 $diag,$dial,$gfr,$med_hist,$insur,$notes,$nid]
            );
            // Add to waitlist if Waiting
            if ($status === 'Waiting') {
                Database::execute(
                    "INSERT INTO waitlist_queue (recipient_id,queue_position,priority_score,wait_since_date)
                     VALUES (?,9999,50.00,DATE('now')) ON CONFLICT(recipient_id) DO UPDATE SET last_recalculated=CURRENT_TIMESTAMP",
                    [(int)$id]
                );
            }
            log_action('CREATE','recipients',(int)$id,null,
                ['name'=>$name,'blood_group'=>$blood,'country'=>$country,'urgency_level'=>$urgency]);
            flash('success',"Recipient '{$name}' added successfully.");
            redirect('/pages/recipients/index.php');
        } catch (PDOException $e) {
            $errors[] = 'Database error: '.$e->getMessage();
        }
    }
}

require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/recipients/index.php')?>">Recipients</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Add Recipient</span></div>
<div class="page-header">
    <div class="page-header-left">
        <div class="page-icon" style="color:var(--accent-crimson);background:rgba(255,45,85,0.1);"><i class="fa-solid fa-user-plus"></i></div>
        <div><h1>Add New Recipient</h1><p class="text-sm text-muted">Register a new kidney recipient</p></div>
    </div>
    <div class="page-actions"><a href="<?=base_url('/pages/recipients/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if ($errors): ?>
<div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;" role="alert">
    <span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span>
    <div><?php foreach ($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div>
</div>
<?php endif; ?>
<div class="glass-card no-hover">
    <div class="card-header"><h3><i class="fa-solid fa-bed-pulse text-red" style="margin-right:8px;"></i>Recipient Information</h3></div>
    <div class="card-body">
        <form method="POST" class="kdms-form" novalidate>
            <?=csrf_field()?>
            <div class="form-grid form-grid-3">
                <div class="form-group"><label for="name">Full Name <span class="req">*</span></label><input type="text" id="name" name="name" value="<?=e($_POST['name']??'')?>" required maxlength="100"></div>
                <div class="form-group"><label for="nid">National ID</label><input type="text" id="nid" name="nid" value="<?=e($_POST['nid']??'')?>" maxlength="20"></div>
                <div class="form-group"><label for="dob">Date of Birth</label><input type="date" id="dob" name="dob" value="<?=e($_POST['dob']??'')?>"></div>
                <div class="form-group"><label for="gender">Gender <span class="req">*</span></label><select id="gender" name="gender" required><option value="">Select…</option><?php foreach(['Male','Female','Other'] as $g): ?><option value="<?=$g?>" <?=($_POST['gender']??'')===$g?'selected':''?>><?=$g?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label for="blood_group">Blood Group <span class="req">*</span></label><select id="blood_group" name="blood_group" required><option value="">Select…</option><?php foreach($blood_groups as $bg): ?><option value="<?=$bg?>" <?=($_POST['blood_group']??'')===$bg?'selected':''?>><?=$bg?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label for="country">Country <span class="req">*</span></label><?= kdms_country_select('country', $_POST['country'] ?? null, 'onchange="kdmsCityCascade(\'country\',\'city\')"') ?></div>
                <div class="form-group"><label for="city">City <span class="req">*</span></label><?= kdms_city_select('city', $_POST['country'] ?? null, $_POST['city'] ?? null) ?></div>
                <div class="form-group"><label for="contact">Phone</label><input type="tel" id="contact" name="contact" value="<?=e($_POST['contact']??'')?>" maxlength="20"></div>
                <div class="form-group"><label for="email">Email</label><input type="email" id="email" name="email" value="<?=e($_POST['email']??'')?>" maxlength="120"></div>
                <div class="form-group"><label for="emergency_contact">Emergency Contact</label><input type="tel" id="emergency_contact" name="emergency_contact" value="<?=e($_POST['emergency_contact']??'')?>" maxlength="20"></div>
                <div class="form-group"><label for="urgency_level">Urgency Level <span class="req">*</span></label><select id="urgency_level" name="urgency_level" required><?php foreach(['Low','Medium','High','Critical'] as $u): ?><option value="<?=$u?>" <?=($_POST['urgency_level']??'Medium')===$u?'selected':''?>><?=$u?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label for="wait_status">Wait Status</label><select id="wait_status" name="wait_status"><?php foreach(['Waiting','Matched','Transplanted','Withdrawn'] as $s): ?><option value="<?=$s?>" <?=($_POST['wait_status']??'Waiting')===$s?'selected':''?>><?=$s?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label for="hospital_id">Hospital</label><select id="hospital_id" name="hospital_id"><option value="">— None —</option><?php foreach($hospitals as $h): ?><option value="<?=(int)$h['hospital_id']?>" <?=((int)($_POST['hospital_id']??0))===(int)$h['hospital_id']?'selected':''?>><?=e($h['name'])?> (<?=e($h['city'])?>, <?=e($h['country'])?>)</option><?php endforeach; ?></select></div>
                <div class="form-group"><label for="gfr_level">GFR Level (mL/min)</label><input type="number" id="gfr_level" name="gfr_level" value="<?=e($_POST['gfr_level']??'')?>" step="0.01" min="0" max="150" placeholder="e.g. 14.5"><div class="gfr-indicator" id="gfrStageDisplay"></div></div>
                <div class="form-group"><label for="dialysis_start">Dialysis Start Date</label><input type="date" id="dialysis_start" name="dialysis_start" value="<?=e($_POST['dialysis_start']??'')?>"></div>
                <div class="form-group"><label for="insurance_info">Insurance Info</label><input type="text" id="insurance_info" name="insurance_info" value="<?=e($_POST['insurance_info']??'')?>" maxlength="100"></div>
                <div class="form-group full"><label for="address">Address</label><textarea id="address" name="address" rows="2"><?=e($_POST['address']??'')?></textarea></div>
                <div class="form-group full"><label for="diagnosis">Diagnosis</label><textarea id="diagnosis" name="diagnosis" rows="2" placeholder="Primary kidney disease diagnosis…"><?=e($_POST['diagnosis']??'')?></textarea></div>
                <div class="form-group full"><label for="medical_history">Medical History</label><textarea id="medical_history" name="medical_history" rows="3"><?=e($_POST['medical_history']??'')?></textarea></div>
                <div class="form-group full"><label for="notes">Notes</label><textarea id="notes" name="notes" rows="2"><?=e($_POST['notes']??'')?></textarea></div>
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;">
                <a href="<?=base_url('/pages/recipients/index.php')?>" class="btn btn-ghost">Cancel</a>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Recipient</button>
            </div>
        </form>
    </div>
</div>
<script>
window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;
const gfrInput = document.getElementById('gfr_level');
const gfrDisplay = document.getElementById('gfrStageDisplay');
function updateGFR(val) {
    const g = parseFloat(val); if(isNaN(g)||g<=0){gfrDisplay.innerHTML='';return;}
    const stage = g>=90?{s:'Stage 1',c:'#00E5A0',l:'Normal or high'}:g>=60?{s:'Stage 2',c:'#00D4FF',l:'Mildly decreased'}:g>=45?{s:'Stage 3a',c:'#FFB800',l:'Mild-moderate'}:g>=30?{s:'Stage 3b',c:'#FF8800',l:'Moderate-severe'}:g>=15?{s:'Stage 4',c:'#FF2D55',l:'Severely decreased'}:{s:'Stage 5',c:'#CC0033',l:'Kidney failure'};
    gfrDisplay.innerHTML=`<span class="gfr-dot" style="background:${stage.c};"></span><span style="color:${stage.c};font-weight:600;">${stage.s}</span><span style="color:var(--text-muted);margin-left:4px;">— ${stage.l}</span>`;
}
gfrInput&&gfrInput.addEventListener('input',()=>updateGFR(gfrInput.value));
updateGFR(gfrInput?.value);
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
