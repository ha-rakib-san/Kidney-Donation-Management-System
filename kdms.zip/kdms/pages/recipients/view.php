<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','recipient','auditor']);

$id = (int)($_GET['id'] ?? 0);
if (!$id) { flash('danger','Invalid ID.'); redirect('/pages/recipients/index.php'); }
if (current_role() === 'recipient') {
    $u = current_user();
    if ((int)($u['linked_id']??0) !== $id) { flash('danger','Access denied.'); redirect('/pages/dashboard.php'); }
}
$rec = Database::fetchOne("
    SELECT r.*, h.name AS hospital_name,
           CAST(julianday('now') - julianday(r.wait_since) AS INTEGER) AS days_waiting,
           wq.queue_position, wq.priority_score,
           u.full_name AS registered_by_name
    FROM recipients r
    LEFT JOIN hospitals h ON r.hospital_id=h.hospital_id
    LEFT JOIN waitlist_queue wq ON r.recipient_id=wq.recipient_id
    LEFT JOIN users u ON r.registered_by=u.user_id
    WHERE r.recipient_id=?", [$id]);
if (!$rec) { flash('danger','Recipient not found.'); redirect('/pages/recipients/index.php'); }

$tests   = Database::fetchAll("SELECT mt.*,doc.name AS doctor_name FROM medical_tests mt LEFT JOIN doctors doc ON mt.doctor_id=doc.doctor_id WHERE mt.person_id=? AND mt.person_type='Recipient' ORDER BY mt.test_date DESC", [$id]);
$matches = Database::fetchAll("SELECT cm.*,d.name AS donor_name,d.blood_group AS donor_blood FROM compatibility_matches cm JOIN donors d ON cm.donor_id=d.donor_id WHERE cm.recipient_id=? ORDER BY cm.match_date DESC LIMIT 10", [$id]);

$gfrInfo = null;
if ($rec['gfr_level']) {
    $g = (float)$rec['gfr_level'];
    $gfrInfo = $g>=90?['s'=>'Stage 1','c'=>'#00E5A0','l'=>'Normal']:($g>=60?['s'=>'Stage 2','c'=>'#00D4FF','l'=>'Mildly decreased']:($g>=45?['s'=>'Stage 3a','c'=>'#FFB800','l'=>'Mild-moderate']:($g>=30?['s'=>'Stage 3b','c'=>'#FF8800','l'=>'Moderate-severe']:($g>=15?['s'=>'Stage 4','c'=>'#FF2D55','l'=>'Severely decreased']:['s'=>'Stage 5','c'=>'#CC0033','l'=>'Kidney failure']))));
}

$page_title = 'Recipient: '.$rec['name'];
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><?php if(!has_role(['recipient'])): ?><a href="<?=base_url('/pages/recipients/index.php')?>">Recipients</a><span class="breadcrumb-sep">›</span><?php endif; ?><span class="breadcrumb-current"><?=e($rec['name'])?></span></div>
<div class="page-header">
    <div class="page-header-left">
        <div class="avatar-circle" style="width:56px;height:56px;font-size:1.2rem;background:rgba(255,45,85,0.12);color:var(--accent-crimson);"><?=strtoupper(substr($rec['name'],0,2))?></div>
        <div>
            <h1><?=e($rec['name'])?></h1>
            <div class="d-flex gap-2 mt-1">
                <span class="badge <?=status_class($rec['urgency_level'])?> <?=$rec['urgency_level']==='Critical'?'badge-critical':''?>"><?=e($rec['urgency_level'])?></span>
                <span class="badge <?=status_class($rec['wait_status'])?>"><?=e($rec['wait_status'])?></span>
                <span class="badge badge-muted"><?=e($rec['blood_group'])?></span>
            </div>
        </div>
    </div>
    <div class="page-actions">
        <?php if(has_role(['superadmin','admin','doctor'])): ?>
        <a href="<?=base_url('/pages/recipients/edit.php?id='.$id)?>" class="btn btn-info"><i class="fa-solid fa-pen"></i> Edit</a>
        <?php endif; ?>
        <?php if(has_role(['superadmin','admin'])): ?>
        <button class="btn btn-danger" data-delete="<?=base_url('/pages/recipients/delete.php')?>" data-id="<?=$id?>" data-msg="Delete recipient '<?=e($rec['name'])?>'?"><i class="fa-solid fa-trash-can"></i> Delete</button>
        <?php endif; ?>
        <a href="<?=base_url('/pages/recipients/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a>
    </div>
</div>

<div class="detail-grid mb-4">
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-user text-cyan" style="margin-right:8px;"></i>Personal Details</h3></div>
        <div class="card-body">
            <div class="detail-section">
                <div class="detail-row"><span class="detail-label">Name</span><span class="detail-value"><?=e($rec['name'])?></span></div>
                <div class="detail-row"><span class="detail-label">Date of Birth</span><span class="detail-value"><?=$rec['dob']?fmt_date($rec['dob']).' ('.calc_age($rec['dob']).')':'—'?></span></div>
                <div class="detail-row"><span class="detail-label">Gender</span><span class="detail-value"><?=e($rec['gender'])?></span></div>
                <div class="detail-row"><span class="detail-label">Blood Group</span><span class="detail-value"><span class="badge bg-<?=str_replace(['+','-'],['pos','neg'],$rec['blood_group'])?>"><?=e($rec['blood_group'])?></span></span></div>
                <div class="detail-row"><span class="detail-label">NID</span><span class="detail-value td-mono"><?=e($rec['nid']??'—')?></span></div>
                <div class="detail-row"><span class="detail-label">Contact</span><span class="detail-value"><?=e($rec['contact']??'—')?></span></div>
                <div class="detail-row"><span class="detail-label">Email</span><span class="detail-value"><?=e($rec['email']??'—')?></span></div>
                <div class="detail-row"><span class="detail-label">Emergency</span><span class="detail-value"><?=e($rec['emergency_contact']??'—')?></span></div>
                <div class="detail-row"><span class="detail-label">City / Country</span><span class="detail-value"><?=e($rec['city'])?>, <?=e($rec['country'])?></span></div>
                <div class="detail-row"><span class="detail-label">Hospital</span><span class="detail-value"><?=e($rec['hospital_name']??'—')?></span></div>
            </div>
        </div>
    </div>
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-bed-pulse text-red" style="margin-right:8px;"></i>Clinical & Waitlist Details</h3></div>
        <div class="card-body">
            <div class="detail-section">
                <div class="detail-row"><span class="detail-label">Urgency</span><span class="detail-value"><span class="badge <?=status_class($rec['urgency_level'])?> <?=$rec['urgency_level']==='Critical'?'badge-critical':''?>"><?=e($rec['urgency_level'])?></span></span></div>
                <div class="detail-row"><span class="detail-label">Wait Status</span><span class="detail-value"><span class="badge <?=status_class($rec['wait_status'])?>"><?=e($rec['wait_status'])?></span></span></div>
                <div class="detail-row"><span class="detail-label">Queue Position</span><span class="detail-value"><span class="queue-position-badge"><?=$rec['queue_position']?'#'.(int)$rec['queue_position']:'Not queued'?></span></span></div>
                <div class="detail-row"><span class="detail-label">Days Waiting</span><span class="detail-value td-mono <?=(int)$rec['days_waiting']>365?'text-red':''?>"><?=(int)$rec['days_waiting']?> days</span></div>
                <div class="detail-row"><span class="detail-label">Priority Score</span><span class="detail-value td-mono"><?=$rec['priority_score']?number_format((float)$rec['priority_score'],1):'—'?></span></div>
                <div class="detail-row"><span class="detail-label">GFR Level</span>
                    <span class="detail-value">
                        <?php if($rec['gfr_level']&&$gfrInfo): ?>
                        <span class="td-mono"><?=e($rec['gfr_level'])?> mL/min</span>
                        <div class="gfr-indicator mt-1"><span class="gfr-dot" style="background:<?=$gfrInfo['c']?>"></span><span style="color:<?=$gfrInfo['c']?>;font-weight:600;"><?=$gfrInfo['s']?></span><span class="text-muted text-xs" style="margin-left:4px;">— <?=$gfrInfo['l']?></span></div>
                        <?php else: ?>—<?php endif; ?>
                    </span>
                </div>
                <div class="detail-row"><span class="detail-label">Dialysis Start</span><span class="detail-value"><?=$rec['dialysis_start']?fmt_date($rec['dialysis_start']):'—'?></span></div>
                <div class="detail-row"><span class="detail-label">Insurance</span><span class="detail-value"><?=e($rec['insurance_info']??'—')?></span></div>
                <div class="detail-row"><span class="detail-label">Registered</span><span class="detail-value td-mono"><?=fmt_datetime($rec['created_at'])?></span></div>
                <?php if($rec['diagnosis']): ?><hr class="detail-divider"><div class="detail-row" style="flex-direction:column;gap:4px;"><span class="detail-label">Diagnosis</span><span class="detail-value text-sm"><?=nl2br(e($rec['diagnosis']))?></span></div><?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="glass-card no-hover mb-4">
    <div class="card-header"><h3><i class="fa-solid fa-flask-vial text-blue" style="margin-right:8px;"></i>Medical Tests (<?=count($tests)?>)</h3><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/tests/add.php?person_id='.$id.'&person_type=Recipient')?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Test</a><?php endif; ?></div>
    <div class="table-wrap">
        <?php if($tests): ?>
        <table><thead><tr><th>Date</th><th>Doctor</th><th>HLA</th><th>Crossmatch</th><th>GFR</th><th>Creatinine</th><th>BMI</th><th>BP</th><th>Hb</th><th>PRA</th><th>Actions</th></tr></thead><tbody>
        <?php foreach($tests as $t): ?>
        <tr><td class="td-mono"><?=fmt_date($t['test_date'])?></td><td><?=e($t['doctor_name']??'—')?></td><td class="td-mono"><?=e($t['tissue_type_hla']??'—')?></td><td><span class="badge <?=$t['crossmatch']==='Negative'?'badge-success':($t['crossmatch']==='Positive'?'badge-danger':'badge-warning')?>"><?=e($t['crossmatch'])?></span></td><td class="td-mono"><?=$t['gfr_numeric']!==null?fmt_decimal10($t['gfr_numeric']):'—'?></td><td class="td-mono"><?=$t['creatinine_level']!==null?fmt_decimal10($t['creatinine_level']):'—'?></td><td class="td-mono"><?=$t['bmi']!==null?fmt_decimal10($t['bmi']):'—'?></td><td class="td-mono"><?=($t['systolic_bp']!==null&&$t['diastolic_bp']!==null)?fmt_decimal10($t['systolic_bp']).'/'.fmt_decimal10($t['diastolic_bp']):'—'?></td><td class="td-mono"><?=$t['hemoglobin']!==null?fmt_decimal10($t['hemoglobin']):'—'?></td><td class="td-mono"><?=$t['pra_percentage']!==null?fmt_decimal10($t['pra_percentage']).'%':'—'?></td><td><a href="<?=base_url('/pages/tests/edit.php?id='.(int)$t['test_id'])?>" class="btn btn-ghost btn-xs"><i class="fa-solid fa-pen"></i></a></td></tr>
        <?php endforeach; ?>
        </tbody></table>
        <?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-flask-vial"></i></div><div class="empty-message">No medical tests recorded yet.</div></div><?php endif; ?>
    </div>
</div>
<div class="glass-card no-hover">
    <div class="card-header"><h3><i class="fa-solid fa-dna text-purple" style="margin-right:8px;"></i>Compatibility Matches (<?=count($matches)?>)</h3></div>
    <div class="table-wrap">
        <?php if($matches): ?>
        <table><thead><tr><th>Donor</th><th>Blood</th><th>Score</th><th>Result</th><th>Date</th></tr></thead><tbody>
        <?php foreach($matches as $m): ?>
        <tr><td><?=e($m['donor_name'])?></td><td><span class="badge bg-<?=str_replace(['+','-'],['pos','neg'],$m['donor_blood'])?>"><?=e($m['donor_blood'])?></span></td><td><div data-score-ring="<?=e(fmt_decimal10($m['match_score']))?>" style="width:44px;height:44px;position:relative;"></div></td><td><span class="badge <?=status_class($m['review_result'])?>"><?=e($m['review_result'])?></span></td><td class="td-mono text-muted"><?=fmt_date($m['match_date'])?></td></tr>
        <?php endforeach; ?>
        </tbody></table>
        <?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-dna"></i></div><div class="empty-message">No matches found.</div></div><?php endif; ?>
    </div>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
