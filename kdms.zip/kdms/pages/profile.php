<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','donor','recipient','auditor']);
$page_title = 'My Profile';
$user = current_user();
$errors = [];

// Update profile (phone, email, password)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = $_POST['form_action'] ?? '';

    if ($action === 'update_contact') {
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        if (!$email) $errors[] = 'Email is required.';
        if (!$errors) {
            try {
                Database::execute("UPDATE users SET email=?, phone=? WHERE user_id=?", [$email,$phone,$user['user_id']]);
                // Update linked donor/recipient contact too
                if ($user['linked_type']==='donor' && $user['linked_id']) {
                    Database::execute("UPDATE donors SET email=?, contact=? WHERE donor_id=?", [$email,$phone,$user['linked_id']]);
                } elseif ($user['linked_type']==='recipient' && $user['linked_id']) {
                    Database::execute("UPDATE recipients SET email=?, contact=? WHERE recipient_id=?", [$email,$phone,$user['linked_id']]);
                }
                log_action('UPDATE','users',(int)$user['user_id'],null,['email'=>$email,'phone'=>$phone],'Self-service profile update');
                flash('success','Profile updated successfully.');
                redirect('/pages/profile.php');
            } catch (PDOException $e) { $errors[] = 'DB error: '.$e->getMessage(); }
        }
    } elseif ($action === 'change_password') {
        $current = $_POST['current_password'] ?? '';
        $newpw   = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        $stored  = Database::fetchOne("SELECT password_hash FROM users WHERE user_id=?", [$user['user_id']]);

        if (!password_verify($current, $stored['password_hash'])) {
            $errors[] = 'Current password is incorrect.';
        } elseif (strlen($newpw) < 8) {
            $errors[] = 'New password must be at least 8 characters.';
        } elseif ($newpw !== $confirm) {
            $errors[] = 'Password confirmation does not match.';
        } else {
            Database::execute("UPDATE users SET password_hash=? WHERE user_id=?", [password_hash($newpw, PASSWORD_BCRYPT), $user['user_id']]);
            log_action('UPDATE','users',(int)$user['user_id'],null,null,'Password changed by user');
            flash('success','Password changed successfully.');
            redirect('/pages/profile.php');
        }
    }
}

// Reload user data
$userData = Database::fetchOne("SELECT u.*, r.role_name FROM users u JOIN roles r ON u.role_id=r.role_id WHERE u.user_id=?", [$user['user_id']]);

// Linked entity data
$linkedData = null;
if ($user['linked_type'] === 'donor' && $user['linked_id']) {
    $linkedData = Database::fetchOne("SELECT * FROM donors WHERE donor_id=?", [$user['linked_id']]);
} elseif ($user['linked_type'] === 'recipient' && $user['linked_id']) {
    $linkedData = Database::fetchOne("SELECT *, (SELECT queue_position FROM waitlist_queue WHERE recipient_id=recipients.recipient_id) AS queue_position FROM recipients WHERE recipient_id=?", [$user['linked_id']]);
} elseif ($user['linked_type'] === 'doctor' && $user['linked_id']) {
    $linkedData = Database::fetchOne("SELECT * FROM doctors WHERE doctor_id=?", [$user['linked_id']]);
}

// Notifications
$notifications = Database::fetchAll("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 30", [$user['user_id']]);

require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">My Profile</span></div>
<div class="page-header">
    <div class="page-header-left">
        <div class="profile-avatar-lg" style="background:rgba(0,212,255,0.12);color:var(--accent-cyan);margin:0;width:56px;height:56px;font-size:1.2rem;">
            <?php $parts=explode(' ',$user['full_name']); echo strtoupper(substr($parts[0]??'U',0,1).substr($parts[1]??'',0,1)); ?>
        </div>
        <div><h1><?=e($user['full_name'])?></h1><span class="badge badge-info"><?=e(ucfirst($user['role_name']))?></span></div>
    </div>
</div>

<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>

<div class="detail-grid mb-4">
    <!-- Account Info -->
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-user-gear text-cyan" style="margin-right:8px;"></i>Account Information</h3></div>
        <div class="card-body">
            <form method="POST" class="kdms-form" novalidate>
                <?=csrf_field()?>
                <input type="hidden" name="form_action" value="update_contact">
                <div class="form-grid">
                    <div class="form-group"><label>Username</label><input type="text" value="<?=e($userData['username'])?>" disabled style="opacity:.6;"></div>
                    <div class="form-group"><label>Full Name</label><input type="text" value="<?=e($userData['full_name'])?>" disabled style="opacity:.6;"></div>
                    <div class="form-group"><label>Email <span class="req">*</span></label><input type="email" name="email" value="<?=e($userData['email'])?>" required></div>
                    <div class="form-group"><label>Phone</label><input type="tel" name="phone" value="<?=e($userData['phone']??'')?>"></div>
                </div>
                <div style="display:flex;justify-content:flex-end;padding-top:16px;"><button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Update Contact Info</button></div>
            </form>
        </div>
    </div>

    <!-- Change Password -->
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-lock text-gold" style="margin-right:8px;"></i>Change Password</h3></div>
        <div class="card-body">
            <form method="POST" class="kdms-form" novalidate>
                <?=csrf_field()?>
                <input type="hidden" name="form_action" value="change_password">
                <div class="form-grid">
                    <div class="form-group"><label>Current Password <span class="req">*</span></label><input type="password" name="current_password" required></div>
                    <div class="form-group"><label>New Password <span class="req">*</span></label><input type="password" name="new_password" minlength="8" required></div>
                    <div class="form-group"><label>Confirm New Password <span class="req">*</span></label><input type="password" name="confirm_password" minlength="8" required></div>
                </div>
                <p class="form-help">Minimum 8 characters.</p>
                <div style="display:flex;justify-content:flex-end;padding-top:8px;"><button type="submit" class="btn btn-warning"><i class="fa-solid fa-key"></i> Change Password</button></div>
            </form>
        </div>
    </div>
</div>

<!-- Linked Entity Info -->
<?php if($linkedData && in_array($user['linked_type'],['donor','recipient'])): ?>
<div class="glass-card no-hover mb-4">
    <div class="card-header"><h3><i class="fa-solid fa-<?=$user['linked_type']==='donor'?'heart-pulse':'bed-pulse'?> text-<?=$user['linked_type']==='donor'?'cyan':'red'?>" style="margin-right:8px;"></i>My <?=ucfirst($user['linked_type'])?> Record</h3>
        <a href="<?=base_url('/pages/'.$user['linked_type'].'s/view.php?id='.(int)$user['linked_id'])?>" class="btn btn-info btn-sm">View Full Record</a>
    </div>
    <div class="card-body">
        <div class="detail-grid">
            <div class="detail-section">
                <div class="detail-row"><span class="detail-label">Blood Group</span><span class="detail-value"><span class="badge bg-<?=str_replace(['+','-'],['pos','neg'],$linkedData['blood_group'])?>"><?=e($linkedData['blood_group'])?></span></span></div>
                <div class="detail-row"><span class="detail-label">City</span><span class="detail-value"><?=e($linkedData['city'])?></span></div>
                <div class="detail-row"><span class="detail-label">Status</span><span class="detail-value"><span class="badge <?=status_class($linkedData['status']??$linkedData['wait_status']??'')?>"><?=e($linkedData['status']??$linkedData['wait_status']??'—')?></span></span></div>
            </div>
            <div class="detail-section">
                <?php if($user['linked_type']==='recipient' && !empty($linkedData['queue_position'])): ?>
                <div class="detail-row"><span class="detail-label">Waitlist Position</span><span class="detail-value"><span class="queue-position-badge">#<?=(int)$linkedData['queue_position']?></span></span></div>
                <?php endif; ?>
                <?php if($user['linked_type']==='recipient'): ?>
                <div class="detail-row"><span class="detail-label">Urgency</span><span class="detail-value"><span class="badge <?=status_class($linkedData['urgency_level'])?>"><?=e($linkedData['urgency_level'])?></span></span></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Notifications -->
<div class="glass-card no-hover" id="notifications">
    <div class="card-header"><h3><i class="fa-solid fa-bell text-purple" style="margin-right:8px;"></i>My Notifications</h3><span class="count-badge"><?=count($notifications)?></span></div>
    <div class="table-wrap">
        <?php if($notifications): ?>
        <table><thead><tr><th>Type</th><th>Title</th><th>Message</th><th>Date</th><th>Status</th></tr></thead><tbody>
        <?php foreach($notifications as $n): ?>
        <tr <?=!$n['is_read']?'style="background:rgba(0,212,255,0.03);"':''?>>
            <td><span class="badge <?=match($n['type']){'success'=>'badge-success','warning'=>'badge-warning','urgent'=>'badge-danger','match'=>'badge-info','transplant'=>'badge-purple',default=>'badge-muted'}?>"><?=e(ucfirst($n['type']))?></span></td>
            <td style="font-weight:600;font-size:.85rem;"><?=e($n['title'])?></td>
            <td style="font-size:.82rem;color:var(--text-secondary);"><?=e($n['message'])?></td>
            <td class="td-mono text-muted text-sm"><?=fmt_datetime($n['created_at'])?></td>
            <td><?=$n['is_read']?'<span class="badge badge-muted">Read</span>':'<span class="badge badge-info">New</span>'?></td>
        </tr>
        <?php endforeach; ?>
        </tbody></table>
        <?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-bell"></i></div><div class="empty-message">No notifications yet.</div></div><?php endif; ?>
    </div>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
