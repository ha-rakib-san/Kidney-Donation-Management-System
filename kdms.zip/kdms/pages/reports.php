<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','auditor']);
$page_title = 'Reports & Analytics';

require_once KDMS_ROOT . '/lib/Procedures.php';

$year  = (int)($_GET['year']  ?? date('Y'));
$month = (int)($_GET['month'] ?? date('n'));

// Monthly summary (was sp_generate_monthly_report)
$monthlyReport  = Procedures::generateMonthlyReport($year, $month);
$monthlySummary = $monthlyReport;
$locationBreakdown = $monthlyReport['by_location'] ?? [];

// 12-month trend
$trends = Database::fetchAll("SELECT * FROM v_monthly_trends ORDER BY yr ASC, mo ASC LIMIT 12");

// Doctor performance
$doctorPerf = Database::fetchAll("SELECT * FROM v_doctor_workload ORDER BY successful_transplants DESC LIMIT 12");

// Blood group demand vs supply
$bloodGroups = ['A+','A-','B+','B-','O+','O-','AB+','AB-'];
$bloodSupply = $bloodDemand = [];
foreach ($bloodGroups as $bg) {
    $bloodSupply[] = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM donors WHERE blood_group=? AND status='Available'",[$bg])['c']??0);
    $bloodDemand[] = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM recipients WHERE blood_group=? AND wait_status='Waiting'",[$bg])['c']??0);
}

$chartData = json_encode([
    'trends' => ['labels'=>array_column($trends,'month_label'),'transplants'=>array_column($trends,'new_transplants'),'matches'=>array_column($trends,'new_matches')],
    'blood'  => ['labels'=>$bloodGroups,'supply'=>$bloodSupply,'demand'=>$bloodDemand],
]);

require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Reports</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-chart-line"></i></div><div><h1>Reports & Analytics</h1><p class="text-sm text-muted">System-wide performance metrics</p></div></div>
    <div class="page-actions">
        <form method="GET" class="d-flex gap-2">
            <select name="month" onchange="this.form.submit()">
                <?php for($m=1;$m<=12;$m++): ?><option value="<?=$m?>" <?=$m===$month?'selected':''?>><?=date('F',mktime(0,0,0,$m,1))?></option><?php endfor; ?>
            </select>
            <select name="year" onchange="this.form.submit()">
                <?php for($y=date('Y');$y>=date('Y')-3;$y--): ?><option value="<?=$y?>" <?=$y===$year?'selected':''?>><?=$y?></option><?php endfor; ?>
            </select>
        </form>
        <button class="btn btn-ghost" onclick="window.print()"><i class="fa-solid fa-print"></i> Print PDF</button>
    </div>
</div>

<!-- Monthly Summary Cards -->
<div class="stat-grid mb-4" style="grid-template-columns:repeat(4,1fr);">
    <div class="glass-card stat-card"><div class="stat-icon icon-cyan"><i class="fa-solid fa-heart-pulse"></i></div><div class="stat-content"><div class="stat-value td-mono"><?=(int)($monthlySummary['new_donors']??0)?></div><div class="stat-label">New Donors</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-red"><i class="fa-solid fa-bed-pulse"></i></div><div class="stat-content"><div class="stat-value td-mono"><?=(int)($monthlySummary['new_recipients']??0)?></div><div class="stat-label">New Recipients</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-purple"><i class="fa-solid fa-dna"></i></div><div class="stat-content"><div class="stat-value td-mono"><?=(int)($monthlySummary['matches_made']??0)?></div><div class="stat-label">Matches Made</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-green"><i class="fa-solid fa-scalpel"></i></div><div class="stat-content"><div class="stat-value td-mono"><?=(int)($monthlySummary['transplants_done']??0)?></div><div class="stat-label">Transplants</div></div></div>
</div>
<div class="stat-grid mb-4" style="grid-template-columns:repeat(3,1fr);">
    <div class="glass-card stat-card"><div class="stat-icon icon-green"><i class="fa-solid fa-check"></i></div><div class="stat-content"><div class="stat-value td-mono" style="color:var(--accent-green);"><?=(int)($monthlySummary['successful']??0)?></div><div class="stat-label">Successful</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-red"><i class="fa-solid fa-xmark"></i></div><div class="stat-content"><div class="stat-value td-mono" style="color:var(--accent-crimson);"><?=(int)($monthlySummary['failed']??0)?></div><div class="stat-label">Failed</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-gold"><i class="fa-solid fa-percent"></i></div><div class="stat-content"><div class="stat-value td-mono"><?=$monthlySummary['success_rate_pct']??0?>%</div><div class="stat-label">Success Rate</div></div></div>
</div>

<!-- Trends Chart -->
<div class="glass-card no-hover chart-card mb-4">
    <h3><i class="fa-solid fa-chart-line text-cyan" style="margin-right:6px;"></i> 12-Month Trends</h3>
    <div class="chart-wrap" style="height:280px;"><canvas id="reportTrendChart"></canvas></div>
</div>

<!-- Blood Demand vs Supply -->
<div class="glass-card no-hover chart-card mb-4">
    <h3><i class="fa-solid fa-chart-bar text-red" style="margin-right:6px;"></i> Blood Group: Supply vs Demand</h3>
    <div class="chart-wrap" style="height:280px;"><canvas id="reportBloodChart"></canvas></div>
</div>

<!-- City & Country Breakdown -->
<div class="glass-card no-hover mb-4">
    <div class="card-header"><h3><i class="fa-solid fa-map-location-dot text-gold" style="margin-right:8px;"></i>City &amp; Country Breakdown (<?=date('F Y',mktime(0,0,0,$month,1,$year))?>)</h3></div>
    <div class="table-wrap">
        <?php if($locationBreakdown): ?>
        <table id="cityTable"><thead><tr><th>City</th><th>Country</th><th>Transplants</th></tr></thead><tbody>
        <?php foreach($locationBreakdown as $c): ?>
        <tr><td><?=e($c['city'])?></td><td><?=e($c['country'])?></td><td class="td-mono text-green"><?=(int)$c['transplant_count']?></td></tr>
        <?php endforeach; ?>
        </tbody></table>
        <?php else: ?><div class="empty-state"><div class="empty-message">No data for this period.</div></div><?php endif; ?>
    </div>
</div>

<!-- Doctor Performance -->
<div class="glass-card no-hover">
    <div class="card-header"><h3><i class="fa-solid fa-user-doctor text-purple" style="margin-right:8px;"></i>Doctor Performance</h3></div>
    <div class="table-wrap">
        <?php if($doctorPerf): ?>
        <table id="doctorTable"><thead><tr><th>Doctor</th><th>Specialization</th><th>Hospital</th><th>Active Tx</th><th>Successful</th><th>Success Rate</th></tr></thead><tbody>
        <?php foreach($doctorPerf as $d): ?>
        <tr>
            <td style="font-weight:600;"><?=e($d['name'])?></td>
            <td><span class="badge badge-info text-xs"><?=e($d['specialization'])?></span></td>
            <td style="font-size:.82rem;"><?=e($d['hospital_name']??'—')?></td>
            <td class="td-mono"><?=(int)$d['active_transplants']?></td>
            <td class="td-mono text-green"><?=(int)$d['successful_transplants']?></td>
            <td class="td-mono"><?=$d['success_rate_pct']??0?>%</td>
        </tr>
        <?php endforeach; ?>
        </tbody></table>
        <?php else: ?><div class="empty-state"><div class="empty-message">No doctor data available.</div></div><?php endif; ?>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
Chart.defaults.color = '#8899BB';
const data = <?=$chartData?>;
new Chart(document.getElementById('reportTrendChart'), {
    type: 'line',
    data: { labels: data.trends.labels, datasets: [
        {label:'Transplants', data:data.trends.transplants, borderColor:'#00D4FF', backgroundColor:'rgba(0,212,255,0.1)', fill:true, tension:0.4},
        {label:'Matches', data:data.trends.matches, borderColor:'#00E5A0', backgroundColor:'rgba(0,229,160,0.08)', fill:true, tension:0.4, borderDash:[4,3]}
    ]},
    options: { responsive:true, maintainAspectRatio:false, scales:{ x:{grid:{color:'rgba(255,255,255,.03)'}}, y:{beginAtZero:true,grid:{color:'rgba(255,255,255,.04)'}} } }
});
new Chart(document.getElementById('reportBloodChart'), {
    type: 'bar',
    data: { labels: data.blood.labels, datasets: [
        {label:'Supply (Available Donors)', data:data.blood.supply, backgroundColor:'rgba(0,229,160,0.6)', borderColor:'#00E5A0', borderWidth:1.5, borderRadius:4},
        {label:'Demand (Waiting Recipients)', data:data.blood.demand, backgroundColor:'rgba(255,45,85,0.55)', borderColor:'#FF2D55', borderWidth:1.5, borderRadius:4}
    ]},
    options: { responsive:true, maintainAspectRatio:false, scales:{ x:{grid:{display:false}}, y:{beginAtZero:true,grid:{color:'rgba(255,255,255,.04)'}} } }
});
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
