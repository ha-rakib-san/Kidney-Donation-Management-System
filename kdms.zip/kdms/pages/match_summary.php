<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','auditor']);
$page_title = 'Match Summary';

$matches = Database::fetchAll("SELECT * FROM v_approved_matches ORDER BY match_date DESC");
$totalScore = count($matches) ? array_sum(array_column($matches,'match_score')) / count($matches) : 0;

require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Match Summary</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-list-check"></i></div><div><h1>Approved Match Summary</h1><p class="text-sm text-muted">All clinically approved donor-recipient matches</p></div><span class="count-badge"><?=count($matches)?></span></div>
    <div class="page-actions"><button class="btn btn-ghost" data-export-csv="mainTable" data-filename="match-summary.csv"><i class="fa-solid fa-file-csv"></i> Export</button></div>
</div>

<div class="stat-grid mb-4" style="grid-template-columns:repeat(3,1fr);">
    <div class="glass-card stat-card"><div class="stat-icon icon-green"><i class="fa-solid fa-check-double"></i></div><div class="stat-content"><div class="stat-value td-mono" data-count="<?=count($matches)?>"><?=count($matches)?></div><div class="stat-label">Approved Matches</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-cyan"><i class="fa-solid fa-percent"></i></div><div class="stat-content"><div class="stat-value td-mono"><?=fmt_decimal10($totalScore)?>%</div><div class="stat-label">Average Score</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-purple"><i class="fa-solid fa-robot"></i></div><div class="stat-content"><div class="stat-value td-mono"><?=count(array_filter($matches, fn($m)=>$m['is_ai_suggested']))?></div><div class="stat-label">AI-Suggested</div></div></div>
</div>

<div class="glass-card no-hover">
    <div class="table-wrap">
        <?php if($matches): ?>
        <table id="mainTable">
            <thead><tr><th data-sort="donor_name">Donor</th><th>Blood</th><th data-sort="recipient_name">Recipient</th><th>Urgency</th><th>Score</th><th>Reviewed By</th><th data-sort="match_date">Date</th></tr></thead>
            <tbody>
            <?php foreach($matches as $m): ?>
            <tr>
                <td data-col="donor_name"><?=e($m['donor_name'])?> <span class="text-xs text-muted">(<?=e($m['donor_city'])?>)</span></td>
                <td><span class="badge bg-<?=str_replace(['+','-'],['pos','neg'],$m['donor_blood'])?>"><?=e($m['donor_blood'])?></span></td>
                <td data-col="recipient_name"><?=e($m['recipient_name'])?> <span class="text-xs text-muted">(<?=e($m['recipient_city'])?>)</span></td>
                <td><span class="badge <?=status_class($m['urgency_level'])?>"><?=e($m['urgency_level'])?></span></td>
                <td><div data-score-ring="<?=e(fmt_decimal10($m['match_score']))?>" style="width:44px;height:44px;position:relative;"></div></td>
                <td style="font-size:.82rem;"><?=e($m['reviewed_by_name']??'—')?></td>
                <td data-col="match_date" class="td-mono text-muted"><?=fmt_date($m['match_date'])?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-list-check"></i></div><div class="empty-title">No Approved Matches</div><div class="empty-message">Approved matches will appear here once reviewed.</div></div>
        <?php endif; ?>
    </div>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
