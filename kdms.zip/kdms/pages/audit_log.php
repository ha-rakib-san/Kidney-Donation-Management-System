<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','auditor']);
$page_title = 'Audit Log';

$filter_action = trim($_GET['action']     ?? '');
$filter_table  = trim($_GET['table_name'] ?? '');
$filter_user   = (int)($_GET['user_id']   ?? 0);
$filter_from   = trim($_GET['date_from']  ?? '');
$filter_to     = trim($_GET['date_to']    ?? '');
$page = max(1,(int)($_GET['page'] ?? 1)); $per_page = 30;

$where = ['1=1']; $params = [];
if ($filter_action) { $where[] = 'al.action=?';     $params[] = $filter_action; }
if ($filter_table)  { $where[] = 'al.table_name=?'; $params[] = $filter_table; }
if ($filter_user)   { $where[] = 'al.user_id=?';    $params[] = $filter_user; }
if ($filter_from)   { $where[] = 'al.created_at >= ?'; $params[] = $filter_from . ' 00:00:00'; }
if ($filter_to)     { $where[] = 'al.created_at <= ?'; $params[] = $filter_to   . ' 23:59:59'; }
$ws = implode(' AND ', $where);

$total  = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM audit_log al WHERE $ws", $params)['c'] ?? 0);
$pages  = (int)ceil($total / $per_page);
$offset = ($page-1)*$per_page;

$logs = Database::fetchAll("
    SELECT al.*, u.full_name AS user_name, r.role_name
    FROM audit_log al
    LEFT JOIN users u ON al.user_id = u.user_id
    LEFT JOIN roles r ON u.role_id = r.role_id
    WHERE $ws ORDER BY al.created_at DESC, al.log_id DESC
    LIMIT $per_page OFFSET $offset", $params);

$users = Database::fetchAll("SELECT user_id, full_name FROM users ORDER BY full_name");
$actions = ['CREATE','READ','UPDATE','DELETE','LOGIN','LOGOUT','APPROVE','REJECT','EXPORT','SYSTEM'];
$tables  = Database::fetchAll("SELECT DISTINCT table_name FROM audit_log WHERE table_name IS NOT NULL ORDER BY table_name");

$action_colors = ['CREATE'=>'badge-success','UPDATE'=>'badge-info','DELETE'=>'badge-danger','LOGIN'=>'badge-info','LOGOUT'=>'badge-muted','APPROVE'=>'badge-purple','REJECT'=>'badge-warning','EXPORT'=>'badge-secondary','SYSTEM'=>'badge-muted','READ'=>'badge-secondary'];

require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Audit Log</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-shield-halved"></i></div><div><h1>Audit Log</h1><p class="text-sm text-muted">Complete system activity trail</p></div><span class="count-badge"><?=$total?></span></div>
    <div class="page-actions"><button class="btn btn-ghost" data-export-csv="mainTable" data-filename="audit-log-<?=date('Y-m-d')?>.csv"><i class="fa-solid fa-file-csv"></i> Export</button></div>
</div>
<div class="glass-card no-hover">
<form method="GET"><div class="filter-bar">
    <div class="form-group"><label>Action</label><select name="action"><option value="">All</option><?php foreach($actions as $a): ?><option value="<?=$a?>" <?=$filter_action===$a?'selected':''?>><?=$a?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Table</label><select name="table_name"><option value="">All</option><?php foreach($tables as $t): ?><option value="<?=e($t['table_name'])?>" <?=$filter_table===$t['table_name']?'selected':''?>><?=e($t['table_name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>User</label><select name="user_id"><option value="0">All</option><?php foreach($users as $u): ?><option value="<?=(int)$u['user_id']?>" <?=$filter_user===(int)$u['user_id']?'selected':''?>><?=e($u['full_name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>From</label><input type="date" name="date_from" value="<?=e($filter_from)?>"></div>
    <div class="form-group"><label>To</label><input type="date" name="date_to" value="<?=e($filter_to)?>"></div>
    <div class="form-group"><label>&nbsp;</label><div class="btn-group"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button><a href="<?=base_url('/pages/audit_log.php')?>" class="btn btn-ghost btn-sm">Clear</a></div></div>
</div></form>
<div class="table-wrap">
<?php if($logs): ?>
<table id="mainTable">
    <thead><tr><th>Timestamp</th><th>User</th><th>Role</th><th>Action</th><th>Table</th><th>Record ID</th><th>IP Address</th><th class="no-export">Details</th></tr></thead>
    <tbody>
    <?php foreach($logs as $log): ?>
    <tr class="audit-row" data-log-id="<?=(int)$log['log_id']?>">
        <td class="td-mono text-muted text-sm"><?=fmt_datetime($log['created_at'])?></td>
        <td style="font-size:.85rem;"><?=e($log['user_name']??'System')?></td>
        <td><?php if($log['role_name']): ?><span class="badge badge-muted text-xs"><?=e(ucfirst($log['role_name']))?></span><?php else: ?>—<?php endif; ?></td>
        <td><span class="badge <?=$action_colors[$log['action']]??'badge-secondary'?>"><?=e($log['action'])?></span></td>
        <td class="td-mono text-sm"><?=e($log['table_name']??'—')?></td>
        <td class="td-mono text-muted"><?=$log['record_id']?'#'.$log['record_id']:'—'?></td>
        <td class="td-mono text-xs text-muted"><?=e($log['ip_address']??'—')?></td>
        <td class="no-export"><button class="btn btn-ghost btn-xs" onclick="toggleDiff(<?=(int)$log['log_id']?>)"><i class="fa-solid fa-eye"></i> View</button></td>
    </tr>
    <tr id="diff-<?=(int)$log['log_id']?>" class="diff-row" style="display:none;">
        <td colspan="8" style="background:rgba(0,212,255,0.03);padding:16px 20px;">
            <?php if($log['notes']): ?><div class="mb-2"><strong class="text-sm">Notes:</strong> <span class="text-sm text-secondary"><?=e($log['notes'])?></span></div><?php endif; ?>
            <div class="detail-grid" style="grid-template-columns:1fr 1fr;gap:16px;">
                <div>
                    <div class="text-xs text-muted mb-1" style="text-transform:uppercase;letter-spacing:.05em;">Old Values</div>
                    <pre style="background:rgba(255,45,85,0.05);border:1px solid rgba(255,45,85,0.15);border-radius:8px;padding:10px 14px;font-size:.78rem;color:#ff8fa3;overflow-x:auto;margin:0;"><?=$log['old_values']?e(json_encode(json_decode($log['old_values']),JSON_PRETTY_PRINT)):'—'?></pre>
                </div>
                <div>
                    <div class="text-xs text-muted mb-1" style="text-transform:uppercase;letter-spacing:.05em;">New Values</div>
                    <pre style="background:rgba(0,229,160,0.05);border:1px solid rgba(0,229,160,0.15);border-radius:8px;padding:10px 14px;font-size:.78rem;color:#7fffd4;overflow-x:auto;margin:0;"><?=$log['new_values']?e(json_encode(json_decode($log['new_values']),JSON_PRETTY_PRINT)):'—'?></pre>
                </div>
            </div>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php else: ?>
<div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-shield-halved"></i></div><div class="empty-title">No Log Entries</div><div class="empty-message">No audit records match your filters.</div></div>
<?php endif; ?>
</div>
<?php if($pages>1): ?><div class="pagination"><?php if($page>1): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page-1]))?>" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?><?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$p]))?>" class="page-btn <?=$p===$page?'active':''?>"><?=$p?></a><?php endfor; ?><?php if($page<$pages): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page+1]))?>" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?><span class="pagination-info"><?=$total?> records</span></div><?php endif; ?>
</div>
<script>
function toggleDiff(id) {
    const row = document.getElementById('diff-'+id);
    row.style.display = row.style.display === 'none' ? 'table-row' : 'none';
}
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
