<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','auditor']);
$page_title='Compatibility Matches';
$filter_result=trim($_GET['review_result']??''); $filter_score=trim($_GET['min_score']??'');
$page=max(1,(int)($_GET['page']??1)); $per_page=20;
$where=['1=1']; $params=[];
if($filter_result){$where[]='cm.review_result=?';$params[]=$filter_result;}
if($filter_score){$where[]='cm.match_score>=?';$params[]=decimal_value($filter_score)??0.0;}
$ws=implode(' AND ',$where);
$total=(int)(Database::fetchOne("SELECT COUNT(*) AS c FROM compatibility_matches cm WHERE $ws",$params)['c']??0);
$pages=(int)ceil($total/$per_page); $offset=($page-1)*$per_page;
$matches=Database::fetchAll("
    SELECT cm.*,d.name AS donor_name,d.blood_group AS donor_blood,d.city AS donor_city,
           r.name AS recipient_name,r.blood_group AS recipient_blood,r.urgency_level,
           u.full_name AS reviewer_name
    FROM compatibility_matches cm
    JOIN donors d ON cm.donor_id=d.donor_id
    JOIN recipients r ON cm.recipient_id=r.recipient_id
    LEFT JOIN users u ON cm.reviewed_by=u.user_id
    WHERE $ws ORDER BY cm.match_id DESC LIMIT $per_page OFFSET $offset",$params);
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Matches</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-dna"></i></div><div><h1>Compatibility Matches</h1><p class="text-sm text-muted">Donor-recipient match management</p></div><span class="count-badge"><?=$total?></span></div>
    <div class="page-actions"><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/matches/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Create Match</a><?php endif; ?></div>
</div>
<div class="glass-card no-hover">
<form method="GET"><div class="filter-bar">
    <div class="form-group"><label>Result</label><select name="review_result"><option value="">All</option><?php foreach(['Pending','Approved','Rejected'] as $r): ?><option value="<?=$r?>" <?=$filter_result===$r?'selected':''?>><?=$r?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Min Score</label><input type="number" name="min_score" value="<?=e($filter_score)?>" min="0" max="100" step="0.0000000001" placeholder="e.g. 70.0000000000"></div>
    <div class="form-group"><label>&nbsp;</label><div class="btn-group"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button><a href="<?=base_url('/pages/matches/index.php')?>" class="btn btn-ghost btn-sm">Clear</a></div></div>
</div></form>
<div class="table-wrap"><?php if($matches): ?>
<table id="mainTable"><thead><tr><th>#</th><th>Donor</th><th>Recipient</th><th>Score</th><th>Crossmatch</th><th>Status</th><th>Date</th><th class="no-export">Actions</th></tr></thead><tbody>
<?php foreach($matches as $m): ?>
<tr>
    <td class="td-mono text-muted">#<?=(int)$m['match_id']?></td>
    <td><div style="font-weight:600;font-size:.85rem;"><?=e($m['donor_name'])?></div><div class="text-xs text-muted"><?=e($m['donor_blood'])?> &bull; <?=e($m['donor_city'])?></div></td>
    <td><div style="font-weight:600;font-size:.85rem;"><?=e($m['recipient_name'])?></div><div class="text-xs"><span class="badge <?=status_class($m['urgency_level'])?> text-xs"><?=e($m['urgency_level'])?></span></div></td>
    <td><div data-score-ring="<?=e(fmt_decimal10($m['match_score']))?>" style="width:46px;height:46px;position:relative;"></div></td>
    <td><span class="badge <?=$m['crossmatch_result']==='Negative'?'badge-success':($m['crossmatch_result']==='Positive'?'badge-danger':'badge-warning')?>"><?=e($m['crossmatch_result'])?></span></td>
    <td><span class="badge <?=status_class($m['review_result'])?>"><?=e($m['review_result'])?></span><?=$m['is_ai_suggested']?'<span class="badge badge-purple text-xs" style="margin-left:4px;"><i class="fa-solid fa-robot"></i> AI</span>':''?></td>
    <td class="td-mono text-muted"><?=fmt_date($m['match_date'])?></td>
    <td class="no-export"><div class="btn-group">
        <a href="<?=base_url('/pages/matches/review.php?id='.(int)$m['match_id'])?>" class="btn btn-info btn-xs" title="Review"><i class="fa-solid fa-eye"></i></a>
        <?php if(has_role(['superadmin','admin']) && $m['review_result']==='Pending' && (int)($m['is_eligible']??0)===1): ?>
        <button class="btn btn-success btn-xs" onclick="quickApprove(<?=(int)$m['match_id']?>)" title="Approve"><i class="fa-solid fa-check"></i></button>
        <?php endif; ?>
        <?php if(has_role(['superadmin','admin'])): ?>
        <button class="btn btn-danger btn-xs" data-delete="<?=base_url('/pages/matches/delete.php')?>" data-id="<?=(int)$m['match_id']?>" data-msg="Delete match #<?=(int)$m['match_id']?>?"><i class="fa-solid fa-trash-can"></i></button>
        <?php endif; ?>
    </div></td>
</tr>
<?php endforeach; ?>
</tbody></table>
<?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-dna"></i></div><div class="empty-title">No Matches Found</div><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/matches/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Create First Match</a><?php endif; ?></div><?php endif; ?>
</div>
<?php if($pages>1): ?><div class="pagination"><?php if($page>1): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page-1]))?>" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?><?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$p]))?>" class="page-btn <?=$p===$page?'active':''?>"><?=$p?></a><?php endfor; ?><?php if($page<$pages): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page+1]))?>" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?><span class="pagination-info"><?=$total?> records</span></div><?php endif; ?>
</div>
<form id="approveForm" method="POST" action="<?=base_url('/pages/matches/review.php')?>" style="display:none;">
    <?=csrf_field()?>
    <input type="hidden" name="match_id" id="approveMatchId">
    <input type="hidden" name="action" value="approve">
    <input type="hidden" name="review_notes" value="Quick-approved from match list">
</form>
<script>
function quickApprove(id) {
    if(!confirm('Approve match #'+id+'?')) return;
    document.getElementById('approveMatchId').value = id;
    document.getElementById('approveForm').submit();
}
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
