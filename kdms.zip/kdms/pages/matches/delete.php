<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin']);
if($_SERVER['REQUEST_METHOD']!=='POST'){redirect('/pages/matches/index.php');}
csrf_verify();
$id=(int)($_POST['id']??0);
$m=Database::fetchOne("SELECT match_id,review_result FROM compatibility_matches WHERE match_id=?",[$id]);
if(!$m){flash('danger','Not found.');redirect('/pages/matches/index.php');}
try{
    Database::execute("DELETE FROM compatibility_matches WHERE match_id=?",[$id]);
    log_action('DELETE','compatibility_matches',$id,['match_id'=>$id,'review_result'=>$m['review_result']]);
    flash('success',"Match #{$id} deleted.");
}catch(PDOException $e){
    if(str_contains($e->getMessage(),'foreign key') || str_contains($e->getMessage(),'a foreign key constraint fails')) {
        flash('danger','Cannot delete: this match has an associated transplant record.');
    } else {
        flash('danger','Error: '.$e->getMessage());
    }
}
redirect('/pages/matches/index.php');
