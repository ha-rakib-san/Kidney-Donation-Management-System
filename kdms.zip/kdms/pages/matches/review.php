<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin','doctor']);

$id = (int)($_GET['id'] ?? $_POST['match_id'] ?? 0);
if (!$id) { flash('danger','Invalid match ID.'); redirect('/pages/matches/index.php'); }

// Handle approve/reject POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    require_role(['superadmin','admin']); // only admin+ can approve/reject
    $action = trim($_POST['action'] ?? '');
    $notes  = trim($_POST['review_notes'] ?? '');

    if ($action === 'approve') {
        try {
            $ok = Procedures::approveMatch($id, current_user()['user_id'], $notes);
            if ($ok) {
                flash('success', "Match #{$id} approved successfully.");
            } else {
                flash('danger', "Could not approve: match is not in Pending status.");
            }
        } catch (Throwable $e) {
            flash('danger', 'Could not approve: ' . $e->getMessage());
        }
    } elseif ($action === 'reject') {
        try {
            Procedures::rejectMatch($id, current_user()['user_id'], $notes);
            flash('warning', "Match #{$id} rejected.");
        } catch (Throwable $e) {
            flash('danger', 'Could not reject: ' . $e->getMessage());
        }
    }
    redirect('/pages/matches/index.php');
}

Procedures::recalculateMatch($id);

$match = Database::fetchOne("
    SELECT cm.*,
           d.donor_id, d.name AS donor_name, d.blood_group AS donor_blood, d.city AS donor_city, d.donor_type, d.gender AS donor_gender, d.contact AS donor_contact,
           r.recipient_id, r.name AS recipient_name, r.blood_group AS recipient_blood, r.city AS recipient_city, r.urgency_level, r.contact AS recipient_contact,
           u.full_name AS reviewer_name
    FROM compatibility_matches cm
    JOIN donors d ON cm.donor_id=d.donor_id
    JOIN recipients r ON cm.recipient_id=r.recipient_id
    LEFT JOIN users u ON cm.reviewed_by=u.user_id
    WHERE cm.match_id=?", [$id]);

if (!$match) { flash('danger','Match not found.'); redirect('/pages/matches/index.php'); }
$scoreDetail = json_decode((string)($match['score_detail_json'] ?? ''), true) ?: [];
$hardStops = is_array($scoreDetail['hard_stops'] ?? null) ? $scoreDetail['hard_stops'] : [];
$warnings = is_array($scoreDetail['warnings'] ?? null) ? $scoreDetail['warnings'] : [];
$missingFields = is_array($scoreDetail['missing_fields'] ?? null) ? $scoreDetail['missing_fields'] : [];
$isEligible = (int)($match['is_eligible'] ?? 0) === 1;
$mainComponents = [
    ['Blood Group', 'blood_score', 15.0, '#00D4FF'],
    ['Distance', 'location_score', 20.0, '#00E5A0'],
    ['Crossmatch', 'crossmatch_score', 20.0, '#FFB800'],
    ['HLA Tissue', 'hla_score', 15.0, '#8B5CF6'],
    ['Medical Profile', 'medical_score', 30.0, '#FF4D8D'],
];
$medicalComponents = [
    ['Age difference', 'age_score', 3.0], ['BMI', 'bmi_score', 3.0],
    ['Creatinine', 'creatinine_score', 4.0], ['GFR', 'gfr_score', 5.0],
    ['Blood pressure', 'blood_pressure_score', 3.0], ['Hemoglobin', 'hemoglobin_score', 3.0],
    ['Diabetes', 'diabetes_score', 2.0], ['Hypertension', 'hypertension_score', 2.0],
    ['PRA / cPRA', 'pra_score', 5.0],
];

$page_title = 'Review Match #' . $id;
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/matches/index.php')?>">Matches</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Review #<?=$id?></span></div>

<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-dna"></i></div><div><h1>Match #<?=$id?></h1><div class="d-flex gap-2 mt-1"><span class="badge <?=status_class($match['review_result'])?>"><?=e($match['review_result'])?></span><?=$match['is_ai_suggested']?'<span class="badge badge-purple"><i class="fa-solid fa-robot"></i> AI Suggested</span>':''?></div></div></div>
    <div class="page-actions"><a href="<?=base_url('/pages/matches/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>

<!-- Score Display -->
<div class="glass-card no-hover compat-panel mb-4">
    <div class="card-header"><h3>Precision Compatibility Score, <?=e($match['score_version'] ?? 'KDMS-2.0')?></h3></div>
    <div class="card-body">
        <div class="compat-score-main glass-card no-hover">
            <div class="compat-score-value" style="font-size:2.2rem;color:<?= $match['match_score']>=85?'#00D4FF':($match['match_score']>=70?'#00E5A0':($match['match_score']>=50?'#FFB800':'#FF2D55')) ?>;"><?=fmt_decimal10($match['match_score'])?></div>
            <div class="compat-score-label"><?= $isEligible ? 'Eligible for clinical review' : 'Not eligible for approval' ?></div>
            <div class="text-xs text-muted mt-1">All stored and displayed score values use 10 decimal places.</div>
        </div>
        <div class="compat-breakdown">
            <?php foreach($mainComponents as [$label,$field,$max,$color]): $value=(float)($match[$field]??0); $width=max(0,min(100,($value/$max)*100)); ?>
            <div class="compat-bar-row"><span class="compat-bar-label"><?=e($label)?></span><div class="compat-bar-track"><div class="compat-bar-fill" style="width:<?=$width?>%;background:<?=$color?>;"></div></div><span class="compat-bar-pts"><?=fmt_decimal10($value)?>/<?=fmt_decimal10($max)?></span></div>
            <?php endforeach; ?>
        </div>
        <div class="detail-grid mt-4">
            <div class="glass-card no-hover"><div class="card-header"><h3>Medical subscore, 30 points</h3></div><div class="card-body"><div class="detail-section">
                <?php foreach($medicalComponents as [$label,$field,$max]): ?><div class="detail-row"><span class="detail-label"><?=e($label)?></span><span class="detail-value td-mono"><?=fmt_decimal10($match[$field]??0)?> / <?=fmt_decimal10($max)?></span></div><?php endforeach; ?>
            </div></div></div>
            <div class="glass-card no-hover"><div class="card-header"><h3>Derived measurements</h3></div><div class="card-body"><div class="detail-section">
                <div class="detail-row"><span class="detail-label">Distance</span><span class="detail-value td-mono"><?=$match['distance_km']!==null?fmt_decimal10($match['distance_km']).' km':'Coordinates unavailable'?></span></div>
                <div class="detail-row"><span class="detail-label">Age difference</span><span class="detail-value td-mono"><?=$match['age_difference_years']!==null?fmt_decimal10($match['age_difference_years']).' years':'Unavailable'?></span></div>
                <div class="detail-row"><span class="detail-label">Data completeness</span><span class="detail-value td-mono"><?=fmt_decimal10($match['data_completeness']??0)?>%</span></div>
                <div class="detail-row"><span class="detail-label">Crossmatch</span><span class="detail-value"><span class="badge <?=($match['crossmatch_result']??'Pending')==='Negative'?'badge-success':(($match['crossmatch_result']??'Pending')==='Positive'?'badge-danger':'badge-warning')?>"><?=e($match['crossmatch_result']??'Pending')?></span></span></div>
                <div class="detail-row"><span class="detail-label">Eligibility</span><span class="detail-value"><span class="badge <?=$isEligible?'badge-success':'badge-danger'?>"><?=$isEligible?'Eligible':'Blocked'?></span></span></div>
            </div></div></div>
        </div>
        <?php if($hardStops): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-top:18px;"><span class="flash-icon"><i class="fa-solid fa-ban"></i></span><div><strong>Hard stops</strong><?php foreach($hardStops as $item): ?><div><?=e((string)$item)?></div><?php endforeach; ?></div></div><?php endif; ?>
        <?php if($warnings): ?><div class="flash-message flash-warning" style="position:relative;top:0;right:0;margin-top:12px;"><span class="flash-icon"><i class="fa-solid fa-triangle-exclamation"></i></span><div><strong>Clinical warnings</strong><?php foreach($warnings as $item): ?><div><?=e((string)$item)?></div><?php endforeach; ?></div></div><?php endif; ?>
        <?php if($missingFields): ?><div class="text-sm text-muted mt-3"><strong>Missing inputs:</strong> <?=e(implode(', ',array_map('strval',$missingFields)))?></div><?php endif; ?>
    </div>
</div>

<div class="detail-grid mb-4">
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-heart-pulse text-cyan" style="margin-right:8px;"></i>Donor</h3></div>
        <div class="card-body"><div class="detail-section">
            <div class="detail-row"><span class="detail-label">Name</span><span class="detail-value"><a href="<?=base_url('/pages/donors/view.php?id='.(int)$match['donor_id'])?>" class="text-cyan"><?=e($match['donor_name'])?></a></span></div>
            <div class="detail-row"><span class="detail-label">Blood Group</span><span class="detail-value"><span class="badge bg-<?=str_replace(['+','-'],['pos','neg'],$match['donor_blood'])?>"><?=e($match['donor_blood'])?></span></span></div>
            <div class="detail-row"><span class="detail-label">City</span><span class="detail-value"><?=e($match['donor_city'])?></span></div>
            <div class="detail-row"><span class="detail-label">Type</span><span class="detail-value"><?=e($match['donor_type'])?></span></div>
            <div class="detail-row"><span class="detail-label">Contact</span><span class="detail-value"><?=e($match['donor_contact']??'—')?></span></div>
            <div class="detail-row"><span class="detail-label">HLA Type</span><span class="detail-value td-mono"><?=e($match['tissue_hla_donor']??'—')?></span></div>
        </div></div>
    </div>
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-bed-pulse text-red" style="margin-right:8px;"></i>Recipient</h3></div>
        <div class="card-body"><div class="detail-section">
            <div class="detail-row"><span class="detail-label">Name</span><span class="detail-value"><a href="<?=base_url('/pages/recipients/view.php?id='.(int)$match['recipient_id'])?>" class="text-cyan"><?=e($match['recipient_name'])?></a></span></div>
            <div class="detail-row"><span class="detail-label">Blood Group</span><span class="detail-value"><span class="badge bg-<?=str_replace(['+','-'],['pos','neg'],$match['recipient_blood'])?>"><?=e($match['recipient_blood'])?></span></span></div>
            <div class="detail-row"><span class="detail-label">City</span><span class="detail-value"><?=e($match['recipient_city'])?></span></div>
            <div class="detail-row"><span class="detail-label">Urgency</span><span class="detail-value"><span class="badge <?=status_class($match['urgency_level'])?>"><?=e($match['urgency_level'])?></span></span></div>
            <div class="detail-row"><span class="detail-label">Contact</span><span class="detail-value"><?=e($match['recipient_contact']??'—')?></span></div>
            <div class="detail-row"><span class="detail-label">HLA Type</span><span class="detail-value td-mono"><?=e($match['tissue_hla_recipient']??'—')?></span></div>
        </div></div>
    </div>
</div>

<?php if ($match['review_result'] !== 'Pending'): ?>
<div class="glass-card no-hover mb-4"><div class="card-body">
    <div class="detail-row"><span class="detail-label">Reviewed By</span><span class="detail-value"><?=e($match['reviewer_name']??'—')?></span></div>
    <div class="detail-row"><span class="detail-label">Reviewed At</span><span class="detail-value td-mono"><?=fmt_datetime($match['reviewed_at'])?></span></div>
    <?php if($match['review_notes']): ?><div class="detail-row"><span class="detail-label">Notes</span><span class="detail-value"><?=e($match['review_notes'])?></span></div><?php endif; ?>
</div></div>
<?php endif; ?>

<?php if ($match['review_result'] === 'Pending' && has_role(['superadmin','admin'])): ?>
<div class="glass-card no-hover">
    <div class="card-header"><h3><i class="fa-solid fa-clipboard-check text-gold" style="margin-right:8px;"></i>Review Decision</h3></div>
    <div class="card-body">
        <form method="POST" id="reviewForm">
            <?=csrf_field()?>
            <input type="hidden" name="match_id" value="<?=$id?>">
            <div class="form-group mb-3">
                <label>Review Notes</label>
                <textarea name="review_notes" rows="3" placeholder="Add clinical notes or justification for this decision…"></textarea>
            </div>
            <div class="d-flex gap-3" style="justify-content:flex-end;">
                <button type="submit" name="action" value="reject" class="btn btn-danger"><i class="fa-solid fa-xmark"></i> Reject Match</button>
                <button type="submit" name="action" value="approve" class="btn btn-success" <?=$isEligible?'':'disabled title="Resolve hard stops before approval"'?>> <i class="fa-solid fa-check"></i> Approve Match</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
