<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin','doctor']);
$page_title='Create Match'; $include_compatibility=true; $errors=[];

$donors    = Database::fetchAll("SELECT donor_id,name,blood_group,city FROM donors WHERE status='Available' ORDER BY name");
$recipients= Database::fetchAll("SELECT recipient_id,name,blood_group,city,urgency_level FROM recipients WHERE wait_status='Waiting' ORDER BY CASE urgency_level WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END, name");

if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_verify();
    $donor_id = (int)($_POST['donor_id'] ?? 0);
    $recip_id = (int)($_POST['recipient_id'] ?? 0);

    if(!$donor_id) $errors[]='Please select a donor.';
    if(!$recip_id) $errors[]='Please select a recipient.';

    // Check existing pair
    if(!$errors){
        $exists = Database::fetchOne("SELECT match_id FROM compatibility_matches WHERE donor_id=? AND recipient_id=?",[$donor_id,$recip_id]);
        if($exists) $errors[]='A match between this donor and recipient already exists.';
    }

    if(!$errors){
        try{
            $id = Procedures::createCompatibilityMatch($donor_id, $recip_id, false);
            log_action('CREATE','compatibility_matches',(int)$id,null,['donor_id'=>$donor_id,'recipient_id'=>$recip_id]);
            flash('success',"Match #{$id} created. Compatibility score calculated automatically.");
            redirect('/pages/matches/review.php?id='.$id);
        }catch(PDOException $e){
            if(str_contains($e->getMessage(),'Cannot match')) {
                $errors[] = 'Cannot create match: donor or recipient is not in an eligible status.';
            } else {
                $errors[] = 'Database error: '.$e->getMessage();
            }
        }
    }
}
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/matches/index.php')?>">Matches</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Create Match</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-dna"></i></div><div><h1>Create Compatibility Match</h1><p class="text-sm text-muted">Select a donor and recipient to compute live compatibility</p></div></div>
    <div class="page-actions"><a href="<?=base_url('/pages/matches/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>

<div class="detail-grid mb-4">
    <!-- Donor / Recipient Selectors -->
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-heart-pulse text-cyan" style="margin-right:8px;"></i>Select Donor</h3></div>
        <div class="card-body">
            <div class="form-group">
                <label>Available Donor <span class="req">*</span></label>
                <select id="donorSelect" name="donor_id_display" style="font-size:.95rem;">
                    <option value="">— Choose a donor —</option>
                    <?php foreach($donors as $d): ?>
                    <option value="<?=(int)$d['donor_id']?>"><?=e($d['name'])?> — <?=e($d['blood_group'])?> — <?=e($d['city'])?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <p class="text-sm text-muted mt-2"><i class="fa-solid fa-circle-info"></i> Only <strong>Available</strong> donors are shown.</p>
        </div>
    </div>
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-bed-pulse text-red" style="margin-right:8px;"></i>Select Recipient</h3></div>
        <div class="card-body">
            <div class="form-group">
                <label>Waiting Recipient <span class="req">*</span></label>
                <select id="recipientSelect" name="recipient_id_display" style="font-size:.95rem;">
                    <option value="">— Choose a recipient —</option>
                    <?php foreach($recipients as $r): ?>
                    <option value="<?=(int)$r['recipient_id']?>"><?=e($r['name'])?> — <?=e($r['blood_group'])?> — <?=e($r['urgency_level'])?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <p class="text-sm text-muted mt-2"><i class="fa-solid fa-circle-info"></i> Sorted by urgency — Critical patients shown first.</p>
        </div>
    </div>
</div>

<!-- Live Score Panel -->
<div class="glass-card no-hover compat-panel" id="compatScorePanel" style="display:none;">
    <div class="card-header"><h3><i class="fa-solid fa-chart-simple text-purple" style="margin-right:8px;"></i>Live Compatibility Score</h3><span id="crossmatchResultBadge" class="badge badge-muted">—</span></div>
    <div class="card-body">
        <div class="compat-score-main glass-card no-hover">
            <div class="compat-score-value" id="compatScoreValue">—</div>
            <div class="compat-score-label" id="compatScoreLabel">Select donor and recipient</div>
        </div>
        <div class="compat-breakdown">
            <div class="compat-bar-row"><span class="compat-bar-label">ABO Blood</span><div class="compat-bar-track"><div class="compat-bar-fill" id="scoreBarBlood" style="width:0%;"></div></div><span class="compat-bar-pts" id="scoreBloodPts">0.0000000000/15</span></div>
            <div class="compat-bar-row"><span class="compat-bar-label">Distance</span><div class="compat-bar-track"><div class="compat-bar-fill" id="scoreBarLoc" style="width:0%;"></div></div><span class="compat-bar-pts" id="scoreLocPts">0.0000000000/20</span></div>
            <div class="compat-bar-row"><span class="compat-bar-label">Crossmatch</span><div class="compat-bar-track"><div class="compat-bar-fill" id="scoreBarCross" style="width:0%;"></div></div><span class="compat-bar-pts" id="scoreCrossPts">0.0000000000/20</span></div>
            <div class="compat-bar-row"><span class="compat-bar-label">HLA Similarity</span><div class="compat-bar-track"><div class="compat-bar-fill" id="scoreBarHLA" style="width:0%;"></div></div><span class="compat-bar-pts" id="scoreHLAPts">0.0000000000/15</span></div>
            <div class="compat-bar-row"><span class="compat-bar-label">Medical Profile</span><div class="compat-bar-track"><div class="compat-bar-fill" id="scoreBarMedical" style="width:0%;"></div></div><span class="compat-bar-pts" id="scoreMedicalPts">0.0000000000/30</span></div>
        </div>
        <div class="mt-4" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:10px;" id="medicalComponentGrid">
            <div class="glass-card no-hover" style="padding:12px;"><div class="text-xs text-muted">Age Difference</div><strong class="text-mono" id="scoreAgePts">0.0000000000/3</strong></div>
            <div class="glass-card no-hover" style="padding:12px;"><div class="text-xs text-muted">BMI</div><strong class="text-mono" id="scoreBmiPts">0.0000000000/3</strong></div>
            <div class="glass-card no-hover" style="padding:12px;"><div class="text-xs text-muted">Creatinine</div><strong class="text-mono" id="scoreCreatininePts">0.0000000000/4</strong></div>
            <div class="glass-card no-hover" style="padding:12px;"><div class="text-xs text-muted">GFR</div><strong class="text-mono" id="scoreGfrPts">0.0000000000/5</strong></div>
            <div class="glass-card no-hover" style="padding:12px;"><div class="text-xs text-muted">Blood Pressure</div><strong class="text-mono" id="scoreBpPts">0.0000000000/3</strong></div>
            <div class="glass-card no-hover" style="padding:12px;"><div class="text-xs text-muted">Hemoglobin</div><strong class="text-mono" id="scoreHemoglobinPts">0.0000000000/3</strong></div>
            <div class="glass-card no-hover" style="padding:12px;"><div class="text-xs text-muted">Diabetes</div><strong class="text-mono" id="scoreDiabetesPts">0.0000000000/2</strong></div>
            <div class="glass-card no-hover" style="padding:12px;"><div class="text-xs text-muted">Hypertension</div><strong class="text-mono" id="scoreHypertensionPts">0.0000000000/2</strong></div>
            <div class="glass-card no-hover" style="padding:12px;"><div class="text-xs text-muted">PRA</div><strong class="text-mono" id="scorePraPts">0.0000000000/5</strong></div>
        </div>
        <div id="compatMetadata" class="mt-3 text-sm text-muted"></div>
        <div id="compatWarnings" class="mt-3"></div>
    </div>
    <div class="card-footer">
        <form method="POST" id="matchForm">
            <?=csrf_field()?>
            <input type="hidden" name="donor_id" id="hiddenDonorId">
            <input type="hidden" name="recipient_id" id="hiddenRecipId">
            <button type="submit" class="btn btn-primary w-full" id="matchSubmitBtn" disabled style="opacity:.4;">
                <i class="fa-solid fa-floppy-disk"></i> Create This Match
            </button>
        </form>
    </div>
</div>

<script>
// Sync visible selects to hidden form fields expected by compatibility.js
const donorSelect = document.getElementById('donorSelect');
const recipientSelect = document.getElementById('recipientSelect');
donorSelect.addEventListener('change', () => { document.getElementById('hiddenDonorId').value = donorSelect.value; });
recipientSelect.addEventListener('change', () => { document.getElementById('hiddenRecipId').value = recipientSelect.value; });
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
