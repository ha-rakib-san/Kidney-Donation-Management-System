<?php
/**
 * KDMS Pro — Dashboard
 * Real-time KPI stats, 3 Chart.js charts, critical cases panel
 */
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/scheduler.php';
require_role(['superadmin','admin','doctor','donor','recipient','auditor']);

// SQLite has no event scheduler — run any due maintenance jobs lazily here
// (daily waitlist reprioritization, weekly AI match suggestions, monthly
// cleanup, hourly stats caching). See includes/scheduler.php.
Scheduler::runDueJobs();

$page_title          = 'Dashboard';
$include_three_scene = true;
$include_dashboard_charts = true;

$user = current_user();
$role = current_role();

// ─── Fetch stats ──────────────────────────────────────────────────────────────
$stats = Database::fetchOne("
    SELECT
        (SELECT COUNT(*) FROM hospitals  WHERE is_active=1)          AS total_hospitals,
        (SELECT COUNT(*) FROM doctors    WHERE is_active=1)          AS total_doctors,
        (SELECT COUNT(*) FROM donors     WHERE status='Available')   AS available_donors,
        (SELECT COUNT(*) FROM donors)                                 AS total_donors,
        (SELECT COUNT(*) FROM donors     WHERE status='Unavailable') AS unavailable_donors,
        (SELECT COUNT(*) FROM donors     WHERE status='Transplanted') AS transplanted_donors,
        (SELECT COUNT(*) FROM donors     WHERE status='Suspended')   AS suspended_donors,
        (SELECT COUNT(*) FROM recipients WHERE wait_status='Waiting') AS waiting_recipients,
        (SELECT COUNT(*) FROM recipients)                             AS total_recipients,
        (SELECT COUNT(*) FROM medical_tests WHERE is_valid=1)        AS total_tests,
        (SELECT COUNT(*) FROM compatibility_matches)                  AS total_matches,
        (SELECT COUNT(*) FROM compatibility_matches WHERE review_result='Approved') AS approved_matches,
        (SELECT COUNT(*) FROM compatibility_matches WHERE review_result='Pending')  AS pending_matches,
        (SELECT COUNT(*) FROM transplants)                            AS total_transplants,
        (SELECT COUNT(*) FROM transplants WHERE result='Successful')  AS successful_transplants,
        (SELECT COUNT(*) FROM transplants WHERE result='Ongoing')     AS ongoing_transplants,
        (SELECT COUNT(*) FROM follow_ups)                             AS total_followups,
        (SELECT COUNT(*) FROM recipients WHERE urgency_level='Critical' AND wait_status='Waiting') AS critical_recipients,
        (SELECT ROUND(COUNT(*)*100.0/NULLIF((SELECT COUNT(*) FROM transplants WHERE result IN ('Successful','Failed')),0),1)
         FROM transplants WHERE result='Successful')                  AS success_rate
") ?? [];

// ─── Self-service: restrict to own data ──────────────────────────────────────
$selfDonorId     = null;
$selfRecipientId = null;
$selfMatchCount  = 0;
$selfTestCount   = 0;
$selfWaitPos     = null;

if ($role === 'donor' && $user['linked_id']) {
    $selfDonorId    = (int)$user['linked_id'];
    $selfMatchCount = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM compatibility_matches WHERE donor_id=?", [$selfDonorId])['c'] ?? 0);
    $selfTestCount  = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM medical_tests WHERE person_id=? AND person_type='Donor'", [$selfDonorId])['c'] ?? 0);
}
if ($role === 'recipient' && $user['linked_id']) {
    $selfRecipientId = (int)$user['linked_id'];
    $selfMatchCount  = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM compatibility_matches WHERE recipient_id=?", [$selfRecipientId])['c'] ?? 0);
    $selfTestCount   = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM medical_tests WHERE person_id=? AND person_type='Recipient'", [$selfRecipientId])['c'] ?? 0);
    $selfWaitPos     = Database::fetchOne("SELECT queue_position FROM waitlist_queue WHERE recipient_id=?", [$selfRecipientId]);
}

// ─── Monthly trend data (last 12 months) ──────────────────────────────────────
$monthlyRaw = Database::fetchAll("
    SELECT yr, mo, month_label, new_transplants AS transplants, new_matches AS matches
    FROM v_monthly_trends
    ORDER BY yr ASC, mo ASC
    LIMIT 12
");
$monthLabels     = array_column($monthlyRaw, 'month_label');
$monthTransplants = array_column($monthlyRaw, 'transplants');
$monthMatches    = array_column($monthlyRaw, 'matches');

// ─── Blood group distribution ──────────────────────────────────────────────────
$bloodGroups = ['A+','A-','B+','B-','O+','O-','AB+','AB-'];
$bloodDonors = $bloodRecips = [];
foreach ($bloodGroups as $bg) {
    $bloodDonors[] = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM donors WHERE blood_group=?", [$bg])['c'] ?? 0);
    $bloodRecips[]  = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM recipients WHERE blood_group=?", [$bg])['c'] ?? 0);
}

// ─── Critical cases ───────────────────────────────────────────────────────────
$criticalCases = ($role !== 'donor' && $role !== 'recipient')
    ? Database::fetchAll("SELECT * FROM v_critical_cases ORDER BY days_in_status DESC LIMIT 6")
    : [];

// ─── Recent matches ───────────────────────────────────────────────────────────
$recentMatches = ($role !== 'donor' && $role !== 'recipient')
    ? Database::fetchAll("
        SELECT cm.match_id, cm.match_score, cm.review_result, cm.match_date,
               d.name AS donor_name, d.blood_group AS donor_blood,
               r.name AS recipient_name, r.blood_group AS recipient_blood, r.urgency_level
        FROM compatibility_matches cm
        JOIN donors d ON cm.donor_id = d.donor_id
        JOIN recipients r ON cm.recipient_id = r.recipient_id
        ORDER BY cm.match_id DESC LIMIT 5")
    : [];

// ─── Recent transplants ───────────────────────────────────────────────────────
$recentTransplants = ($role !== 'donor' && $role !== 'recipient')
    ? Database::fetchAll("
        SELECT t.transplant_id, t.surgery_date, t.result,
               d.name AS donor_name, r.name AS recipient_name,
               doc.name AS doctor_name, h.name AS hospital_name
        FROM transplants t
        JOIN compatibility_matches cm ON t.match_id = cm.match_id
        JOIN donors d ON cm.donor_id = d.donor_id
        JOIN recipients r ON cm.recipient_id = r.recipient_id
        JOIN doctors doc ON t.doctor_id = doc.doctor_id
        LEFT JOIN hospitals h ON t.hospital_id = h.hospital_id
        ORDER BY t.transplant_id DESC LIMIT 5")
    : [];

// ─── Greeting ─────────────────────────────────────────────────────────────────
$hour = (int)date('H');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 17 ? 'Good afternoon' : 'Good evening');
$firstNameParts = explode(' ', $user['full_name']);
$firstName = $firstNameParts[0] ?? 'User';

// ─── Chart JSON ───────────────────────────────────────────────────────────────
$chartData = json_encode([
    'monthly'      => ['labels' => $monthLabels, 'transplants' => $monthTransplants, 'matches' => $monthMatches],
    'donor_status' => ['available' => $stats['available_donors'] ?? 0, 'unavailable' => $stats['unavailable_donors'] ?? 0, 'transplanted' => $stats['transplanted_donors'] ?? 0, 'suspended' => $stats['suspended_donors'] ?? 0],
    'blood_group'  => ['labels' => $bloodGroups, 'donors' => $bloodDonors, 'recipients' => $bloodRecips],
]);

require_once KDMS_ROOT . '/includes/header.php';
?>

<!-- Dashboard Canvas (behind content, subtle node graph) -->
<canvas id="dashboardCanvas" style="position:fixed;top:0;left:var(--sidebar-width);width:calc(100% - var(--sidebar-width));height:100vh;opacity:0.10;pointer-events:none;z-index:0;" aria-hidden="true"></canvas>

<div style="position:relative;z-index:1;">

<?php if ($role === 'donor' || $role === 'recipient'): ?>
<!-- ─── Self-Service Dashboard ─────────────────────────────────────────────── -->
<div class="greeting-banner glass-card no-hover mb-4">
    <div class="greeting-text">
        <h2><?= e($greeting) ?>, <?= e($firstName) ?> 👋</h2>
        <p><?= date('l, F j, Y') ?> &bull; <?= ucfirst(e($role)) ?> portal</p>
    </div>
</div>

<div class="stat-grid stagger-children" style="grid-template-columns:repeat(3,1fr);">
    <div class="glass-card stat-card">
        <div class="stat-icon icon-cyan"><i class="fa-solid fa-flask-vial"></i></div>
        <div class="stat-content">
            <div class="stat-value text-mono" data-count="<?= $selfTestCount ?>" id="kpi-tests"><?= $selfTestCount ?></div>
            <div class="stat-label">Medical Tests</div>
        </div>
    </div>
    <div class="glass-card stat-card">
        <div class="stat-icon icon-green"><i class="fa-solid fa-dna"></i></div>
        <div class="stat-content">
            <div class="stat-value text-mono" data-count="<?= $selfMatchCount ?>" id="kpi-matches"><?= $selfMatchCount ?></div>
            <div class="stat-label">Compatibility Matches</div>
        </div>
    </div>
    <?php if ($role === 'recipient' && $selfWaitPos): ?>
    <div class="glass-card stat-card">
        <div class="stat-icon icon-gold"><i class="fa-solid fa-list-ol"></i></div>
        <div class="stat-content">
            <div class="stat-value text-mono" style="color:var(--accent-gold);">#<?= (int)$selfWaitPos['queue_position'] ?></div>
            <div class="stat-label">Waitlist Position</div>
        </div>
    </div>
    <?php elseif ($role === 'donor'): ?>
    <div class="glass-card stat-card">
        <div class="stat-icon icon-purple"><i class="fa-solid fa-heart-pulse"></i></div>
        <div class="stat-content">
            <div class="stat-value text-mono" style="color:var(--accent-green);">Active</div>
            <div class="stat-label">Donor Status</div>
        </div>
    </div>
    <?php endif; ?>
</div>

<div class="glass-card no-hover mt-3 card-body text-center">
    <i class="fa-solid fa-<?= $role === 'donor' ? 'heart-pulse' : 'bed-pulse' ?>" style="font-size:2rem;color:var(--accent-cyan);margin-bottom:12px;"></i>
    <h3 style="margin-bottom:8px;">Your <?= ucfirst($role) ?> Portal</h3>
    <p style="max-width:460px;margin:0 auto 16px;">View your profile, medical tests, and match status using the sidebar navigation.</p>
    <a href="<?= base_url('/pages/profile.php') ?>" class="btn btn-primary">
        <i class="fa-solid fa-user-gear"></i> View My Profile
    </a>
</div>

<?php else: ?>
<!-- ─── Full Admin/Doctor/Auditor Dashboard ────────────────────────────────── -->

<!-- Greeting Banner -->
<div class="greeting-banner glass-card no-hover mb-4">
    <div class="greeting-text">
        <h2><?= e($greeting) ?>, <?= e($firstName) ?> <?= $stats['critical_recipients'] > 0 ? '⚠️' : '👋' ?></h2>
        <p>
            <?= date('l, F j, Y') ?>
            <?php if ($stats['critical_recipients'] > 0): ?>
            &bull; <span style="color:var(--accent-crimson);font-weight:600;"><?= (int)$stats['critical_recipients'] ?> Critical case<?= $stats['critical_recipients'] > 1 ? 's' : '' ?> need<?= $stats['critical_recipients'] == 1 ? 's' : '' ?> attention</span>
            <?php endif; ?>
        </p>
    </div>
    <div class="greeting-stats">
        <div>
            <div class="greeting-stat-value"><?= (int)($stats['critical_recipients'] ?? 0) ?></div>
            <div class="greeting-stat-label">Critical</div>
        </div>
        <div>
            <div class="greeting-stat-value" style="color:var(--accent-gold);"><?= (int)($stats['pending_matches'] ?? 0) ?></div>
            <div class="greeting-stat-label">Pending Review</div>
        </div>
        <div>
            <div class="greeting-stat-value" style="color:var(--accent-green);"><?= (int)($stats['ongoing_transplants'] ?? 0) ?></div>
            <div class="greeting-stat-label">Active Surgery</div>
        </div>
    </div>
</div>

<!-- KPI Grid -->
<div class="stat-grid stagger-children" id="kpiGrid">
    <?php
    $kpis = [
        ['id'=>'kpi-hospitals',   'icon'=>'fa-hospital',       'color'=>'icon-cyan',   'val'=>$stats['total_hospitals']??0,     'label'=>'Hospitals',          'sub'=>'Active centres'],
        ['id'=>'kpi-doctors',     'icon'=>'fa-user-doctor',    'color'=>'icon-green',  'val'=>$stats['total_doctors']??0,       'label'=>'Doctors',            'sub'=>'Active specialists'],
        ['id'=>'kpi-donors',      'icon'=>'fa-heart-pulse',    'color'=>'icon-cyan',   'val'=>$stats['available_donors']??0,    'label'=>'Available Donors',   'sub'=>'Ready to match'],
        ['id'=>'kpi-recipients',  'icon'=>'fa-bed-pulse',      'color'=>'icon-red',    'val'=>$stats['waiting_recipients']??0,  'label'=>'Waiting Recipients', 'sub'=>'On waitlist'],
        ['id'=>'kpi-tests',       'icon'=>'fa-flask-vial',     'color'=>'icon-blue',   'val'=>$stats['total_tests']??0,         'label'=>'Medical Tests',      'sub'=>'Records logged'],
        ['id'=>'kpi-matches',     'icon'=>'fa-dna',            'color'=>'icon-purple', 'val'=>$stats['total_matches']??0,       'label'=>'Total Matches',      'sub'=>($stats['approved_matches']??0).' approved'],
        ['id'=>'kpi-transplants', 'icon'=>'fa-scalpel',        'color'=>'icon-green',  'val'=>$stats['total_transplants']??0,   'label'=>'Transplants',        'sub'=>($stats['successful_transplants']??0).' successful'],
        ['id'=>'kpi-followups',   'icon'=>'fa-clipboard-list', 'color'=>'icon-gold',   'val'=>$stats['total_followups']??0,     'label'=>'Follow-Ups',         'sub'=>'Post-transplant'],
    ];
    foreach ($kpis as $kpi): ?>
    <div class="glass-card stat-card">
        <div class="stat-icon <?= e($kpi['color']) ?>"><i class="fa-solid <?= e($kpi['icon']) ?>"></i></div>
        <div class="stat-content">
            <div class="stat-value text-mono" data-count="<?= (int)$kpi['val'] ?>" id="<?= e($kpi['id']) ?>"><?= (int)$kpi['val'] ?></div>
            <div class="stat-label"><?= e($kpi['label']) ?></div>
            <div class="stat-trend up"><i class="fa-solid fa-circle-dot" style="font-size:.5rem;"></i> <?= e($kpi['sub']) ?></div>
        </div>
    </div>
    <?php endforeach; ?>
</div>

<!-- Charts Row -->
<div class="chart-grid mb-4">
    <div class="glass-card chart-card no-hover">
        <h3><i class="fa-solid fa-chart-line text-cyan" style="margin-right:6px;"></i> Monthly Transplant Trends</h3>
        <div class="chart-wrap" style="height:220px;"><canvas id="chartMonthlyTrends"></canvas></div>
    </div>
    <div class="glass-card chart-card no-hover">
        <h3><i class="fa-solid fa-chart-pie text-gold" style="margin-right:6px;"></i> Donor Status</h3>
        <div class="chart-wrap" style="height:220px;"><canvas id="chartDonorStatus"></canvas></div>
    </div>
    <div class="glass-card chart-card no-hover">
        <h3><i class="fa-solid fa-chart-bar text-green" style="margin-right:6px;"></i> Blood Group Distribution</h3>
        <div class="chart-wrap" style="height:220px;"><canvas id="chartBloodGroup"></canvas></div>
    </div>
</div>

<!-- Critical Cases + Recent Matches -->
<div class="panel-grid mb-4">
    <!-- Critical Cases -->
    <div class="glass-card no-hover">
        <div class="card-header">
            <h3><i class="fa-solid fa-triangle-exclamation text-red" style="margin-right:6px;"></i> Critical Cases</h3>
            <?php if ($stats['critical_recipients'] > 0): ?>
            <span class="badge badge-danger badge-critical"><?= (int)$stats['critical_recipients'] ?> Active</span>
            <?php else: ?>
            <span class="badge badge-success">All Clear</span>
            <?php endif; ?>
        </div>
        <div class="table-wrap">
            <?php if ($criticalCases): ?>
            <table>
                <thead><tr>
                    <th>Name</th><th>Type</th><th>Status</th><th>Days</th>
                </tr></thead>
                <tbody>
                <?php foreach ($criticalCases as $case): ?>
                <tr class="critical-row">
                    <td>
                        <div class="d-flex align-center gap-2">
                            <div class="avatar-circle" style="background:rgba(255,45,85,0.15);color:var(--accent-crimson);font-size:.7rem;">
                                <?= strtoupper(substr($case['name'], 0, 2)) ?>
                            </div>
                            <span><?= e($case['name']) ?></span>
                        </div>
                    </td>
                    <td><span class="badge badge-muted text-xs"><?= e(ucfirst($case['case_type'])) ?></span></td>
                    <td><span class="badge badge-danger badge-critical"><?= e($case['severity']) ?></span></td>
                    <td class="td-mono text-red"><?= (int)$case['days_in_status'] ?>d</td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="empty-state">
                <div class="empty-icon"><i class="fa-solid fa-shield-check"></i></div>
                <div class="empty-title" style="color:var(--accent-green);">No Critical Cases</div>
                <div class="empty-message">All patients are in stable or non-critical status.</div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Recent Matches -->
    <div class="glass-card no-hover">
        <div class="card-header">
            <h3><i class="fa-solid fa-dna text-cyan" style="margin-right:6px;"></i> Recent Matches</h3>
            <a href="<?= base_url('/pages/matches/index.php') ?>" class="btn btn-ghost btn-sm">View All</a>
        </div>
        <div class="table-wrap">
            <?php if ($recentMatches): ?>
            <table>
                <thead><tr><th>Match</th><th>Score</th><th>Status</th></tr></thead>
                <tbody>
                <?php foreach ($recentMatches as $m): ?>
                <tr>
                    <td>
                        <div style="font-size:.82rem;font-weight:600;"><?= e($m['donor_name']) ?></div>
                        <div style="font-size:.75rem;color:var(--text-muted);">↔ <?= e($m['recipient_name']) ?></div>
                    </td>
                    <td>
                        <div data-score-ring="<?= e(fmt_decimal10($m['match_score'])) ?>" style="width:48px;height:48px;position:relative;"></div>
                    </td>
                    <td><span class="badge <?= status_class($m['review_result']) ?>"><?= e($m['review_result']) ?></span></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-dna"></i></div><div class="empty-message">No matches yet.</div></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Recent Transplants -->
<div class="glass-card no-hover mb-4">
    <div class="card-header">
        <h3><i class="fa-solid fa-scalpel text-purple" style="margin-right:6px;"></i> Recent Transplants</h3>
        <a href="<?= base_url('/pages/transplants/index.php') ?>" class="btn btn-ghost btn-sm">View All</a>
    </div>
    <div class="table-wrap">
        <?php if ($recentTransplants): ?>
        <table>
            <thead><tr>
                <th>#</th><th>Donor → Recipient</th><th>Doctor</th><th>Hospital</th><th>Date</th><th>Result</th>
            </tr></thead>
            <tbody>
            <?php foreach ($recentTransplants as $t): ?>
            <tr>
                <td class="td-mono text-muted">#<?= (int)$t['transplant_id'] ?></td>
                <td>
                    <div style="font-size:.82rem;font-weight:600;"><?= e($t['donor_name']) ?></div>
                    <div style="font-size:.75rem;color:var(--text-muted);">↔ <?= e($t['recipient_name']) ?></div>
                </td>
                <td style="font-size:.82rem;"><?= e($t['doctor_name']) ?></td>
                <td style="font-size:.82rem;color:var(--text-secondary);"><?= e($t['hospital_name'] ?? '—') ?></td>
                <td class="td-mono text-muted"><?= fmt_date($t['surgery_date']) ?></td>
                <td><span class="badge <?= status_class($t['result']) ?>"><?= e($t['result']) ?></span></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-scalpel"></i></div><div class="empty-message">No transplants recorded yet.</div></div>
        <?php endif; ?>
    </div>
</div>

<?php endif; ?>
</div><!-- /z-index wrapper -->

<?php
// Pass chart data to JS
$extra_js = "document.addEventListener('DOMContentLoaded',()=>{ DashboardCharts.init(<?= $chartData ?>); });";
require_once KDMS_ROOT . '/includes/footer.php';
?>
