<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin']);
if($_SERVER['REQUEST_METHOD']!=='POST'){redirect('/pages/transplants/index.php');}
csrf_verify();
$id=(int)($_POST['id']??0);
$t=Database::fetchOne("SELECT transplant_id FROM transplants WHERE transplant_id=?",[$id]);
if(!$t){flash('danger','Not found.');redirect('/pages/transplants/index.php');}
try{
    Database::execute("DELETE FROM transplants WHERE transplant_id=?",[$id]);
    log_action('DELETE','transplants',$id,['transplant_id'=>$id]);
    flash('success',"Transplant #{$id} deleted.");
}catch(PDOException $e){
    flash('danger', str_contains($e->getMessage(),'foreign key') ? 'Cannot delete: has linked follow-up records.' : 'Error: '.$e->getMessage());
}
redirect('/pages/transplants/index.php');
