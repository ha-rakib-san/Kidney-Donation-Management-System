<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin','doctor']);
$id=(int)($_GET['id']??0); if(!$id){flash('danger','Invalid.');redirect('/pages/transplants/index.php');}
$tx=Database::fetchOne("SELECT t.*,d.name AS donor_name,r.name AS recipient_name FROM transplants t JOIN compatibility_matches cm ON t.match_id=cm.match_id JOIN donors d ON cm.donor_id=d.donor_id JOIN recipients r ON cm.recipient_id=r.recipient_id WHERE t.transplant_id=?",[$id]);
if(!$tx){flash('danger','Not found.');redirect('/pages/transplants/index.php');}
$errors=[]; $doctors=Database::fetchAll("SELECT doctor_id,name FROM doctors WHERE is_active=1 ORDER BY name");
$hospitals=Database::fetchAll("SELECT hospital_id,name,city FROM hospitals WHERE is_active=1 ORDER BY name");

if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_verify();
    $result = trim($_POST['result'] ?? $tx['result']);
    $notes  = trim($_POST['notes'] ?? '');

    // If result is changing to a terminal state, use the stored procedure (handles cascades)
    if (in_array($result, ['Successful','Failed','Cancelled']) && $result !== $tx['result']) {
        try {
            Procedures::completeTransplant($id, $result, $notes);
            flash('success', "Transplant #{$id} marked as {$result}. Related records updated automatically.");
            redirect('/pages/transplants/view.php?id='.$id);
        } catch (Throwable $e) {
            $errors[] = 'DB error: ' . $e->getMessage();
        }
    } else {
        // Just update other fields
        $doctor_id=(int)($_POST['doctor_id']??0)?:$tx['doctor_id'];
        $asst_id=(int)($_POST['assisting_doctor_id']??0)?:null;
        $hosp_id=(int)($_POST['hospital_id']??0)?:null;
        $sdate=trim($_POST['surgery_date']??$tx['surgery_date']);
        $stime=trim($_POST['surgery_start_time']??'')?:null;
        $sdur=(int)($_POST['surgery_duration_min']??0)?:null;
        $cold=(int)($_POST['cold_ischemia_time']??0)?:null;
        $warm=(int)($_POST['warm_ischemia_time']??0)?:null;
        $immuno=trim($_POST['immunosuppression']??'');
        $cost=trim($_POST['cost_amount']??'')?:null;
        $currency=trim($_POST['currency']??'USD')?:'USD';
        $insured=!empty($_POST['insurance_covered'])?1:0;
        try {
            Database::execute("UPDATE transplants SET doctor_id=?,assisting_doctor_id=?,hospital_id=?,surgery_date=?,surgery_start_time=?,surgery_duration_min=?,cold_ischemia_time=?,warm_ischemia_time=?,immunosuppression=?,notes=?,cost_amount=?,currency=?,insurance_covered=?,updated_at=CURRENT_TIMESTAMP WHERE transplant_id=?",
                [$doctor_id,$asst_id,$hosp_id,$sdate,$stime,$sdur,$cold,$warm,$immuno,$notes,$cost,$currency,$insured,$id]);
            log_action('UPDATE','transplants',$id,$tx,['notes'=>$notes]);
            flash('success','Transplant updated.'); redirect('/pages/transplants/view.php?id='.$id);
        } catch(PDOException $e) { $errors[]='DB error: '.$e->getMessage(); }
    }
    $tx = array_merge($tx, $_POST);
}
$page_title='Edit Transplant #'.$id;
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/transplants/index.php')?>">Transplants</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Edit #<?=$id?></span></div>
<div class="page-header"><div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-scalpel"></i></div><div><h1>Edit Transplant #<?=$id?></h1><p class="text-sm text-muted"><?=e($tx['donor_name'])?> → <?=e($tx['recipient_name'])?></p></div></div><div class="page-actions"><a href="<?=base_url('/pages/transplants/view.php?id='.$id)?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div></div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>

<!-- Outcome Quick Actions -->
<?php if($tx['result']==='Ongoing'): ?>
<div class="glass-card no-hover mb-4" style="border-color:rgba(255,184,0,0.3);">
    <div class="card-header"><h3><i class="fa-solid fa-circle-exclamation text-gold" style="margin-right:8px;"></i>Surgery In Progress — Record Outcome</h3></div>
    <div class="card-body">
        <p class="text-sm mb-3">Marking the outcome below will automatically update donor/recipient status, doctor stats, and notifications.</p>
        <form method="POST" class="d-flex gap-3" style="flex-wrap:wrap;">
            <?=csrf_field()?>
            <input type="text" name="notes" placeholder="Outcome notes (optional)" style="flex:1;min-width:200px;">
            <button type="submit" name="result" value="Successful" class="btn btn-success"><i class="fa-solid fa-check"></i> Mark Successful</button>
            <button type="submit" name="result" value="Failed" class="btn btn-danger" onclick="return confirm('Mark this transplant as Failed? Recipient will be re-queued.')"><i class="fa-solid fa-xmark"></i> Mark Failed</button>
            <button type="submit" name="result" value="Cancelled" class="btn btn-ghost">Cancel Surgery</button>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="glass-card no-hover"><div class="card-body">
<form method="POST" class="kdms-form" novalidate><?=csrf_field()?>
<input type="hidden" name="result" value="<?=e($tx['result'])?>">
<div class="form-grid form-grid-3">
    <div class="form-group"><label>Lead Surgeon</label><select name="doctor_id"><?php foreach($doctors as $d): ?><option value="<?=(int)$d['doctor_id']?>" <?=((int)$tx['doctor_id'])===(int)$d['doctor_id']?'selected':''?>><?=e($d['name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Assisting Doctor</label><select name="assisting_doctor_id"><option value="">— None —</option><?php foreach($doctors as $d): ?><option value="<?=(int)$d['doctor_id']?>" <?=((int)($tx['assisting_doctor_id']??0))===(int)$d['doctor_id']?'selected':''?>><?=e($d['name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Hospital</label><select name="hospital_id"><option value="">— None —</option><?php foreach($hospitals as $h): ?><option value="<?=(int)$h['hospital_id']?>" <?=((int)($tx['hospital_id']??0))===(int)$h['hospital_id']?'selected':''?>><?=e($h['name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Surgery Date</label><input type="date" name="surgery_date" value="<?=e($tx['surgery_date'])?>"></div>
    <div class="form-group"><label>Start Time</label><input type="time" name="surgery_start_time" value="<?=e($tx['surgery_start_time']??'')?>"></div>
    <div class="form-group"><label>Duration (min)</label><input type="number" name="surgery_duration_min" value="<?=e($tx['surgery_duration_min']??'')?>"></div>
    <div class="form-group"><label>Cold Ischemia (min)</label><input type="number" name="cold_ischemia_time" value="<?=e($tx['cold_ischemia_time']??'')?>"></div>
    <div class="form-group"><label>Warm Ischemia (min)</label><input type="number" name="warm_ischemia_time" value="<?=e($tx['warm_ischemia_time']??'')?>"></div>
    <div class="form-group"><label>Cost Amount</label><input type="number" name="cost_amount" step="0.01" value="<?=e($tx['cost_amount']??'')?>"></div>
    <div class="form-group"><label>Currency</label><select name="currency"><?php foreach(array_unique(array_values(KDMS_CURRENCY_BY_COUNTRY)) as $cur): ?><option value="<?=e($cur)?>" <?=($tx['currency']??'USD')===$cur?'selected':''?>><?=e($cur)?></option><?php endforeach; ?></select></div>
    <div class="form-group full"><label>Immunosuppression</label><textarea name="immunosuppression" rows="2"><?=e($tx['immunosuppression']??'')?></textarea></div>
    <div class="form-group full"><label>Notes</label><textarea name="notes" rows="3"><?=e($tx['notes']??'')?></textarea></div>
</div>
<div class="glass-card no-hover mt-3" style="padding:16px 20px;"><label class="login-remember" style="margin:0;"><input type="checkbox" name="insurance_covered" value="1" <?=$tx['insurance_covered']?'checked':''?>> Insurance Covered</label></div>
<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;"><a href="<?=base_url('/pages/transplants/view.php?id='.$id)?>" class="btn btn-ghost">Cancel</a><button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button></div>
</form></div></div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
