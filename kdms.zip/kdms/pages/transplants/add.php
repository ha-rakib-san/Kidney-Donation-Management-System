<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_role(['superadmin','admin','doctor']);
$page_title='Schedule Transplant'; $errors=[];

// Only Approved matches without an existing transplant
$matches = Database::fetchAll("
    SELECT cm.match_id,cm.match_score,d.name AS donor_name,r.name AS recipient_name
    FROM compatibility_matches cm
    JOIN donors d ON cm.donor_id=d.donor_id
    JOIN recipients r ON cm.recipient_id=r.recipient_id
    WHERE cm.review_result='Approved'
      AND cm.match_id NOT IN (SELECT match_id FROM transplants)
    ORDER BY cm.match_score DESC");
$doctors   = Database::fetchAll("SELECT doctor_id,name,specialization FROM doctors WHERE is_active=1 ORDER BY name");
$hospitals = Database::fetchAll("SELECT hospital_id,name,city,country FROM hospitals WHERE is_active=1 ORDER BY name");

if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_verify();
    $match_id  = (int)($_POST['match_id'] ?? 0);
    $doctor_id = (int)($_POST['doctor_id'] ?? 0);
    $asst_id   = (int)($_POST['assisting_doctor_id'] ?? 0) ?: null;
    $hosp_id   = (int)($_POST['hospital_id'] ?? 0) ?: null;
    $sdate     = trim($_POST['surgery_date'] ?? '');
    $stime     = trim($_POST['surgery_start_time'] ?? '') ?: null;
    $sdur      = (int)($_POST['surgery_duration_min'] ?? 0) ?: null;
    $cold_isch = (int)($_POST['cold_ischemia_time'] ?? 0) ?: null;
    $warm_isch = (int)($_POST['warm_ischemia_time'] ?? 0) ?: null;
    $immuno    = trim($_POST['immunosuppression'] ?? '');
    $notes     = trim($_POST['notes'] ?? '');
    $cost      = trim($_POST['cost_amount'] ?? '') ?: null;
    $currency  = trim($_POST['currency'] ?? 'USD') ?: 'USD';
    $insured   = !empty($_POST['insurance_covered']) ? 1 : 0;

    if(!$match_id)  $errors[] = 'Please select an approved match.';
    if(!$doctor_id) $errors[] = 'Lead surgeon is required.';
    if(!$sdate)     $errors[] = 'Surgery date is required.';

    if(!$errors){
        try{
            $id = Database::execute(
                "INSERT INTO transplants (match_id,doctor_id,assisting_doctor_id,hospital_id,surgery_date,surgery_start_time,surgery_duration_min,cold_ischemia_time,warm_ischemia_time,immunosuppression,notes,cost_amount,currency,insurance_covered)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [$match_id,$doctor_id,$asst_id,$hosp_id,$sdate,$stime,$sdur,$cold_isch,$warm_isch,$immuno,$notes,$cost,$currency,$insured]
            );
            log_action('CREATE','transplants',(int)$id,null,['match_id'=>$match_id,'doctor_id'=>$doctor_id,'surgery_date'=>$sdate]);
            flash('success', "Transplant #{$id} scheduled successfully.");
            redirect('/pages/transplants/index.php');
        }catch(PDOException $e){
            $errors[] = str_contains($e->getMessage(),'Duplicate') ? 'This match already has a transplant scheduled.' : 'DB error: '.$e->getMessage();
        }
    }
}
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/transplants/index.php')?>">Transplants</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Schedule</span></div>
<div class="page-header"><div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-scalpel"></i></div><div><h1>Schedule Transplant</h1><p class="text-sm text-muted">Create a surgical record from an approved match</p></div></div><div class="page-actions"><a href="<?=base_url('/pages/transplants/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div></div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>

<?php if(!$matches): ?>
<div class="glass-card no-hover"><div class="empty-state">
    <div class="empty-icon"><i class="fa-solid fa-triangle-exclamation"></i></div>
    <div class="empty-title">No Approved Matches Available</div>
    <div class="empty-message">There are no approved compatibility matches without an existing transplant record. Approve a match first.</div>
    <a href="<?=base_url('/pages/matches/index.php')?>" class="btn btn-primary"><i class="fa-solid fa-dna"></i> Go to Matches</a>
</div></div>
<?php else: ?>
<div class="glass-card no-hover"><div class="card-body">
<form method="POST" class="kdms-form" novalidate><?=csrf_field()?>
<div class="form-grid form-grid-3">
    <div class="form-group full"><label>Approved Match <span class="req">*</span></label>
        <select name="match_id" required>
            <option value="">Select an approved match…</option>
            <?php foreach($matches as $m): ?>
            <option value="<?=(int)$m['match_id']?>"><?=e($m['donor_name'])?> → <?=e($m['recipient_name'])?> (Score: <?=fmt_decimal10($m['match_score'])?>%)</option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group"><label>Lead Surgeon <span class="req">*</span></label><select name="doctor_id" required><option value="">Select…</option><?php foreach($doctors as $d): ?><option value="<?=(int)$d['doctor_id']?>"><?=e($d['name'])?> (<?=e($d['specialization'])?>)</option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Assisting Doctor</label><select name="assisting_doctor_id"><option value="">— None —</option><?php foreach($doctors as $d): ?><option value="<?=(int)$d['doctor_id']?>"><?=e($d['name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Hospital</label><select name="hospital_id"><option value="">— None —</option><?php foreach($hospitals as $h): ?><option value="<?=(int)$h['hospital_id']?>"><?=e($h['name'])?> (<?=e($h['city'])?>)</option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Surgery Date <span class="req">*</span></label><input type="date" name="surgery_date" required></div>
    <div class="form-group"><label>Start Time</label><input type="time" name="surgery_start_time"></div>
    <div class="form-group"><label>Duration (minutes)</label><input type="number" name="surgery_duration_min" min="0" max="1440" placeholder="e.g. 240"></div>
    <div class="form-group"><label>Cold Ischemia (min)</label><input type="number" name="cold_ischemia_time" min="0" max="2000"></div>
    <div class="form-group"><label>Warm Ischemia (min)</label><input type="number" name="warm_ischemia_time" min="0" max="500"></div>
    <div class="form-group"><label>Cost Amount</label><input type="number" name="cost_amount" step="0.01" min="0" placeholder="e.g. 25000"></div>
    <div class="form-group"><label>Currency</label><select name="currency"><?php foreach(array_unique(array_values(KDMS_CURRENCY_BY_COUNTRY)) as $cur): ?><option value="<?=e($cur)?>"><?=e($cur)?></option><?php endforeach; ?></select></div>
    <div class="form-group full"><label>Immunosuppression Protocol</label><textarea name="immunosuppression" rows="2" placeholder="e.g. Tacrolimus 0.1mg/kg + Mycophenolate 1g BID + Prednisolone 20mg OD"></textarea></div>
    <div class="form-group full"><label>Notes</label><textarea name="notes" rows="3" placeholder="Surgical notes, special considerations…"></textarea></div>
</div>
<div class="glass-card no-hover mt-3" style="padding:16px 20px;"><label class="login-remember" style="margin:0;"><input type="checkbox" name="insurance_covered" value="1"> Procedure covered by insurance</label></div>
<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;">
    <a href="<?=base_url('/pages/transplants/index.php')?>" class="btn btn-ghost">Cancel</a>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Schedule Transplant</button>
</div>
</form>
</div></div>
<?php endif; ?>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
