<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','auditor']);
$page_title='Transplants';
$filter_result=trim($_GET['result']??''); $page=max(1,(int)($_GET['page']??1)); $per_page=20;
$where=['1=1']; $params=[];
if($filter_result){$where[]='t.result=?';$params[]=$filter_result;}
$ws=implode(' AND ',$where);
$total=(int)(Database::fetchOne("SELECT COUNT(*) AS c FROM transplants t WHERE $ws",$params)['c']??0);
$pages=(int)ceil($total/$per_page); $offset=($page-1)*$per_page;
$transplants=Database::fetchAll("
    SELECT t.*,cm.match_score,d.name AS donor_name,r.name AS recipient_name,doc.name AS doctor_name,h.name AS hospital_name,
           (SELECT COUNT(*) FROM follow_ups fu WHERE fu.transplant_id=t.transplant_id) AS followup_count
    FROM transplants t
    JOIN compatibility_matches cm ON t.match_id=cm.match_id
    JOIN donors d ON cm.donor_id=d.donor_id
    JOIN recipients r ON cm.recipient_id=r.recipient_id
    JOIN doctors doc ON t.doctor_id=doc.doctor_id
    LEFT JOIN hospitals h ON t.hospital_id=h.hospital_id
    WHERE $ws ORDER BY t.surgery_date DESC LIMIT $per_page OFFSET $offset",$params);
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Transplants</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-scalpel"></i></div><div><h1>Transplants</h1><p class="text-sm text-muted">Surgical procedure records</p></div><span class="count-badge"><?=$total?></span></div>
    <div class="page-actions"><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/transplants/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Schedule Transplant</a><?php endif; ?><button class="btn btn-ghost" data-export-csv="mainTable" data-filename="transplants.csv"><i class="fa-solid fa-file-csv"></i> Export</button></div>
</div>
<div class="glass-card no-hover">
<form method="GET"><div class="filter-bar">
    <div class="form-group"><label>Result</label><select name="result"><option value="">All</option><?php foreach(['Ongoing','Successful','Failed','Cancelled'] as $r): ?><option value="<?=$r?>" <?=$filter_result===$r?'selected':''?>><?=$r?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>&nbsp;</label><div class="btn-group"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button><a href="<?=base_url('/pages/transplants/index.php')?>" class="btn btn-ghost btn-sm">Clear</a></div></div>
</div></form>
<div class="table-wrap"><?php if($transplants): ?>
<table id="mainTable"><thead><tr><th>#</th><th>Donor → Recipient</th><th>Doctor</th><th>Hospital</th><th>Surgery Date</th><th>Score</th><th>Result</th><th>Follow-Ups</th><th class="no-export">Actions</th></tr></thead><tbody>
<?php foreach($transplants as $t): ?>
<tr>
    <td class="td-mono text-muted">#<?=(int)$t['transplant_id']?></td>
    <td><div style="font-size:.85rem;"><div style="font-weight:600;"><?=e($t['donor_name'])?></div><div class="text-muted">↔ <?=e($t['recipient_name'])?></div></div></td>
    <td style="font-size:.85rem;"><?=e($t['doctor_name'])?></td>
    <td style="font-size:.82rem;color:var(--text-secondary);"><?=e($t['hospital_name']??'—')?></td>
    <td class="td-mono"><?=fmt_date($t['surgery_date'])?></td>
    <td class="td-mono text-cyan"><?=fmt_decimal10($t['match_score'])?>%</td>
    <td><span class="badge <?=status_class($t['result'])?>"><?=e($t['result'])?></span></td>
    <td class="td-mono"><?=(int)$t['followup_count']?></td>
    <td class="no-export"><div class="btn-group">
        <a href="<?=base_url('/pages/transplants/view.php?id='.(int)$t['transplant_id'])?>" class="btn btn-info btn-xs"><i class="fa-solid fa-eye"></i></a>
        <?php if(has_role(['superadmin','admin','doctor'])): ?>
        <a href="<?=base_url('/pages/transplants/edit.php?id='.(int)$t['transplant_id'])?>" class="btn btn-ghost btn-xs"><i class="fa-solid fa-pen"></i></a>
        <?php endif; ?>
        <?php if(has_role(['superadmin','admin'])): ?>
        <button class="btn btn-danger btn-xs" data-delete="<?=base_url('/pages/transplants/delete.php')?>" data-id="<?=(int)$t['transplant_id']?>" data-msg="Delete transplant #<?=(int)$t['transplant_id']?>?"><i class="fa-solid fa-trash-can"></i></button>
        <?php endif; ?>
    </div></td>
</tr>
<?php endforeach; ?>
</tbody></table>
<?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-scalpel"></i></div><div class="empty-title">No Transplants Found</div><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/transplants/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Schedule Transplant</a><?php endif; ?></div><?php endif; ?>
</div>
<?php if($pages>1): ?><div class="pagination"><?php if($page>1): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page-1]))?>" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?><?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$p]))?>" class="page-btn <?=$p===$page?'active':''?>"><?=$p?></a><?php endfor; ?><?php if($page<$pages): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page+1]))?>" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?><span class="pagination-info"><?=$total?> records</span></div><?php endif; ?>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
