<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','auditor']);
$id=(int)($_GET['id']??0); if(!$id){flash('danger','Invalid.');redirect('/pages/transplants/index.php');}
$tx=Database::fetchOne("
    SELECT t.*,cm.match_id,cm.match_score,d.donor_id,d.name AS donor_name,d.blood_group AS donor_blood,
           r.recipient_id,r.name AS recipient_name,r.blood_group AS recipient_blood,
           doc.name AS doctor_name,doc.specialization,asst.name AS assisting_name,h.name AS hospital_name,h.city AS hospital_city
    FROM transplants t
    JOIN compatibility_matches cm ON t.match_id=cm.match_id
    JOIN donors d ON cm.donor_id=d.donor_id
    JOIN recipients r ON cm.recipient_id=r.recipient_id
    JOIN doctors doc ON t.doctor_id=doc.doctor_id
    LEFT JOIN doctors asst ON t.assisting_doctor_id=asst.doctor_id
    LEFT JOIN hospitals h ON t.hospital_id=h.hospital_id
    WHERE t.transplant_id=?",[$id]);
if(!$tx){flash('danger','Not found.');redirect('/pages/transplants/index.php');}
$followups = Database::fetchAll("SELECT fu.*,doc.name AS doctor_name FROM follow_ups fu LEFT JOIN doctors doc ON fu.doctor_id=doc.doctor_id WHERE fu.transplant_id=? ORDER BY fu.checkup_date DESC",[$id]);
$page_title='Transplant #'.$id;
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/transplants/index.php')?>">Transplants</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">#<?=$id?></span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-scalpel"></i></div><div><h1>Transplant #<?=$id?></h1><div class="d-flex gap-2 mt-1"><span class="badge <?=status_class($tx['result'])?>"><?=e($tx['result'])?></span><span class="badge badge-muted">Score: <?=fmt_decimal10($tx['match_score'])?>%</span></div></div></div>
    <div class="page-actions"><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/transplants/edit.php?id='.$id)?>" class="btn btn-info"><i class="fa-solid fa-pen"></i> Edit</a><?php endif; ?><?php if(has_role(['superadmin','admin'])): ?><button class="btn btn-danger" data-delete="<?=base_url('/pages/transplants/delete.php')?>" data-id="<?=$id?>" data-msg="Delete transplant #<?=$id?>?"><i class="fa-solid fa-trash-can"></i></button><?php endif; ?><a href="<?=base_url('/pages/transplants/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<div class="detail-grid mb-4">
    <div class="glass-card no-hover"><div class="card-header"><h3>Surgical Details</h3></div><div class="card-body"><div class="detail-section">
        <div class="detail-row"><span class="detail-label">Donor</span><span class="detail-value"><a href="<?=base_url('/pages/donors/view.php?id='.(int)$tx['donor_id'])?>" class="text-cyan"><?=e($tx['donor_name'])?></a> (<?=e($tx['donor_blood'])?>)</span></div>
        <div class="detail-row"><span class="detail-label">Recipient</span><span class="detail-value"><a href="<?=base_url('/pages/recipients/view.php?id='.(int)$tx['recipient_id'])?>" class="text-cyan"><?=e($tx['recipient_name'])?></a> (<?=e($tx['recipient_blood'])?>)</span></div>
        <div class="detail-row"><span class="detail-label">Lead Surgeon</span><span class="detail-value"><?=e($tx['doctor_name'])?> (<?=e($tx['specialization'])?>)</span></div>
        <div class="detail-row"><span class="detail-label">Assistant</span><span class="detail-value"><?=e($tx['assisting_name']??'—')?></span></div>
        <div class="detail-row"><span class="detail-label">Hospital</span><span class="detail-value"><?=e($tx['hospital_name']??'—')?> <?=$tx['hospital_city']?'('.e($tx['hospital_city']).')':''?></span></div>
        <div class="detail-row"><span class="detail-label">Surgery Date</span><span class="detail-value td-mono"><?=fmt_date($tx['surgery_date'])?> <?=$tx['surgery_start_time']?'at '.substr($tx['surgery_start_time'],0,5):''?></span></div>
        <div class="detail-row"><span class="detail-label">Duration</span><span class="detail-value td-mono"><?=$tx['surgery_duration_min']?$tx['surgery_duration_min'].' min':'—'?></span></div>
        <div class="detail-row"><span class="detail-label">Ischemia Time</span><span class="detail-value td-mono">Cold: <?=$tx['cold_ischemia_time']??'—'?>min / Warm: <?=$tx['warm_ischemia_time']??'—'?>min</span></div>
    </div></div></div>
    <div class="glass-card no-hover"><div class="card-header"><h3>Outcome & Treatment</h3></div><div class="card-body"><div class="detail-section">
        <div class="detail-row"><span class="detail-label">Result</span><span class="detail-value"><span class="badge <?=status_class($tx['result'])?>" style="font-size:.85rem;"><?=e($tx['result'])?></span></span></div>
        <div class="detail-row"><span class="detail-label">Cost</span><span class="detail-value td-mono"><?=$tx['cost_amount']?e($tx['currency']??'USD').' '.number_format((float)$tx['cost_amount'],2):'—'?></span></div>
        <div class="detail-row"><span class="detail-label">Insurance</span><span class="detail-value"><?=$tx['insurance_covered']?'<span class="badge badge-success">Covered</span>':'<span class="badge badge-muted">Not covered</span>'?></span></div>
        <?php if($tx['immunosuppression']): ?><hr class="detail-divider"><div class="detail-row" style="flex-direction:column;gap:4px;"><span class="detail-label">Immunosuppression</span><span class="detail-value text-sm"><?=nl2br(e($tx['immunosuppression']))?></span></div><?php endif; ?>
        <?php if($tx['complications']): ?><div class="detail-row" style="flex-direction:column;gap:4px;"><span class="detail-label">Complications</span><span class="detail-value text-sm text-red"><?=nl2br(e($tx['complications']))?></span></div><?php endif; ?>
        <?php if($tx['notes']): ?><div class="detail-row" style="flex-direction:column;gap:4px;"><span class="detail-label">Notes</span><span class="detail-value text-sm"><?=nl2br(e($tx['notes']))?></span></div><?php endif; ?>
    </div></div></div>
</div>
<div class="glass-card no-hover">
    <div class="card-header"><h3><i class="fa-solid fa-clipboard-list text-gold" style="margin-right:8px;"></i>Follow-Up Timeline (<?=count($followups)?>)</h3><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/followups/add.php?transplant_id='.$id)?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Follow-Up</a><?php endif; ?></div>
    <div class="table-wrap"><?php if($followups): ?>
    <table><thead><tr><th>Month</th><th>Date</th><th>Status</th><th>Creatinine</th><th>GFR</th><th>BP</th><th>Rejection</th><th>Doctor</th></tr></thead><tbody>
    <?php foreach($followups as $f): ?>
    <tr <?=$f['health_status']==='Critical'?'class="critical-row"':''?>>
        <td class="td-mono"><?=$f['followup_month']?'M'.$f['followup_month']:'—'?></td>
        <td class="td-mono"><?=fmt_date($f['checkup_date'])?></td>
        <td><span class="badge <?=status_class($f['health_status'])?> <?=$f['health_status']==='Critical'?'badge-critical':''?>"><?=e($f['health_status'])?></span></td>
        <td class="td-mono"><?=$f['creatinine_level']?e($f['creatinine_level']).' mg/dL':'—'?></td>
        <td class="td-mono"><?=$f['gfr_numeric']?e($f['gfr_numeric']).' mL/min':'—'?></td>
        <td class="td-mono"><?=e($f['blood_pressure']??'—')?></td>
        <td><?php if($f['rejection_episode']): ?><span class="badge badge-danger"><?=e($f['rejection_grade'])?></span><?php else: ?><span class="badge badge-muted">None</span><?php endif; ?></td>
        <td style="font-size:.82rem;"><?=e($f['doctor_name']??'—')?></td>
    </tr>
    <?php endforeach; ?>
    </tbody></table>
    <?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-clipboard-list"></i></div><div class="empty-message">No follow-ups recorded yet.</div></div><?php endif; ?>
    </div>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
