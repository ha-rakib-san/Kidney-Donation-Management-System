<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor']);
$id=(int)($_GET['id']??0); if(!$id){flash('danger','Invalid.');redirect('/pages/followups/index.php');}
$fu=Database::fetchOne("SELECT * FROM follow_ups WHERE followup_id=?",[$id]);
if(!$fu){flash('danger','Not found.');redirect('/pages/followups/index.php');}
$errors=[]; $doctors=Database::fetchAll("SELECT doctor_id,name FROM doctors WHERE is_active=1 ORDER BY name");

if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_verify(); $old=$fu;
    $doc_id=(int)($_POST['doctor_id']??0)?:null; $ptype=trim($_POST['person_type']??'Recipient');
    $cdate=trim($_POST['checkup_date']??''); $status=trim($_POST['health_status']??'Stable');
    $creat=trim($_POST['creatinine_level']??'')?:null; $gfr=trim($_POST['gfr_numeric']??'')?:null;
    $bp=trim($_POST['blood_pressure']??''); $rejection=!empty($_POST['rejection_episode'])?1:0;
    $rgrade=trim($_POST['rejection_grade']??'None'); $mednotes=trim($_POST['medication_notes']??'');
    $notes=trim($_POST['notes']??''); $nextdate=trim($_POST['next_checkup_date']??'')?:null;
    $month=(int)($_POST['followup_month']??0)?:null;
    if(!$cdate) $errors[]='Checkup date required.';
    if(!$errors){
        try{
            Database::execute("UPDATE follow_ups SET doctor_id=?,person_type=?,checkup_date=?,health_status=?,creatinine_level=?,gfr_numeric=?,blood_pressure=?,rejection_episode=?,rejection_grade=?,medication_notes=?,notes=?,next_checkup_date=?,followup_month=? WHERE followup_id=?",
                [$doc_id,$ptype,$cdate,$status,$creat,$gfr,$bp,$rejection,$rgrade,$mednotes,$notes,$nextdate,$month,$id]);
            log_action('UPDATE','follow_ups',$id,$old,['health_status'=>$status]);
            flash('success','Follow-up updated.'); redirect('/pages/followups/index.php');
        }catch(PDOException $e){ $errors[]='DB error: '.$e->getMessage(); }
    }
    $fu=array_merge($fu,$_POST);
}
$page_title='Edit Follow-Up #'.$id;
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/followups/index.php')?>">Follow-Ups</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Edit</span></div>
<div class="page-header"><div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-clipboard-list"></i></div><div><h1>Edit Follow-Up #<?=$id?></h1></div></div><div class="page-actions"><a href="<?=base_url('/pages/transplants/view.php?id='.$fu['transplant_id'])?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div></div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>
<div class="glass-card no-hover"><div class="card-body">
<form method="POST" class="kdms-form" novalidate><?=csrf_field()?>
<div class="form-grid form-grid-3">
    <div class="form-group"><label>Person Type</label><select name="person_type"><option value="Recipient" <?=$fu['person_type']==='Recipient'?'selected':''?>>Recipient</option><option value="Donor" <?=$fu['person_type']==='Donor'?'selected':''?>>Donor</option></select></div>
    <div class="form-group"><label>Doctor</label><select name="doctor_id"><option value="">— None —</option><?php foreach($doctors as $d): ?><option value="<?=(int)$d['doctor_id']?>" <?=((int)($fu['doctor_id']??0))===(int)$d['doctor_id']?'selected':''?>><?=e($d['name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Checkup Date</label><input type="date" name="checkup_date" value="<?=e($fu['checkup_date'])?>"></div>
    <div class="form-group"><label>Follow-Up Month</label><select name="followup_month"><option value="">— —</option><?php foreach([1,3,6,12] as $m): ?><option value="<?=$m?>" <?=((int)($fu['followup_month']??0))===$m?'selected':''?>>Month <?=$m?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Next Checkup</label><input type="date" name="next_checkup_date" value="<?=e($fu['next_checkup_date']??'')?>"></div>
    <div class="form-group"><label>Health Status</label><select name="health_status"><?php foreach(['Stable','Recovering','Critical','Discharged','Deceased'] as $s): ?><option value="<?=$s?>" <?=$fu['health_status']===$s?'selected':''?>><?=$s?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Creatinine</label><input type="number" name="creatinine_level" value="<?=e($fu['creatinine_level']??'')?>" step="0.001"></div>
    <div class="form-group"><label>GFR</label><input type="number" name="gfr_numeric" value="<?=e($fu['gfr_numeric']??'')?>" step="0.01"></div>
    <div class="form-group"><label>Blood Pressure</label><input type="text" name="blood_pressure" value="<?=e($fu['blood_pressure']??'')?>" maxlength="15"></div>
    <div class="form-group"><label>Rejection Episode</label><select name="rejection_episode"><option value="0" <?=!$fu['rejection_episode']?'selected':''?>>No</option><option value="1" <?=$fu['rejection_episode']?'selected':''?>>Yes</option></select></div>
    <div class="form-group"><label>Rejection Grade</label><select name="rejection_grade"><?php foreach(['None','Borderline','IA','IB','IIA','IIB','III'] as $g): ?><option value="<?=$g?>" <?=$fu['rejection_grade']===$g?'selected':''?>><?=$g?></option><?php endforeach; ?></select></div>
    <div class="form-group full"><label>Medication Notes</label><textarea name="medication_notes" rows="2"><?=e($fu['medication_notes']??'')?></textarea></div>
    <div class="form-group full"><label>Notes</label><textarea name="notes" rows="3"><?=e($fu['notes']??'')?></textarea></div>
</div>
<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;"><a href="<?=base_url('/pages/transplants/view.php?id='.$fu['transplant_id'])?>" class="btn btn-ghost">Cancel</a><button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button></div>
</form></div></div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
