<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','auditor']);
$page_title='Follow-Ups';
$filter_status=trim($_GET['health_status']??''); $page=max(1,(int)($_GET['page']??1)); $per_page=20;
$where=['1=1']; $params=[];
if($filter_status){$where[]='fu.health_status=?';$params[]=$filter_status;}
$ws=implode(' AND ',$where);
$total=(int)(Database::fetchOne("SELECT COUNT(*) AS c FROM follow_ups fu WHERE $ws",$params)['c']??0);
$pages=(int)ceil($total/$per_page); $offset=($page-1)*$per_page;
$followups=Database::fetchAll("
    SELECT fu.*,t.transplant_id,d.name AS donor_name,r.name AS recipient_name,doc.name AS doctor_name
    FROM follow_ups fu
    JOIN transplants t ON fu.transplant_id=t.transplant_id
    JOIN compatibility_matches cm ON t.match_id=cm.match_id
    JOIN donors d ON cm.donor_id=d.donor_id
    JOIN recipients r ON cm.recipient_id=r.recipient_id
    LEFT JOIN doctors doc ON fu.doctor_id=doc.doctor_id
    WHERE $ws ORDER BY fu.checkup_date DESC LIMIT $per_page OFFSET $offset",$params);
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Follow-Ups</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-clipboard-list"></i></div><div><h1>Follow-Ups</h1><p class="text-sm text-muted">Post-transplant patient monitoring</p></div><span class="count-badge"><?=$total?></span></div>
    <div class="page-actions"><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/followups/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Follow-Up</a><?php endif; ?></div>
</div>
<div class="glass-card no-hover">
<form method="GET"><div class="filter-bar">
    <div class="form-group"><label>Health Status</label><select name="health_status"><option value="">All</option><?php foreach(['Stable','Critical','Recovering','Discharged','Deceased'] as $s): ?><option value="<?=$s?>" <?=$filter_status===$s?'selected':''?>><?=$s?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>&nbsp;</label><div class="btn-group"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button><a href="<?=base_url('/pages/followups/index.php')?>" class="btn btn-ghost btn-sm">Clear</a></div></div>
</div></form>
<div class="table-wrap"><?php if($followups): ?>
<table id="mainTable"><thead><tr><th>Transplant</th><th>Patient Pair</th><th>Date</th><th>Month</th><th>Status</th><th>Creatinine</th><th>GFR</th><th>Rejection</th><th class="no-export">Actions</th></tr></thead><tbody>
<?php foreach($followups as $f): ?>
<tr <?=$f['health_status']==='Critical'?'class="critical-row"':''?>>
    <td><a href="<?=base_url('/pages/transplants/view.php?id='.(int)$f['transplant_id'])?>" class="td-mono text-cyan">#<?=(int)$f['transplant_id']?></a></td>
    <td style="font-size:.82rem;"><?=e($f['donor_name'])?> ↔ <?=e($f['recipient_name'])?></td>
    <td class="td-mono"><?=fmt_date($f['checkup_date'])?></td>
    <td class="td-mono"><?=$f['followup_month']?'M'.$f['followup_month']:'—'?></td>
    <td><span class="badge <?=status_class($f['health_status'])?> <?=$f['health_status']==='Critical'?'badge-critical':''?>"><?=e($f['health_status'])?></span></td>
    <td class="td-mono"><?=$f['creatinine_level']?e($f['creatinine_level']):'—'?></td>
    <td class="td-mono"><?=$f['gfr_numeric']?e($f['gfr_numeric']):'—'?></td>
    <td><?php if($f['rejection_episode']): ?><span class="badge badge-danger"><?=e($f['rejection_grade'])?></span><?php else: ?><span class="badge badge-muted">None</span><?php endif; ?></td>
    <td class="no-export"><div class="btn-group">
        <?php if(has_role(['superadmin','admin','doctor'])): ?>
        <a href="<?=base_url('/pages/followups/edit.php?id='.(int)$f['followup_id'])?>" class="btn btn-ghost btn-xs"><i class="fa-solid fa-pen"></i></a>
        <?php endif; ?>
        <?php if(has_role(['superadmin','admin'])): ?>
        <button class="btn btn-danger btn-xs" data-delete="<?=base_url('/pages/followups/delete.php')?>" data-id="<?=(int)$f['followup_id']?>" data-msg="Delete this follow-up record?"><i class="fa-solid fa-trash-can"></i></button>
        <?php endif; ?>
    </div></td>
</tr>
<?php endforeach; ?>
</tbody></table>
<?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-clipboard-list"></i></div><div class="empty-title">No Follow-Ups Found</div><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/followups/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Follow-Up</a><?php endif; ?></div><?php endif; ?>
</div>
<?php if($pages>1): ?><div class="pagination"><?php if($page>1): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page-1]))?>" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?><?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$p]))?>" class="page-btn <?=$p===$page?'active':''?>"><?=$p?></a><?php endfor; ?><?php if($page<$pages): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page+1]))?>" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?><span class="pagination-info"><?=$total?> records</span></div><?php endif; ?>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
