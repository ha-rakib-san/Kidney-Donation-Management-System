<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin']);
if($_SERVER['REQUEST_METHOD']!=='POST'){redirect('/pages/followups/index.php');}
csrf_verify();
$id=(int)($_POST['id']??0);
$f=Database::fetchOne("SELECT followup_id FROM follow_ups WHERE followup_id=?",[$id]);
if(!$f){flash('danger','Not found.');redirect('/pages/followups/index.php');}
try{
    Database::execute("DELETE FROM follow_ups WHERE followup_id=?",[$id]);
    log_action('DELETE','follow_ups',$id,['followup_id'=>$id]);
    flash('success',"Follow-up #{$id} deleted.");
}catch(PDOException $e){flash('danger','Error: '.$e->getMessage());}
redirect('/pages/followups/index.php');
