<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor']);
$page_title='Add Follow-Up'; $errors=[];
$prefill_tx = (int)($_GET['transplant_id'] ?? 0);
$transplants = Database::fetchAll("
    SELECT t.transplant_id,d.name AS donor_name,r.name AS recipient_name
    FROM transplants t
    JOIN compatibility_matches cm ON t.match_id=cm.match_id
    JOIN donors d ON cm.donor_id=d.donor_id
    JOIN recipients r ON cm.recipient_id=r.recipient_id
    WHERE t.result IN ('Successful','Ongoing')
    ORDER BY t.transplant_id DESC");
$doctors = Database::fetchAll("SELECT doctor_id,name FROM doctors WHERE is_active=1 ORDER BY name");

if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_verify();
    $tx_id   = (int)($_POST['transplant_id'] ?? 0);
    $doc_id  = (int)($_POST['doctor_id'] ?? 0) ?: null;
    $ptype   = trim($_POST['person_type'] ?? 'Recipient');
    $cdate   = trim($_POST['checkup_date'] ?? date('Y-m-d'));
    $status  = trim($_POST['health_status'] ?? 'Stable');
    $creat   = trim($_POST['creatinine_level'] ?? '') ?: null;
    $gfr     = trim($_POST['gfr_numeric'] ?? '') ?: null;
    $bp      = trim($_POST['blood_pressure'] ?? '');
    $rejection = !empty($_POST['rejection_episode']) ? 1 : 0;
    $rgrade  = trim($_POST['rejection_grade'] ?? 'None');
    $mednotes= trim($_POST['medication_notes'] ?? '');
    $notes   = trim($_POST['notes'] ?? '');
    $nextdate= trim($_POST['next_checkup_date'] ?? '') ?: null;
    $month   = (int)($_POST['followup_month'] ?? 0) ?: null;

    if(!$tx_id) $errors[] = 'Transplant is required.';
    if(!$cdate) $errors[] = 'Checkup date is required.';

    if(!$errors){
        try{
            $id = Database::execute(
                "INSERT INTO follow_ups (transplant_id,doctor_id,person_type,checkup_date,health_status,creatinine_level,gfr_numeric,blood_pressure,rejection_episode,rejection_grade,medication_notes,notes,next_checkup_date,followup_month)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [$tx_id,$doc_id,$ptype,$cdate,$status,$creat,$gfr,$bp,$rejection,$rgrade,$mednotes,$notes,$nextdate,$month]
            );
            log_action('CREATE','follow_ups',(int)$id,null,['transplant_id'=>$tx_id,'health_status'=>$status]);
            flash('success','Follow-up recorded.' . ($status==='Critical' ? ' Urgent notification sent to medical team.' : ''));
            redirect('/pages/followups/index.php');
        }catch(PDOException $e){ $errors[] = 'DB error: ' . $e->getMessage(); }
    }
}
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/followups/index.php')?>">Follow-Ups</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Add Follow-Up</span></div>
<div class="page-header"><div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-clipboard-list"></i></div><div><h1>Add Follow-Up</h1><p class="text-sm text-muted">Record post-transplant checkup</p></div></div><div class="page-actions"><a href="<?=base_url('/pages/followups/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div></div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>
<div class="glass-card no-hover"><div class="card-body">
<form method="POST" class="kdms-form" novalidate><?=csrf_field()?>
<div class="form-grid form-grid-3">
    <div class="form-group full"><label>Transplant <span class="req">*</span></label>
        <select name="transplant_id" required>
            <option value="">Select transplant…</option>
            <?php foreach($transplants as $t): ?>
            <option value="<?=(int)$t['transplant_id']?>" <?=$prefill_tx===(int)$t['transplant_id']?'selected':''?>>#<?=(int)$t['transplant_id']?> — <?=e($t['donor_name'])?> → <?=e($t['recipient_name'])?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group"><label>Person Type</label><select name="person_type"><option value="Recipient" selected>Recipient</option><option value="Donor">Donor</option></select></div>
    <div class="form-group"><label>Reviewing Doctor</label><select name="doctor_id"><option value="">— None —</option><?php foreach($doctors as $d): ?><option value="<?=(int)$d['doctor_id']?>"><?=e($d['name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Checkup Date <span class="req">*</span></label><input type="date" name="checkup_date" value="<?=date('Y-m-d')?>" max="<?=date('Y-m-d')?>" required></div>
    <div class="form-group"><label>Follow-Up Month</label><select name="followup_month"><option value="">— Select —</option><option value="1">Month 1</option><option value="3">Month 3</option><option value="6">Month 6</option><option value="12">Month 12</option></select></div>
    <div class="form-group"><label>Next Checkup Date</label><input type="date" name="next_checkup_date"></div>
    <div class="form-group">
        <label>Health Status <span class="req">*</span></label>
        <select name="health_status" id="healthStatus" required onchange="toggleCriticalWarning()">
            <?php foreach(['Stable','Recovering','Critical','Discharged','Deceased'] as $s): ?>
            <option value="<?=$s?>"><?=$s?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="form-group"><label>Creatinine (mg/dL)</label><input type="number" name="creatinine_level" step="0.001" min="0"></div>
    <div class="form-group"><label>GFR (mL/min)</label><input type="number" name="gfr_numeric" step="0.01" min="0"></div>
    <div class="form-group"><label>Blood Pressure</label><input type="text" name="blood_pressure" placeholder="e.g. 120/80" maxlength="15"></div>
    <div class="form-group">
        <label>Rejection Episode</label>
        <div class="toggle-btn-group">
            <button type="button" class="toggle-btn active-neg" id="noRejection" onclick="setRejection(false)">No</button>
            <button type="button" class="toggle-btn" id="yesRejection" onclick="setRejection(true)">Yes</button>
        </div>
        <input type="hidden" name="rejection_episode" id="rejectionInput" value="0">
    </div>
    <div class="form-group" id="rejectionGradeWrap" style="display:none;">
        <label>Rejection Grade</label>
        <select name="rejection_grade"><?php foreach(['None','Borderline','IA','IB','IIA','IIB','III'] as $g): ?><option value="<?=$g?>"><?=$g?></option><?php endforeach; ?></select>
    </div>
    <div class="form-group full"><label>Medication Notes</label><textarea name="medication_notes" rows="2" placeholder="Current medications, dosage adjustments…"></textarea></div>
    <div class="form-group full"><label>Clinical Notes</label><textarea name="notes" rows="3" placeholder="Examination findings, recommendations…"></textarea></div>
</div>
<div id="criticalWarning" class="flash-message flash-danger mt-3" style="position:relative;top:0;right:0;display:none;">
    <span class="flash-icon"><i class="fa-solid fa-triangle-exclamation"></i></span>
    <span class="flash-text">Marking as Critical will trigger an urgent notification to the medical team immediately upon saving.</span>
</div>
<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;">
    <a href="<?=base_url('/pages/followups/index.php')?>" class="btn btn-ghost">Cancel</a>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Follow-Up</button>
</div>
</form></div></div>
<script>
function setRejection(yes) {
    document.getElementById('rejectionInput').value = yes ? '1' : '0';
    document.getElementById('noRejection').classList.toggle('active-neg', !yes);
    document.getElementById('yesRejection').classList.toggle('active-pos', yes);
    document.getElementById('rejectionGradeWrap').style.display = yes ? 'block' : 'none';
}
function toggleCriticalWarning() {
    const val = document.getElementById('healthStatus').value;
    document.getElementById('criticalWarning').style.display = val === 'Critical' ? 'flex' : 'none';
}
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
