<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','auditor']);
$page_title='Medical Tests';
$filter_type=trim($_GET['person_type']??''); $filter_cross=trim($_GET['crossmatch']??''); $filter_infect=trim($_GET['infection_screen']??'');
$page=max(1,(int)($_GET['page']??1)); $per_page=20;
$where=['1=1']; $params=[];
if($filter_type){$where[]='mt.person_type=?';$params[]=$filter_type;}
if($filter_cross){$where[]='mt.crossmatch=?';$params[]=$filter_cross;}
if($filter_infect){$where[]='mt.infection_screen=?';$params[]=$filter_infect;}
$ws=implode(' AND ',$where);
$total=(int)(Database::fetchOne("SELECT COUNT(*) AS c FROM medical_tests mt WHERE $ws",$params)['c']??0);
$pages=(int)ceil($total/$per_page); $offset=($page-1)*$per_page;
$tests=Database::fetchAll("
    SELECT mt.*, doc.name AS doctor_name,
           CASE mt.person_type WHEN 'Donor' THEN (SELECT name FROM donors WHERE donor_id=mt.person_id) ELSE (SELECT name FROM recipients WHERE recipient_id=mt.person_id) END AS person_name
    FROM medical_tests mt
    LEFT JOIN doctors doc ON mt.doctor_id=doc.doctor_id
    WHERE $ws ORDER BY mt.test_date DESC, mt.test_id DESC LIMIT $per_page OFFSET $offset",$params);
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Medical Tests</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-flask-vial"></i></div><div><h1>Medical Tests</h1><p class="text-sm text-muted">Donor & recipient test records</p></div><span class="count-badge"><?=$total?></span></div>
    <div class="page-actions"><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/tests/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Test</a><?php endif; ?><button class="btn btn-ghost" data-export-csv="mainTable" data-filename="tests.csv"><i class="fa-solid fa-file-csv"></i> Export</button></div>
</div>
<div class="glass-card no-hover">
<form method="GET"><div class="filter-bar">
    <div class="form-group"><label>Person Type</label><select name="person_type"><option value="">All</option><option value="Donor" <?=$filter_type==='Donor'?'selected':''?>>Donor</option><option value="Recipient" <?=$filter_type==='Recipient'?'selected':''?>>Recipient</option></select></div>
    <div class="form-group"><label>Crossmatch</label><select name="crossmatch"><option value="">All</option><option value="Negative" <?=$filter_cross==='Negative'?'selected':''?>>Negative</option><option value="Positive" <?=$filter_cross==='Positive'?'selected':''?>>Positive</option><option value="Pending" <?=$filter_cross==='Pending'?'selected':''?>>Pending</option></select></div>
    <div class="form-group"><label>Infection Screen</label><select name="infection_screen"><option value="">All</option><option value="Clear" <?=$filter_infect==='Clear'?'selected':''?>>Clear</option><option value="Flagged" <?=$filter_infect==='Flagged'?'selected':''?>>Flagged</option></select></div>
    <div class="form-group"><label>&nbsp;</label><div class="btn-group"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button><a href="<?=base_url('/pages/tests/index.php')?>" class="btn btn-ghost btn-sm">Clear</a></div></div>
</div></form>
<div class="table-wrap"><?php if($tests): ?>
<table id="mainTable"><thead><tr><th>#</th><th>Person</th><th>Type</th><th>Doctor</th><th>HLA Type</th><th>Crossmatch</th><th>GFR</th><th>Creatinine</th><th>BMI</th><th>BP</th><th>Hb</th><th>PRA</th><th>Date</th><th class="no-export">Actions</th></tr></thead><tbody>
<?php foreach($tests as $t): ?>
<tr>
    <td class="td-mono text-muted"><?=(int)$t['test_id']?></td>
    <td style="font-weight:600;font-size:.88rem;"><?=e($t['person_name']??'ID:'.$t['person_id'])?></td>
    <td><span class="badge <?=$t['person_type']==='Donor'?'badge-success':'badge-warning'?>"><?=e($t['person_type'])?></span></td>
    <td style="font-size:.82rem;"><?=e($t['doctor_name']??'—')?></td>
    <td class="td-mono"><?=e($t['tissue_type_hla']??'—')?></td>
    <td><span class="badge <?=$t['crossmatch']==='Negative'?'badge-success':($t['crossmatch']==='Positive'?'badge-danger crossmatch-positive':'badge-warning')?>"><?=e($t['crossmatch'])?></span></td>
    <td class="td-mono"><?=$t['gfr_numeric']!==null?fmt_decimal10($t['gfr_numeric']):'—'?></td>
    <td class="td-mono"><?=$t['creatinine_level']!==null?fmt_decimal10($t['creatinine_level']):'—'?></td>
    <td class="td-mono"><?=$t['bmi']!==null?fmt_decimal10($t['bmi']):'—'?></td>
    <td class="td-mono"><?=($t['systolic_bp']!==null&&$t['diastolic_bp']!==null)?fmt_decimal10($t['systolic_bp']).'/'.fmt_decimal10($t['diastolic_bp']):'—'?></td>
    <td class="td-mono"><?=$t['hemoglobin']!==null?fmt_decimal10($t['hemoglobin']):'—'?></td>
    <td class="td-mono"><?=$t['pra_percentage']!==null?fmt_decimal10($t['pra_percentage']).'%':'—'?></td>
    <td class="td-mono text-muted"><?=fmt_date($t['test_date'])?></td>
    <td class="no-export"><div class="btn-group">
        <?php if(has_role(['superadmin','admin','doctor'])): ?>
        <a href="<?=base_url('/pages/tests/edit.php?id='.(int)$t['test_id'])?>" class="btn btn-ghost btn-xs"><i class="fa-solid fa-pen"></i></a>
        <button class="btn btn-danger btn-xs" data-delete="<?=base_url('/pages/tests/delete.php')?>" data-id="<?=(int)$t['test_id']?>" data-msg="Delete test #<?=(int)$t['test_id']?>?"><i class="fa-solid fa-trash-can"></i></button>
        <?php endif; ?>
    </div></td>
</tr>
<?php endforeach; ?>
</tbody></table>
<?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-flask-vial"></i></div><div class="empty-title">No Tests Found</div><?php if(has_role(['superadmin','admin','doctor'])): ?><a href="<?=base_url('/pages/tests/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Test</a><?php endif; ?></div><?php endif; ?>
</div>
<?php if($pages>1): ?><div class="pagination"><?php if($page>1): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page-1]))?>" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?><?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$p]))?>" class="page-btn <?=$p===$page?'active':''?>"><?=$p?></a><?php endfor; ?><?php if($page<$pages): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page+1]))?>" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?><span class="pagination-info"><?=$total?> records</span></div><?php endif; ?>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
