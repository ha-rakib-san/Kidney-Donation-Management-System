<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin']);
if($_SERVER['REQUEST_METHOD']!=='POST'){redirect('/pages/tests/index.php');}
csrf_verify();
$id=(int)($_POST['id']??0);
$t=Database::fetchOne("SELECT test_id,person_id,person_type FROM medical_tests WHERE test_id=?",[$id]);
if(!$t){flash('danger','Not found.');redirect('/pages/tests/index.php');}
try{
    Database::execute("DELETE FROM medical_tests WHERE test_id=?",[$id]);
    Procedures::recalculateMatchesForPerson((int)$t['person_id'], (string)$t['person_type']);
    log_action('DELETE','medical_tests',$id,['test_id'=>$id]);
    flash('success',"Test #{$id} deleted.");
}catch(PDOException $e){flash('danger','Error: '.$e->getMessage());}
redirect('/pages/tests/index.php');
