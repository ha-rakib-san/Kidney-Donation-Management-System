<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin','doctor']);
$page_title='Add Medical Test'; $errors=[];
$prefill_person_id   = (int)($_GET['person_id']   ?? 0);
$prefill_person_type = trim($_GET['person_type']  ?? '');
$donors    = Database::fetchAll("SELECT donor_id,name,blood_group FROM donors ORDER BY name");
$recipients= Database::fetchAll("SELECT recipient_id,name,blood_group FROM recipients ORDER BY name");
$doctors   = Database::fetchAll("SELECT doctor_id,name FROM doctors WHERE is_active=1 ORDER BY name");
$hla_types = ['DR1','DR2','DR3','DR4','DR5','DR6','DR7','DR8','DR9','DR10','DR11','DR12','DR13','DR14','DR15','DR16','DR17','DR18'];

if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_verify();
    $person_id   =(int)($_POST['person_id']??0);
    $person_type =trim($_POST['person_type']??'');
    $doctor_id   =(int)($_POST['doctor_id']??0)?:null;
    $blood_test  =trim($_POST['blood_test']??'');
    $kidney_fn   =trim($_POST['kidney_function']??'');
    $hla         =trim($_POST['tissue_type_hla']??'');
    $crossmatch  =trim($_POST['crossmatch']??'Pending');
    $infect      =trim($_POST['infection_screen']??'Clear');
    $hep_b       =trim($_POST['hepatitis_b']??'Negative');
    $hep_c       =trim($_POST['hepatitis_c']??'Negative');
    $hiv         =trim($_POST['hiv']??'Negative');
    $creat       = decimal_value($_POST['creatinine_level'] ?? null);
    $hemo        = decimal_value($_POST['hemoglobin'] ?? null);
    $height      = decimal_value($_POST['height_cm'] ?? null);
    $weight      = decimal_value($_POST['weight_kg'] ?? null);
    $bmi         = decimal_value($_POST['bmi'] ?? null);
    $systolic    = decimal_value($_POST['systolic_bp'] ?? null);
    $diastolic   = decimal_value($_POST['diastolic_bp'] ?? null);
    $diabetes    = ($_POST['diabetes'] ?? '') === '' ? null : (int)$_POST['diabetes'];
    $hypertension= ($_POST['hypertension'] ?? '') === '' ? null : (int)$_POST['hypertension'];
    $pra         = decimal_value($_POST['pra_percentage'] ?? null);
    $gfr_num     = decimal_value($_POST['gfr_numeric'] ?? null);
    if ($height !== null && $weight !== null && $height > 0) {
        $bmi = round($weight / (($height / 100) ** 2), 10);
    }
    if ($person_type === 'Donor' && $pra === null) $pra = 0.0;
    $test_date   =trim($_POST['test_date']??date('Y-m-d'));
    $notes       =trim($_POST['result_notes']??'');
    $lab_ref     =trim($_POST['lab_reference']??'');

    if(!$person_id) $errors[]='Person is required.';
    if(!in_array($person_type,['Donor','Recipient'])) $errors[]='Person type required.';
    if(!in_array($crossmatch,['Positive','Negative','Pending'], true)) $errors[]='Crossmatch result required.';
    $requiredNumbers = [
        'GFR' => [$gfr_num, 0, 200], 'Creatinine' => [$creat, 0, 30],
        'Hemoglobin' => [$hemo, 0, 25], 'Height' => [$height, 100, 250],
        'Weight' => [$weight, 20, 300], 'BMI' => [$bmi, 8, 80],
        'Systolic blood pressure' => [$systolic, 50, 300],
        'Diastolic blood pressure' => [$diastolic, 30, 200],
    ];
    foreach ($requiredNumbers as $label => [$value, $min, $max]) {
        if ($value === null || $value < $min || $value > $max) {
            $errors[] = "$label must be between $min and $max.";
        }
    }
    if (!in_array($diabetes, [0,1], true)) $errors[]='Diabetes status is required.';
    if (!in_array($hypertension, [0,1], true)) $errors[]='Hypertension status is required.';
    if ($person_type === 'Recipient' && ($pra === null || $pra < 0 || $pra > 100)) $errors[]='PRA percentage must be between 0 and 100.';

    if(!$errors){
        try{
            $id=Database::execute(
                "INSERT INTO medical_tests (person_id,person_type,doctor_id,blood_test,kidney_function,gfr_numeric,tissue_type_hla,crossmatch,infection_screen,hepatitis_b,hepatitis_c,hiv,creatinine_level,hemoglobin,height_cm,weight_kg,bmi,systolic_bp,diastolic_bp,diabetes,hypertension,pra_percentage,test_date,result_notes,lab_reference,verified_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [$person_id,$person_type,$doctor_id,$blood_test,$kidney_fn,$gfr_num,$hla,$crossmatch,$infect,$hep_b,$hep_c,$hiv,$creat,$hemo,$height,$weight,$bmi,$systolic,$diastolic,$diabetes,$hypertension,$pra,$test_date,$notes,$lab_ref,current_user()['user_id']]
            );
            Procedures::recalculateMatchesForPerson($person_id, $person_type);
            log_action('CREATE','medical_tests',(int)$id,null,['person_id'=>$person_id,'person_type'=>$person_type,'crossmatch'=>$crossmatch]);
            flash('success','Medical test recorded.');
            redirect('/pages/tests/index.php');
        }catch(PDOException $e){ $errors[]='DB error: '.$e->getMessage(); }
    }
}
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/tests/index.php')?>">Medical Tests</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Add Test</span></div>
<div class="page-header"><div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-flask-vial"></i></div><div><h1>Add Medical Test</h1><p class="text-sm text-muted">Record diagnostic test results</p></div></div><div class="page-actions"><a href="<?=base_url('/pages/tests/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div></div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>

<div class="glass-card no-hover"><div class="card-body"><form method="POST" class="kdms-form" novalidate><?=csrf_field()?>
<div class="form-grid form-grid-3">
    <!-- Person type radio -->
    <div class="form-group">
        <label>Person Type <span class="req">*</span></label>
        <div class="toggle-btn-group">
            <button type="button" class="toggle-btn <?=($prefill_person_type==='Donor'||($_POST['person_type']??'')==='Donor')?'active-neg':''?>" id="typeDonor" onclick="selectType('Donor')">Donor</button>
            <button type="button" class="toggle-btn <?=($prefill_person_type==='Recipient'||($_POST['person_type']??'')==='Recipient')?'active-neg':''?>" id="typeRecipient" onclick="selectType('Recipient')">Recipient</button>
        </div>
        <input type="hidden" name="person_type" id="personTypeInput" value="<?=e($prefill_person_type?:($_POST['person_type']??''))?>">
    </div>
    <!-- Dynamic person selector -->
    <div class="form-group">
        <label>Select Donor <span class="req">*</span></label>
        <select name="person_id" id="donorSelect" <?=$prefill_person_type==='Recipient'?'style="display:none;"':''?>>
            <option value="">Select donor…</option>
            <?php foreach($donors as $d): ?><option value="<?=(int)$d['donor_id']?>" <?=((int)($_POST['person_id']??$prefill_person_id))===(int)$d['donor_id']&&($prefill_person_type!=='Recipient')?'selected':''?>><?=e($d['name'])?> (<?=e($d['blood_group'])?>)</option><?php endforeach; ?>
        </select>
        <select id="recipientSelect" <?=$prefill_person_type!=='Recipient'?'style="display:none;"':''?> <?=$prefill_person_type==='Recipient'?'name="person_id"':'data-inactive="1"'?>>
            <option value="">Select recipient…</option>
            <?php foreach($recipients as $r): ?><option value="<?=(int)$r['recipient_id']?>" <?=((int)($_POST['person_id']??$prefill_person_id))===(int)$r['recipient_id']&&$prefill_person_type==='Recipient'?'selected':''?>><?=e($r['name'])?> (<?=e($r['blood_group'])?>)</option><?php endforeach; ?>
        </select>
    </div>
    <div class="form-group"><label>Examining Doctor</label><select name="doctor_id"><option value="">— Select —</option><?php foreach($doctors as $d): ?><option value="<?=(int)$d['doctor_id']?>" <?=((int)($_POST['doctor_id']??0))===(int)$d['doctor_id']?'selected':''?>><?=e($d['name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Test Date <span class="req">*</span></label><input type="date" name="test_date" value="<?=e($_POST['test_date']??date('Y-m-d'))?>" max="<?=date('Y-m-d')?>"></div>
    <div class="form-group"><label>Lab Reference</label><input type="text" name="lab_reference" value="<?=e($_POST['lab_reference']??'')?>" maxlength="50" placeholder="e.g. LAB-2024-001"></div>
    <div class="form-group"><label>Blood Test Result</label><input type="text" name="blood_test" value="<?=e($_POST['blood_test']??'')?>" maxlength="100" placeholder="e.g. Normal CBC"></div>

    <!-- HLA Type with autocomplete -->
    <div class="form-group"><label>HLA Tissue Type</label>
        <input type="text" name="tissue_type_hla" id="hlaInput" value="<?=e($_POST['tissue_type_hla']??'')?>" maxlength="30" placeholder="e.g. DR3" list="hlaList" autocomplete="off">
        <datalist id="hlaList"><?php foreach($hla_types as $h): ?><option value="<?=$h?>"><?php endforeach; ?></datalist>
    </div>

    <!-- GFR with stage classifier -->
    <div class="form-group"><label>GFR (mL/min)</label>
        <input type="number" name="gfr_numeric" id="gfrInput" value="<?=e($_POST['gfr_numeric']??'')?>" step="0.0000000001" min="0" max="200" required placeholder="e.g. 85.5">
        <div class="gfr-indicator mt-1" id="gfrStage"></div>
    </div>
    <div class="form-group"><label>Kidney Function</label><input type="text" name="kidney_function" value="<?=e($_POST['kidney_function']??'')?>" maxlength="50" placeholder="e.g. GFR 85"></div>
    <div class="form-group"><label>Creatinine (mg/dL)</label><input type="number" name="creatinine_level" value="<?=e($_POST['creatinine_level']??'')?>" step="0.0000000001" min="0" max="30" required></div>
    <div class="form-group"><label>Hemoglobin (g/dL) <span class="req">*</span></label><input type="number" name="hemoglobin" value="<?=e($_POST['hemoglobin']??'')?>" step="0.0000000001" min="0" max="25" required></div>
    <div class="form-group"><label>Height (cm) <span class="req">*</span></label><input type="number" id="heightInput" name="height_cm" value="<?=e($_POST['height_cm']??'')?>" step="0.0000000001" min="100" max="250" required></div>
    <div class="form-group"><label>Weight (kg) <span class="req">*</span></label><input type="number" id="weightInput" name="weight_kg" value="<?=e($_POST['weight_kg']??'')?>" step="0.0000000001" min="20" max="300" required></div>
    <div class="form-group"><label>BMI, calculated <span class="req">*</span></label><input type="number" id="bmiInput" name="bmi" value="<?=e($_POST['bmi']??'')?>" step="0.0000000001" min="8" max="80" readonly required><small class="text-muted">Calculated from height and weight.</small></div>
    <div class="form-group"><label>Systolic BP (mmHg) <span class="req">*</span></label><input type="number" name="systolic_bp" value="<?=e($_POST['systolic_bp']??'')?>" step="0.0000000001" min="50" max="300" required></div>
    <div class="form-group"><label>Diastolic BP (mmHg) <span class="req">*</span></label><input type="number" name="diastolic_bp" value="<?=e($_POST['diastolic_bp']??'')?>" step="0.0000000001" min="30" max="200" required></div>
    <div class="form-group"><label>Diabetes <span class="req">*</span></label><select name="diabetes" required><option value="">Select…</option><option value="0" <?=($_POST['diabetes']??'')==='0'?'selected':''?>>No</option><option value="1" <?=($_POST['diabetes']??'')==='1'?'selected':''?>>Yes</option></select></div>
    <div class="form-group"><label>Hypertension <span class="req">*</span></label><select name="hypertension" required><option value="">Select…</option><option value="0" <?=($_POST['hypertension']??'')==='0'?'selected':''?>>No</option><option value="1" <?=($_POST['hypertension']??'')==='1'?'selected':''?>>Yes</option></select></div>
    <div class="form-group"><label>PRA / cPRA (%) <span class="req">*</span></label><input type="number" name="pra_percentage" value="<?=e($_POST['pra_percentage']??'')?>" step="0.0000000001" min="0" max="100" placeholder="Recipient sensitization, donor may use 0"><small class="text-muted">Required for recipients. Use 0 for donors.</small></div>

    <!-- Crossmatch visual toggle -->
    <div class="form-group">
        <label>Crossmatch Result <span class="req">*</span></label>
        <div class="toggle-btn-group">
            <button type="button" class="toggle-btn <?=($_POST['crossmatch']??'Pending')==='Negative'?'active-neg':''?>" id="crossNeg" onclick="setCrossmatch('Negative')"><i class="fa-solid fa-check"></i> Negative</button>
            <button type="button" class="toggle-btn <?=($_POST['crossmatch']??'')==='Positive'?'active-pos':''?>" id="crossPos" onclick="setCrossmatch('Positive')"><i class="fa-solid fa-xmark"></i> Positive</button>
            <button type="button" class="toggle-btn <?=($_POST['crossmatch']??'Pending')==='Pending'?'active':''?>" id="crossPending" onclick="setCrossmatch('Pending')"><i class="fa-solid fa-clock"></i> Pending</button>
        </div>
        <input type="hidden" name="crossmatch" id="crossmatchInput" value="<?=e($_POST['crossmatch']??'Pending')?>">
        <div id="crossmatchBadgeDisplay" class="mt-1"></div>
    </div>

    <!-- Infection screen -->
    <div class="form-group">
        <label>Infection Screen</label>
        <div class="toggle-btn-group">
            <button type="button" class="toggle-btn <?=($_POST['infection_screen']??'Clear')==='Clear'?'active-neg':''?>" onclick="setInfect('Clear',this)"><i class="fa-solid fa-shield-check"></i> Clear</button>
            <button type="button" class="toggle-btn <?=($_POST['infection_screen']??'')==='Flagged'?'active-pos':''?>" onclick="setInfect('Flagged',this)"><i class="fa-solid fa-flag"></i> Flagged</button>
        </div>
        <input type="hidden" name="infection_screen" id="infectInput" value="<?=e($_POST['infection_screen']??'Clear')?>">
    </div>

    <!-- Pathogen toggles -->
    <div class="form-group">
        <label>Hepatitis B</label>
        <div class="toggle-btn-group">
            <button type="button" class="toggle-btn <?=($_POST['hepatitis_b']??'Negative')==='Negative'?'active-neg':''?>" onclick="setPathogen('hepB','Negative',this)">Negative</button>
            <button type="button" class="toggle-btn <?=($_POST['hepatitis_b']??'')==='Positive'?'active-pos':''?>" onclick="setPathogen('hepB','Positive',this)">Positive</button>
        </div>
        <input type="hidden" name="hepatitis_b" id="hepBInput" value="<?=e($_POST['hepatitis_b']??'Negative')?>">
    </div>
    <div class="form-group">
        <label>Hepatitis C</label>
        <div class="toggle-btn-group">
            <button type="button" class="toggle-btn <?=($_POST['hepatitis_c']??'Negative')==='Negative'?'active-neg':''?>" onclick="setPathogen('hepC','Negative',this)">Negative</button>
            <button type="button" class="toggle-btn <?=($_POST['hepatitis_c']??'')==='Positive'?'active-pos':''?>" onclick="setPathogen('hepC','Positive',this)">Positive</button>
        </div>
        <input type="hidden" name="hepatitis_c" id="hepCInput" value="<?=e($_POST['hepatitis_c']??'Negative')?>">
    </div>
    <div class="form-group">
        <label>HIV</label>
        <div class="toggle-btn-group">
            <button type="button" class="toggle-btn <?=($_POST['hiv']??'Negative')==='Negative'?'active-neg':''?>" onclick="setPathogen('hiv','Negative',this)">Negative</button>
            <button type="button" class="toggle-btn <?=($_POST['hiv']??'')==='Positive'?'active-pos':''?>" onclick="setPathogen('hiv','Positive',this)">Positive</button>
        </div>
        <input type="hidden" name="hiv" id="hivInput" value="<?=e($_POST['hiv']??'Negative')?>">
    </div>
    <div class="form-group full"><label>Result Notes</label><textarea name="result_notes" rows="3" placeholder="Observations, clinical notes…"><?=e($_POST['result_notes']??'')?></textarea></div>
</div>
<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;"><a href="<?=base_url('/pages/tests/index.php')?>" class="btn btn-ghost">Cancel</a><button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Test</button></div>
</form></div></div>

<script>
// Person type toggle
function selectType(type) {
    document.getElementById('personTypeInput').value = type;
    const donorSel = document.getElementById('donorSelect');
    const recipSel = document.getElementById('recipientSelect');
    if (type === 'Donor') {
        donorSel.style.display = ''; donorSel.name = 'person_id';
        recipSel.style.display = 'none'; recipSel.name = '';
        document.getElementById('typeDonor').classList.add('active-neg');
        document.getElementById('typeRecipient').classList.remove('active-neg');
    } else {
        recipSel.style.display = ''; recipSel.name = 'person_id';
        donorSel.style.display = 'none'; donorSel.name = '';
        document.getElementById('typeRecipient').classList.add('active-neg');
        document.getElementById('typeDonor').classList.remove('active-neg');
    }
}
// Init from prefill
const initType = document.getElementById('personTypeInput').value;
if(initType) selectType(initType);

// Crossmatch
function setCrossmatch(val) {
    document.getElementById('crossmatchInput').value = val;
    const neg=document.getElementById('crossNeg'), pos=document.getElementById('crossPos');
    const badge=document.getElementById('crossmatchBadgeDisplay');
    const pending=document.getElementById('crossPending');
    [neg,pos,pending].forEach(b=>b&&b.classList.remove('active-neg','active-pos','active'));
    if(val==='Negative'){neg.classList.add('active-neg');badge.innerHTML='<span class="badge badge-success crossmatch-negative"><i class="fa-solid fa-check"></i> Negative — Compatible</span>';}
    else if(val==='Positive'){pos.classList.add('active-pos');badge.innerHTML='<span class="badge badge-danger crossmatch-positive"><i class="fa-solid fa-xmark"></i> Positive — Incompatible risk</span>';}
    else{pending.classList.add('active');badge.innerHTML='<span class="badge badge-warning"><i class="fa-solid fa-clock"></i> Pending — Not eligible for approval</span>';}
}
setCrossmatch(document.getElementById('crossmatchInput').value||'Pending');

// Infection screen
function setInfect(val, btn) {
    document.getElementById('infectInput').value = val;
    document.querySelectorAll('[onclick^="setInfect"]').forEach(b=>b.classList.remove('active-neg','active-pos'));
    btn.classList.add(val==='Clear'?'active-neg':'active-pos');
}

// Pathogen toggle
const pathMap = {hepB:'hepBInput',hepC:'hepCInput',hiv:'hivInput'};
function setPathogen(key, val, btn) {
    document.getElementById(pathMap[key]).value = val;
    const btns = btn.closest('.toggle-btn-group').querySelectorAll('.toggle-btn');
    btns.forEach(b=>b.classList.remove('active-neg','active-pos'));
    btn.classList.add(val==='Negative'?'active-neg':'active-pos');
}

// GFR stage classifier
const gfrIn=document.getElementById('gfrInput'), gfrStage=document.getElementById('gfrStage');
function updateGFR(v){const g=parseFloat(v);if(isNaN(g)||g<=0){gfrStage.innerHTML='';return;}const s=g>=90?{s:'Stage 1 — Normal',c:'#00E5A0'}:g>=60?{s:'Stage 2 — Mild',c:'#00D4FF'}:g>=45?{s:'Stage 3a — Mild-Mod',c:'#FFB800'}:g>=30?{s:'Stage 3b — Mod-Severe',c:'#FF8800'}:g>=15?{s:'Stage 4 — Severe',c:'#FF2D55'}:{s:'Stage 5 — Failure',c:'#CC0033'};gfrStage.innerHTML=`<span class="gfr-dot" style="background:${s.c}"></span><span style="color:${s.c};font-weight:600;font-size:.8rem;">${s.s}</span>`;}
gfrIn&&gfrIn.addEventListener('input',()=>updateGFR(gfrIn.value));
updateGFR(gfrIn?.value);

// BMI calculator, stored to 10 decimal places
const heightInput=document.getElementById('heightInput'), weightInput=document.getElementById('weightInput'), bmiInput=document.getElementById('bmiInput');
function updateBMI(){const h=parseFloat(heightInput?.value),w=parseFloat(weightInput?.value);if(Number.isFinite(h)&&h>0&&Number.isFinite(w)){bmiInput.value=(w/((h/100)**2)).toFixed(10);}else if(bmiInput){bmiInput.value='';}}
heightInput&&heightInput.addEventListener('input',updateBMI);weightInput&&weightInput.addEventListener('input',updateBMI);updateBMI();
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
