<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin','doctor']);

$id=(int)($_GET['id']??0);
if(!$id){flash('danger','Invalid test.');redirect('/pages/tests/index.php');}
$test=Database::fetchOne("SELECT * FROM medical_tests WHERE test_id=?",[$id]);
if(!$test){flash('danger','Test not found.');redirect('/pages/tests/index.php');}

$errors=[];
$doctors=Database::fetchAll("SELECT doctor_id,name FROM doctors WHERE is_active=1 ORDER BY name");
$hla_types=['DR1','DR2','DR3','DR4','DR5','DR6','DR7','DR8','DR9','DR10','DR11','DR12','DR13','DR14','DR15','DR16','DR17','DR18'];

if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_verify();
    $old=$test;
    $cross=trim($_POST['crossmatch']??'Pending');
    $infect=trim($_POST['infection_screen']??'Clear');
    $hla=trim($_POST['tissue_type_hla']??'');
    $gfr=decimal_value($_POST['gfr_numeric']??null);
    $creat=decimal_value($_POST['creatinine_level']??null);
    $hemo=decimal_value($_POST['hemoglobin']??null);
    $height=decimal_value($_POST['height_cm']??null);
    $weight=decimal_value($_POST['weight_kg']??null);
    $bmi=decimal_value($_POST['bmi']??null);
    $systolic=decimal_value($_POST['systolic_bp']??null);
    $diastolic=decimal_value($_POST['diastolic_bp']??null);
    $diabetes=($_POST['diabetes']??'')===''?null:(int)$_POST['diabetes'];
    $hypertension=($_POST['hypertension']??'')===''?null:(int)$_POST['hypertension'];
    $pra=decimal_value($_POST['pra_percentage']??null);
    if($height!==null && $weight!==null && $height>0){$bmi=round($weight/(($height/100)**2),10);}
    if($test['person_type']==='Donor' && $pra===null){$pra=0.0;}

    $notes=trim($_POST['result_notes']??'');
    $blood=trim($_POST['blood_test']??'');
    $kfn=trim($_POST['kidney_function']??'');
    $doc_id=(int)($_POST['doctor_id']??0)?:null;
    $tdate=trim($_POST['test_date']??date('Y-m-d'));
    $lab=trim($_POST['lab_reference']??'');
    $hb=trim($_POST['hepatitis_b']??'Negative');
    $hc=trim($_POST['hepatitis_c']??'Negative');
    $hiv=trim($_POST['hiv']??'Negative');

    if(!in_array($cross,['Positive','Negative','Pending'],true)){$errors[]='Crossmatch result is required.';}
    $requiredNumbers=[
        'GFR'=>[$gfr,0,200], 'Creatinine'=>[$creat,0,30], 'Hemoglobin'=>[$hemo,0,25],
        'Height'=>[$height,100,250], 'Weight'=>[$weight,20,300], 'BMI'=>[$bmi,8,80],
        'Systolic blood pressure'=>[$systolic,50,300], 'Diastolic blood pressure'=>[$diastolic,30,200],
    ];
    foreach($requiredNumbers as $label=>[$value,$min,$max]){
        if($value===null || $value<$min || $value>$max){$errors[]="$label must be between $min and $max.";}
    }
    if(!in_array($diabetes,[0,1],true)){$errors[]='Diabetes status is required.';}
    if(!in_array($hypertension,[0,1],true)){$errors[]='Hypertension status is required.';}
    if($test['person_type']==='Recipient' && ($pra===null || $pra<0 || $pra>100)){$errors[]='PRA percentage must be between 0 and 100.';}
    if($pra!==null && ($pra<0 || $pra>100)){$errors[]='PRA percentage must be between 0 and 100.';}

    if(!$errors){
        try{
            Database::execute(
                "UPDATE medical_tests SET doctor_id=?,blood_test=?,kidney_function=?,gfr_numeric=?,tissue_type_hla=?,crossmatch=?,infection_screen=?,hepatitis_b=?,hepatitis_c=?,hiv=?,creatinine_level=?,hemoglobin=?,height_cm=?,weight_kg=?,bmi=?,systolic_bp=?,diastolic_bp=?,diabetes=?,hypertension=?,pra_percentage=?,test_date=?,result_notes=?,lab_reference=? WHERE test_id=?",
                [$doc_id,$blood,$kfn,$gfr,$hla,$cross,$infect,$hb,$hc,$hiv,$creat,$hemo,$height,$weight,$bmi,$systolic,$diastolic,$diabetes,$hypertension,$pra,$tdate,$notes,$lab,$id]
            );
            Procedures::recalculateMatchesForPerson((int)$test['person_id'],(string)$test['person_type']);
            log_action('UPDATE','medical_tests',$id,$old,['crossmatch'=>$cross,'gfr_numeric'=>$gfr,'bmi'=>$bmi,'pra_percentage'=>$pra]);
            flash('success','Medical test updated and compatibility scores recalculated.');
            redirect('/pages/tests/index.php');
        }catch(PDOException $e){$errors[]='DB error: '.$e->getMessage();}
    }
    $test=array_merge($test,$_POST,['bmi'=>$bmi]);
}

$person_name='';
if($test['person_type']==='Donor'){$r=Database::fetchOne("SELECT name FROM donors WHERE donor_id=?",[$test['person_id']]);$person_name=$r['name']??'';}
else{$r=Database::fetchOne("SELECT name FROM recipients WHERE recipient_id=?",[$test['person_id']]);$person_name=$r['name']??'';}
$page_title='Edit Test #'.$id;
$decimalInput = static fn(mixed $value): string => ($value === null || $value === '' || !is_numeric($value)) ? '' : fmt_decimal10($value);
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/tests/index.php')?>">Medical Tests</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Edit #<?=$id?></span></div>
<div class="page-header"><div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-flask-vial"></i></div><div><h1>Edit Test #<?=$id?></h1><p class="text-sm text-muted"><?=e($test['person_type'])?> · <?=e($person_name)?></p></div></div><div class="page-actions"><a href="<?=base_url('/pages/tests/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div></div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>
<div class="glass-card no-hover"><div class="card-body">
<div class="d-flex gap-2 mb-3"><span class="badge badge-info"><?=e($test['person_type'])?></span><span class="badge badge-muted"><?=e($person_name)?></span><span class="badge badge-muted"><?=e($test['test_date'])?></span></div>
<form method="POST" class="kdms-form" novalidate><?=csrf_field()?>
<div class="form-grid form-grid-3">
<div class="form-group"><label>Doctor</label><select name="doctor_id"><option value="">None</option><?php foreach($doctors as $d): ?><option value="<?=(int)$d['doctor_id']?>" <?=((int)($test['doctor_id']??0))===(int)$d['doctor_id']?'selected':''?>><?=e($d['name'])?></option><?php endforeach; ?></select></div>
<div class="form-group"><label>Test Date</label><input type="date" name="test_date" value="<?=e($test['test_date'])?>" max="<?=date('Y-m-d')?>" required></div>
<div class="form-group"><label>Lab Reference</label><input type="text" name="lab_reference" value="<?=e($test['lab_reference']??'')?>" maxlength="50"></div>
<div class="form-group"><label>Blood Test</label><input type="text" name="blood_test" value="<?=e($test['blood_test']??'')?>" maxlength="100"></div>
<div class="form-group"><label>HLA Type</label><input type="text" name="tissue_type_hla" value="<?=e($test['tissue_type_hla']??'')?>" maxlength="30" list="hlaList"><datalist id="hlaList"><?php foreach($hla_types as $h): ?><option value="<?=$h?>"><?php endforeach; ?></datalist></div>
<div class="form-group"><label>Kidney Function</label><input type="text" name="kidney_function" value="<?=e($test['kidney_function']??'')?>" maxlength="50"></div>
<div class="form-group"><label>GFR (mL/min) <span class="req">*</span></label><input type="number" id="gfrInput" name="gfr_numeric" value="<?=e($decimalInput($test['gfr_numeric']??null))?>" step="0.0000000001" min="0" max="200" required><div class="gfr-indicator mt-1" id="gfrStage"></div></div>
<div class="form-group"><label>Creatinine (mg/dL) <span class="req">*</span></label><input type="number" name="creatinine_level" value="<?=e($decimalInput($test['creatinine_level']??null))?>" step="0.0000000001" min="0" max="30" required></div>
<div class="form-group"><label>Hemoglobin (g/dL) <span class="req">*</span></label><input type="number" name="hemoglobin" value="<?=e($decimalInput($test['hemoglobin']??null))?>" step="0.0000000001" min="0" max="25" required></div>
<div class="form-group"><label>Height (cm) <span class="req">*</span></label><input type="number" id="heightInput" name="height_cm" value="<?=e($decimalInput($test['height_cm']??null))?>" step="0.0000000001" min="100" max="250" required></div>
<div class="form-group"><label>Weight (kg) <span class="req">*</span></label><input type="number" id="weightInput" name="weight_kg" value="<?=e($decimalInput($test['weight_kg']??null))?>" step="0.0000000001" min="20" max="300" required></div>
<div class="form-group"><label>BMI, calculated <span class="req">*</span></label><input type="number" id="bmiInput" name="bmi" value="<?=e($decimalInput($test['bmi']??null))?>" step="0.0000000001" min="8" max="80" readonly required><small class="text-muted">Calculated from height and weight.</small></div>
<div class="form-group"><label>Systolic BP (mmHg) <span class="req">*</span></label><input type="number" name="systolic_bp" value="<?=e($decimalInput($test['systolic_bp']??null))?>" step="0.0000000001" min="50" max="300" required></div>
<div class="form-group"><label>Diastolic BP (mmHg) <span class="req">*</span></label><input type="number" name="diastolic_bp" value="<?=e($decimalInput($test['diastolic_bp']??null))?>" step="0.0000000001" min="30" max="200" required></div>
<div class="form-group"><label>Diabetes <span class="req">*</span></label><select name="diabetes" required><option value="">Select</option><option value="0" <?=isset($test['diabetes'])&&(string)$test['diabetes']==='0'?'selected':''?>>No</option><option value="1" <?=isset($test['diabetes'])&&(string)$test['diabetes']==='1'?'selected':''?>>Yes</option></select></div>
<div class="form-group"><label>Hypertension <span class="req">*</span></label><select name="hypertension" required><option value="">Select</option><option value="0" <?=isset($test['hypertension'])&&(string)$test['hypertension']==='0'?'selected':''?>>No</option><option value="1" <?=isset($test['hypertension'])&&(string)$test['hypertension']==='1'?'selected':''?>>Yes</option></select></div>
<div class="form-group"><label>PRA / cPRA (%) <span class="req">*</span></label><input type="number" name="pra_percentage" value="<?=e($decimalInput($test['pra_percentage']??($test['person_type']==='Donor'?0:null)))?>" step="0.0000000001" min="0" max="100" required><small class="text-muted">Recipient sensitization. Donors use 0.</small></div>
<div class="form-group"><label>Crossmatch <span class="req">*</span></label><div class="toggle-btn-group"><button type="button" id="crossNeg" class="toggle-btn <?=$test['crossmatch']==='Negative'?'active-neg':''?>" onclick="setCrossmatch('Negative')"><i class="fa-solid fa-check"></i> Negative</button><button type="button" id="crossPos" class="toggle-btn <?=$test['crossmatch']==='Positive'?'active-pos':''?>" onclick="setCrossmatch('Positive')"><i class="fa-solid fa-xmark"></i> Positive</button><button type="button" id="crossPending" class="toggle-btn <?=$test['crossmatch']==='Pending'?'active':''?>" onclick="setCrossmatch('Pending')"><i class="fa-solid fa-clock"></i> Pending</button></div><input type="hidden" name="crossmatch" id="crossmatch" value="<?=e($test['crossmatch'])?>"><div id="crossmatchBadgeDisplay" class="mt-1"></div></div>
<div class="form-group"><label>Infection Screen</label><div class="toggle-btn-group"><button type="button" class="toggle-btn <?=$test['infection_screen']==='Clear'?'active-neg':''?>" onclick="setVal('infection_screen','Clear',this,'active-neg')"><i class="fa-solid fa-shield-check"></i> Clear</button><button type="button" class="toggle-btn <?=$test['infection_screen']==='Flagged'?'active-pos':''?>" onclick="setVal('infection_screen','Flagged',this,'active-pos')"><i class="fa-solid fa-flag"></i> Flagged</button></div><input type="hidden" name="infection_screen" id="infection_screen" value="<?=e($test['infection_screen'])?>"></div>
<div class="form-group"><label>Hep B</label><div class="toggle-btn-group"><button type="button" class="toggle-btn <?=$test['hepatitis_b']==='Negative'?'active-neg':''?>" onclick="setVal('hepatitis_b','Negative',this,'active-neg')">Negative</button><button type="button" class="toggle-btn <?=$test['hepatitis_b']==='Positive'?'active-pos':''?>" onclick="setVal('hepatitis_b','Positive',this,'active-pos')">Positive</button></div><input type="hidden" name="hepatitis_b" id="hepatitis_b" value="<?=e($test['hepatitis_b'])?>"></div>
<div class="form-group"><label>Hep C</label><div class="toggle-btn-group"><button type="button" class="toggle-btn <?=$test['hepatitis_c']==='Negative'?'active-neg':''?>" onclick="setVal('hepatitis_c','Negative',this,'active-neg')">Negative</button><button type="button" class="toggle-btn <?=$test['hepatitis_c']==='Positive'?'active-pos':''?>" onclick="setVal('hepatitis_c','Positive',this,'active-pos')">Positive</button></div><input type="hidden" name="hepatitis_c" id="hepatitis_c" value="<?=e($test['hepatitis_c'])?>"></div>
<div class="form-group"><label>HIV</label><div class="toggle-btn-group"><button type="button" class="toggle-btn <?=$test['hiv']==='Negative'?'active-neg':''?>" onclick="setVal('hiv','Negative',this,'active-neg')">Negative</button><button type="button" class="toggle-btn <?=$test['hiv']==='Positive'?'active-pos':''?>" onclick="setVal('hiv','Positive',this,'active-pos')">Positive</button></div><input type="hidden" name="hiv" id="hiv" value="<?=e($test['hiv'])?>"></div>
<div class="form-group full"><label>Result Notes</label><textarea name="result_notes" rows="3"><?=e($test['result_notes']??'')?></textarea></div>
</div>
<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;"><a href="<?=base_url('/pages/tests/index.php')?>" class="btn btn-ghost">Cancel</a><button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button></div>
</form></div></div>
<script>
function setVal(field,val,btn,cls){document.getElementById(field).value=val;const g=btn.closest('.toggle-btn-group');g.querySelectorAll('.toggle-btn').forEach(b=>b.classList.remove('active-neg','active-pos','active'));btn.classList.add(cls);}
function setCrossmatch(val){const input=document.getElementById('crossmatch'),neg=document.getElementById('crossNeg'),pos=document.getElementById('crossPos'),pending=document.getElementById('crossPending'),badge=document.getElementById('crossmatchBadgeDisplay');input.value=val;[neg,pos,pending].forEach(b=>b.classList.remove('active-neg','active-pos','active'));if(val==='Negative'){neg.classList.add('active-neg');badge.innerHTML='<span class="badge badge-success">Negative, eligible result</span>';}else if(val==='Positive'){pos.classList.add('active-pos');badge.innerHTML='<span class="badge badge-danger">Positive, hard stop</span>';}else{pending.classList.add('active');badge.innerHTML='<span class="badge badge-warning">Pending, cannot approve</span>';}}
setCrossmatch(document.getElementById('crossmatch').value||'Pending');
const gfrIn=document.getElementById('gfrInput'),gfrStage=document.getElementById('gfrStage');
function updateGFR(v){const g=parseFloat(v);if(!Number.isFinite(g)||g<=0){gfrStage.innerHTML='';return;}const s=g>=90?{s:'Stage 1, normal',c:'#00E5A0'}:g>=60?{s:'Stage 2, mild',c:'#00D4FF'}:g>=45?{s:'Stage 3a',c:'#FFB800'}:g>=30?{s:'Stage 3b',c:'#FF8800'}:g>=15?{s:'Stage 4',c:'#FF2D55'}:{s:'Stage 5',c:'#CC0033'};gfrStage.innerHTML=`<span class="gfr-dot" style="background:${s.c}"></span><span style="color:${s.c};font-weight:600;font-size:.8rem;">${s.s}</span>`;}
gfrIn&&gfrIn.addEventListener('input',()=>updateGFR(gfrIn.value));updateGFR(gfrIn?.value);
const heightInput=document.getElementById('heightInput'),weightInput=document.getElementById('weightInput'),bmiInput=document.getElementById('bmiInput');
function updateBMI(){const h=parseFloat(heightInput?.value),w=parseFloat(weightInput?.value);if(Number.isFinite(h)&&h>0&&Number.isFinite(w)){bmiInput.value=(w/((h/100)**2)).toFixed(10);}else{bmiInput.value='';}}
heightInput&&heightInput.addEventListener('input',updateBMI);weightInput&&weightInput.addEventListener('input',updateBMI);updateBMI();
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
