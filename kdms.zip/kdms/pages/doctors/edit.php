<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin']);
$id=(int)($_GET['id']??0); if(!$id){flash('danger','Invalid.');redirect('/pages/doctors/index.php');}
$doc=Database::fetchOne("SELECT * FROM doctors WHERE doctor_id=?",[$id]);
if(!$doc){flash('danger','Not found.');redirect('/pages/doctors/index.php');}
$errors=[]; $hospitals=Database::fetchAll("SELECT hospital_id,name,city,country FROM hospitals WHERE is_active=1 ORDER BY name");
$specs=['Nephrology','Transplant Surgery','Urology','Immunology','Anesthesiology','Pathology','Other'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_verify(); $old=$doc;
    $name=trim($_POST['name']??''); $spec=trim($_POST['specialization']??'');
    $bmdc=trim($_POST['bmdc_reg_no']??'')?:null; $phone=trim($_POST['phone']??'');
    $email=trim($_POST['email']??''); $hosp_id=(int)($_POST['hospital_id']??0)?:null;
    $yrs=(int)($_POST['years_exp']??0)?:null; $bio=trim($_POST['bio']??'');
    if(!$name) $errors[]='Name required.';
    if(!$errors){
        try{
            Database::execute("UPDATE doctors SET name=?,specialization=?,bmdc_reg_no=?,phone=?,email=?,hospital_id=?,years_exp=?,bio=? WHERE doctor_id=?",[$name,$spec,$bmdc,$phone,$email,$hosp_id,$yrs,$bio,$id]);
            log_action('UPDATE','doctors',$id,$old,['name'=>$name]);
            flash('success','Doctor updated.'); redirect('/pages/doctors/view.php?id='.$id);
        }catch(PDOException $e){ $errors[]='DB error: '.$e->getMessage(); }
    }
    $doc=array_merge($doc,$_POST);
}
$page_title='Edit Doctor';
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/doctors/index.php')?>">Doctors</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Edit</span></div>
<div class="page-header"><div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-pen-to-square"></i></div><div><h1>Edit Doctor</h1><p class="text-sm text-muted"><?=e($doc['name'])?></p></div></div><div class="page-actions"><a href="<?=base_url('/pages/doctors/view.php?id='.$id)?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div></div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>
<div class="glass-card no-hover"><div class="card-body"><form method="POST" class="kdms-form" novalidate><?=csrf_field()?>
<div class="form-grid form-grid-3">
    <div class="form-group" style="grid-column:span 2;"><label>Name <span class="req">*</span></label><input type="text" name="name" value="<?=e($doc['name'])?>" required maxlength="100"></div>
    <div class="form-group"><label>Specialization</label><select name="specialization"><?php foreach($specs as $s): ?><option value="<?=$s?>" <?=$doc['specialization']===$s?'selected':''?>><?=$s?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>BMDC Reg No</label><input type="text" name="bmdc_reg_no" value="<?=e($doc['bmdc_reg_no']??'')?>" maxlength="20"></div>
    <div class="form-group"><label>Phone</label><input type="tel" name="phone" value="<?=e($doc['phone']??'')?>" maxlength="20"></div>
    <div class="form-group"><label>Email</label><input type="email" name="email" value="<?=e($doc['email']??'')?>" maxlength="120"></div>
    <div class="form-group"><label>Hospital</label><select name="hospital_id"><option value="">— None —</option><?php foreach($hospitals as $h): ?><option value="<?=(int)$h['hospital_id']?>" <?=((int)$doc['hospital_id'])===(int)$h['hospital_id']?'selected':''?>><?=e($h['name'])?> (<?=e($h['city'])?>, <?=e($h['country'])?>)</option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Years Experience</label><input type="number" name="years_exp" value="<?=e($doc['years_exp']??'')?>" min="0" max="60"></div>
    <div class="form-group full"><label>Biography</label><textarea name="bio" rows="3"><?=e($doc['bio']??'')?></textarea></div>
</div>
<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;"><a href="<?=base_url('/pages/doctors/view.php?id='.$id)?>" class="btn btn-ghost">Cancel</a><button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button></div>
</form></div></div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
