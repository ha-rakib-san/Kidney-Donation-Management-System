<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin']);
$page_title='Add Doctor'; $errors=[];
$hospitals=Database::fetchAll("SELECT hospital_id,name,city,country FROM hospitals WHERE is_active=1 ORDER BY name");
$specs=['Nephrology','Transplant Surgery','Urology','Immunology','Anesthesiology','Pathology','Other'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    csrf_verify();
    $name=trim($_POST['name']??''); $spec=trim($_POST['specialization']??'');
    $bmdc=trim($_POST['bmdc_reg_no']??'')?:null; $phone=trim($_POST['phone']??'');
    $email=trim($_POST['email']??''); $hosp_id=(int)($_POST['hospital_id']??0)?:null;
    $yrs=(int)($_POST['years_exp']??0)?:null; $bio=trim($_POST['bio']??'');
    if(!$name) $errors[]='Name required.'; if(!$spec) $errors[]='Specialization required.';
    if(!$errors){
        try{
            $id=Database::execute("INSERT INTO doctors (name,specialization,bmdc_reg_no,phone,email,hospital_id,years_exp,bio) VALUES (?,?,?,?,?,?,?,?)",[$name,$spec,$bmdc,$phone,$email,$hosp_id,$yrs,$bio]);
            log_action('CREATE','doctors',(int)$id,null,['name'=>$name,'specialization'=>$spec]);
            flash('success',"Dr. {$name} added."); redirect('/pages/doctors/index.php');
        }catch(PDOException $e){ $errors[]='DB error: '.$e->getMessage(); }
    }
}
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/doctors/index.php')?>">Doctors</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Add Doctor</span></div>
<div class="page-header"><div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-user-doctor"></i></div><div><h1>Add Doctor</h1></div></div><div class="page-actions"><a href="<?=base_url('/pages/doctors/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div></div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>
<div class="glass-card no-hover"><div class="card-body"><form method="POST" class="kdms-form" novalidate><?=csrf_field()?>
<div class="form-grid form-grid-3">
    <div class="form-group" style="grid-column:span 2;"><label>Full Name <span class="req">*</span></label><input type="text" name="name" value="<?=e($_POST['name']??'')?>" required maxlength="100" placeholder="e.g. Dr. Aminul Islam"></div>
    <div class="form-group"><label>Specialization <span class="req">*</span></label><select name="specialization" required><option value="">Select…</option><?php foreach($specs as $s): ?><option value="<?=$s?>" <?=($_POST['specialization']??'')===$s?'selected':''?>><?=$s?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>BMDC Reg No</label><input type="text" name="bmdc_reg_no" value="<?=e($_POST['bmdc_reg_no']??'')?>" maxlength="20"></div>
    <div class="form-group"><label>Phone</label><input type="tel" name="phone" value="<?=e($_POST['phone']??'')?>" maxlength="20"></div>
    <div class="form-group"><label>Email</label><input type="email" name="email" value="<?=e($_POST['email']??'')?>" maxlength="120"></div>
    <div class="form-group"><label>Hospital</label><select name="hospital_id"><option value="">— None —</option><?php foreach($hospitals as $h): ?><option value="<?=(int)$h['hospital_id']?>" <?=((int)($_POST['hospital_id']??0))===(int)$h['hospital_id']?'selected':''?>><?=e($h['name'])?> (<?=e($h['city'])?>, <?=e($h['country'])?>)</option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Years Experience</label><input type="number" name="years_exp" value="<?=e($_POST['years_exp']??'')?>" min="0" max="60"></div>
    <div class="form-group full"><label>Biography</label><textarea name="bio" rows="3" placeholder="Professional background…"><?=e($_POST['bio']??'')?></textarea></div>
</div>
<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;"><a href="<?=base_url('/pages/doctors/index.php')?>" class="btn btn-ghost">Cancel</a><button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Doctor</button></div>
</form></div></div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
