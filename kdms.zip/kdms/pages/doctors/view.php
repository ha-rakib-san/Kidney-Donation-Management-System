<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','auditor']);
$id=(int)($_GET['id']??0); if(!$id){flash('danger','Invalid.');redirect('/pages/doctors/index.php');}
$doc=Database::fetchOne("SELECT d.*,h.name AS hospital_name,h.city AS hospital_city,h.country AS hospital_country FROM doctors d LEFT JOIN hospitals h ON d.hospital_id=h.hospital_id WHERE d.doctor_id=?",[$id]);
if(!$doc){flash('danger','Not found.');redirect('/pages/doctors/index.php');}
$txCount=(int)(Database::fetchOne("SELECT COUNT(*) AS c FROM transplants WHERE doctor_id=?",[$id])['c']??0);
$txSuccess=(int)(Database::fetchOne("SELECT COUNT(*) AS c FROM transplants WHERE doctor_id=? AND result='Successful'",[$id])['c']??0);
$fuCount=(int)(Database::fetchOne("SELECT COUNT(*) AS c FROM follow_ups fu JOIN transplants t ON fu.transplant_id=t.transplant_id WHERE t.doctor_id=?",[$id])['c']??0);
$rate=$txCount>0?round($txSuccess*100/$txCount,1):0;
$recentTx=Database::fetchAll("SELECT t.*,d2.name AS donor_name,r.name AS recipient_name FROM transplants t JOIN compatibility_matches cm ON t.match_id=cm.match_id JOIN donors d2 ON cm.donor_id=d2.donor_id JOIN recipients r ON cm.recipient_id=r.recipient_id WHERE t.doctor_id=? ORDER BY t.surgery_date DESC LIMIT 5",[$id]);
$page_title='Dr. '.$doc['name'];
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/doctors/index.php')?>">Doctors</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current"><?=e($doc['name'])?></span></div>
<div class="page-header">
    <div class="page-header-left"><div class="avatar-circle" style="width:56px;height:56px;font-size:1.2rem;background:rgba(0,212,255,0.12);color:var(--accent-cyan);"><?=strtoupper(substr($doc['name'],0,2))?></div><div><h1><?=e($doc['name'])?></h1><div class="d-flex gap-2 mt-1"><span class="badge badge-info"><?=e($doc['specialization'])?></span><?php if($doc['hospital_name']): ?><span class="badge badge-muted"><?=e($doc['hospital_name'])?></span><?php endif; ?></div></div></div>
    <div class="page-actions"><?php if(has_role(['superadmin','admin'])): ?><a href="<?=base_url('/pages/doctors/edit.php?id='.$id)?>" class="btn btn-info"><i class="fa-solid fa-pen"></i> Edit</a><button class="btn btn-danger" data-delete="<?=base_url('/pages/doctors/delete.php')?>" data-id="<?=$id?>" data-msg="Deactivate Dr. <?=e($doc['name'])?>?"><i class="fa-solid fa-trash-can"></i></button><?php endif; ?><a href="<?=base_url('/pages/doctors/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<div class="stat-grid mb-4" style="grid-template-columns:repeat(4,1fr);">
    <div class="glass-card stat-card"><div class="stat-icon icon-purple"><i class="fa-solid fa-scalpel"></i></div><div class="stat-content"><div class="stat-value td-mono" data-count="<?=$txCount?>"><?=$txCount?></div><div class="stat-label">Total Transplants</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-green"><i class="fa-solid fa-circle-check"></i></div><div class="stat-content"><div class="stat-value td-mono" style="color:var(--accent-green);"><?=$txSuccess?></div><div class="stat-label">Successful</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-cyan"><i class="fa-solid fa-percent"></i></div><div class="stat-content"><div class="stat-value td-mono" style="color:var(--accent-cyan);"><?=$rate?>%</div><div class="stat-label">Success Rate</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-blue"><i class="fa-solid fa-clipboard-list"></i></div><div class="stat-content"><div class="stat-value td-mono"><?=$fuCount?></div><div class="stat-label">Follow-Ups</div></div></div>
</div>
<div class="detail-grid mb-4">
    <div class="glass-card no-hover"><div class="card-header"><h3>Professional Details</h3></div><div class="card-body"><div class="detail-section">
        <div class="detail-row"><span class="detail-label">Name</span><span class="detail-value"><?=e($doc['name'])?></span></div>
        <div class="detail-row"><span class="detail-label">Specialization</span><span class="detail-value"><span class="badge badge-info"><?=e($doc['specialization'])?></span></span></div>
        <div class="detail-row"><span class="detail-label">BMDC Reg</span><span class="detail-value td-mono"><?=e($doc['bmdc_reg_no']??'—')?></span></div>
        <div class="detail-row"><span class="detail-label">Phone</span><span class="detail-value"><?=e($doc['phone']??'—')?></span></div>
        <div class="detail-row"><span class="detail-label">Email</span><span class="detail-value"><?=e($doc['email']??'—')?></span></div>
        <div class="detail-row"><span class="detail-label">Hospital</span><span class="detail-value"><?=e($doc['hospital_name']??'—')?></span></div>
        <div class="detail-row"><span class="detail-label">Experience</span><span class="detail-value"><?=$doc['years_exp']?e($doc['years_exp']).' years':'—'?></span></div>
        <?php if($doc['bio']): ?><hr class="detail-divider"><div class="detail-row" style="flex-direction:column;gap:6px;"><span class="detail-label">Biography</span><span class="detail-value text-sm"><?=nl2br(e($doc['bio']))?></span></div><?php endif; ?>
    </div></div></div>
    <div class="glass-card no-hover"><div class="card-header"><h3><i class="fa-solid fa-scalpel text-purple" style="margin-right:8px;"></i>Recent Transplants</h3></div><div class="table-wrap">
        <?php if($recentTx): ?><table><thead><tr><th>Date</th><th>Donor → Recipient</th><th>Result</th></tr></thead><tbody>
        <?php foreach($recentTx as $t): ?><tr><td class="td-mono text-muted"><?=fmt_date($t['surgery_date'])?></td><td><div style="font-size:.82rem;"><?=e($t['donor_name'])?> → <?=e($t['recipient_name'])?></div></td><td><span class="badge <?=status_class($t['result'])?>"><?=e($t['result'])?></span></td></tr><?php endforeach; ?>
        </tbody></table><?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-scalpel"></i></div><div class="empty-message">No transplants yet.</div></div><?php endif; ?>
    </div></div>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
