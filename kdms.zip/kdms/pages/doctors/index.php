<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','auditor']);
$page_title='Doctors';
$search=trim($_GET['search']??''); $spec=trim($_GET['specialization']??''); $hosp_f=(int)($_GET['hospital_id']??0);
$page=max(1,(int)($_GET['page']??1)); $per_page=20;
$where=['1=1']; $params=[];
if($search){$where[]='d.name LIKE ?';$params[]='%'.$search.'%';}
if($spec){$where[]='d.specialization=?';$params[]=$spec;}
if($hosp_f){$where[]='d.hospital_id=?';$params[]=$hosp_f;}
$ws=implode(' AND ',$where);
$total=(int)(Database::fetchOne("SELECT COUNT(*) AS c FROM doctors d WHERE $ws",$params)['c']??0);
$pages=(int)ceil($total/$per_page); $offset=($page-1)*$per_page;
$doctors=Database::fetchAll("SELECT d.*,h.name AS hospital_name FROM doctors d LEFT JOIN hospitals h ON d.hospital_id=h.hospital_id WHERE $ws AND d.is_active=1 ORDER BY d.name LIMIT $per_page OFFSET $offset",$params);
$hospitals=Database::fetchAll("SELECT hospital_id,name FROM hospitals WHERE is_active=1 ORDER BY name");
$specs=['Nephrology','Transplant Surgery','Urology','Immunology','Anesthesiology','Pathology','Other'];
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Doctors</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-user-doctor"></i></div><div><h1>Doctors</h1><p class="text-sm text-muted">Medical specialists</p></div><span class="count-badge"><?=$total?></span></div>
    <div class="page-actions"><?php if(has_role(['superadmin','admin'])): ?><a href="<?=base_url('/pages/doctors/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Doctor</a><?php endif; ?><button class="btn btn-ghost" data-export-csv="mainTable" data-filename="doctors.csv"><i class="fa-solid fa-file-csv"></i> Export</button></div>
</div>
<div class="glass-card no-hover">
<form method="GET"><div class="filter-bar">
    <div class="form-group"><label>Search</label><input type="text" name="search" value="<?=e($search)?>" placeholder="Doctor name…"></div>
    <div class="form-group"><label>Specialization</label><select name="specialization"><option value="">All</option><?php foreach($specs as $s): ?><option value="<?=$s?>" <?=$spec===$s?'selected':''?>><?=$s?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Hospital</label><select name="hospital_id"><option value="">All Hospitals</option><?php foreach($hospitals as $h): ?><option value="<?=(int)$h['hospital_id']?>" <?=$hosp_f===(int)$h['hospital_id']?'selected':''?>><?=e($h['name'])?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>&nbsp;</label><div class="btn-group"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button><a href="<?=base_url('/pages/doctors/index.php')?>" class="btn btn-ghost btn-sm">Clear</a></div></div>
</div></form>
<div class="table-wrap"><?php if($doctors): ?>
<table id="mainTable"><thead><tr><th data-sort="name">Doctor</th><th>Specialization</th><th>BMDC Reg</th><th>Hospital</th><th>Experience</th><th>Transplants Done</th><th class="no-export">Actions</th></tr></thead><tbody>
<?php foreach($doctors as $d): ?>
<tr>
    <td><div class="d-flex align-center gap-2"><div class="avatar-circle" style="background:rgba(0,212,255,0.12);color:var(--accent-cyan);"><?=strtoupper(substr($d['name'],0,2))?></div><div><div style="font-weight:600;font-size:.88rem;" data-col="name"><?=e($d['name'])?></div><div style="font-size:.72rem;color:var(--text-muted);"><?=e($d['email']??'')?></div></div></div></td>
    <td><span class="badge badge-info text-xs"><?=e($d['specialization'])?></span></td>
    <td class="td-mono text-sm"><?=e($d['bmdc_reg_no']??'—')?></td>
    <td style="font-size:.82rem;"><?=e($d['hospital_name']??'—')?></td>
    <td class="td-mono"><?=$d['years_exp']?e($d['years_exp']).' yrs':'—'?></td>
    <td><span class="td-mono text-green" style="font-size:1rem;"><?=(int)$d['transplants_done']?></span></td>
    <td class="no-export"><div class="btn-group">
        <a href="<?=base_url('/pages/doctors/view.php?id='.(int)$d['doctor_id'])?>" class="btn btn-info btn-xs"><i class="fa-solid fa-eye"></i></a>
        <?php if(has_role(['superadmin','admin'])): ?>
        <a href="<?=base_url('/pages/doctors/edit.php?id='.(int)$d['doctor_id'])?>" class="btn btn-ghost btn-xs"><i class="fa-solid fa-pen"></i></a>
        <button class="btn btn-danger btn-xs" data-delete="<?=base_url('/pages/doctors/delete.php')?>" data-id="<?=(int)$d['doctor_id']?>" data-msg="Deactivate Dr. <?=e($d['name'])?>?"><i class="fa-solid fa-trash-can"></i></button>
        <?php endif; ?>
    </div></td>
</tr>
<?php endforeach; ?>
</tbody></table>
<?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-user-doctor"></i></div><div class="empty-title">No Doctors Found</div><?php if(has_role(['superadmin','admin'])): ?><a href="<?=base_url('/pages/doctors/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Doctor</a><?php endif; ?></div><?php endif; ?>
</div>
<?php if($pages>1): ?><div class="pagination"><?php if($page>1): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page-1]))?>" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?><?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$p]))?>" class="page-btn <?=$p===$page?'active':''?>"><?=$p?></a><?php endfor; ?><?php if($page<$pages): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page+1]))?>" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?><span class="pagination-info"><?=$total?> records</span></div><?php endif; ?>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
