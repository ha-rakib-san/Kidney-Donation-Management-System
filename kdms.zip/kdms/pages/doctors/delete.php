<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin']);
if($_SERVER['REQUEST_METHOD']!=='POST'){redirect('/pages/doctors/index.php');}
csrf_verify();
$id=(int)($_POST['id']??0);
$d=Database::fetchOne("SELECT name FROM doctors WHERE doctor_id=?",[$id]);
if(!$d){flash('danger','Not found.');redirect('/pages/doctors/index.php');}
try{
    Database::execute("UPDATE doctors SET is_active=0 WHERE doctor_id=?",[$id]);
    log_action('DELETE','doctors',$id,['name'=>$d['name']]);
    flash('success',"Dr. {$d['name']} deactivated.");
}catch(PDOException $e){flash('danger','Error: '.$e->getMessage());}
redirect('/pages/doctors/index.php');
