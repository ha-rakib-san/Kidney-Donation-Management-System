<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_role(['superadmin','admin','doctor','auditor']);
$page_title = 'Advanced Donor Search';

$blood    = trim($_GET['blood_group'] ?? '');
$country  = trim($_GET['country']     ?? '');
$city     = trim($_GET['city']        ?? '');
$dtype    = trim($_GET['donor_type']  ?? '');
$hla      = trim($_GET['hla_type']    ?? '');
$cross    = trim($_GET['crossmatch']  ?? '');
$name     = trim($_GET['name']        ?? '');
$searched = !empty($_GET);

$results = [];
if ($searched) {
    // NOTE: this used to run MySQL's MATCH(...) AGAINST(...) full-text search.
    // SQLite has no equivalent operator (see sql/01_schema.sql header for why
    // the FTS5 virtual-table approach was dropped). A LIKE search on the
    // indexed `name` column is the portable replacement — see
    // Procedures::searchDonors() for the same logic used by api/search_donors.php.
    $where = ["d.status='Available'"];
    $params = [];
    if ($name)    { $where[] = 'd.name LIKE ?';        $params[] = '%'.$name.'%'; }
    if ($blood)   { $where[] = 'd.blood_group=?';      $params[] = $blood; }
    if ($country) { $where[] = 'd.country=?';          $params[] = $country; }
    if ($city)    { $where[] = 'd.city=?';             $params[] = $city; }
    if ($dtype)   { $where[] = 'd.donor_type=?';       $params[] = $dtype; }
    if ($hla)     { $where[] = 'mt.tissue_type_hla=?'; $params[] = $hla; }
    if ($cross)   { $where[] = 'mt.crossmatch=?';      $params[] = $cross; }
    $ws = implode(' AND ', $where);

    $results = Database::fetchAll("
        SELECT d.donor_id,d.name,d.blood_group,d.country,d.city,d.status,d.donor_type,d.contact,
               h.name AS hospital_name, mt.tissue_type_hla, mt.crossmatch AS latest_crossmatch,
               mt.gfr_numeric, mt.infection_screen
        FROM donors d
        LEFT JOIN hospitals h ON d.hospital_id=h.hospital_id
        LEFT JOIN (
            SELECT mt1.* FROM medical_tests mt1
            INNER JOIN (SELECT person_id,MAX(test_id) AS mid FROM medical_tests WHERE person_type='Donor' AND is_valid=1 GROUP BY person_id) m2 ON mt1.test_id=m2.mid
        ) mt ON d.donor_id=mt.person_id
        WHERE $ws
        ORDER BY d.name ASC, d.donor_id DESC LIMIT 50", $params);
}

$hla_types = ['DR1','DR2','DR3','DR4','DR5','DR6','DR7','DR8','DR9','DR10','DR11','DR12','DR13','DR14','DR15','DR16','DR17','DR18'];

require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Donor Search</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-magnifying-glass-chart"></i></div><div><h1>Advanced Donor Search</h1><p class="text-sm text-muted">Search the global donor registry across <?=count(KDMS_COUNTRIES)?> countries</p></div></div>
</div>

<div class="glass-card no-hover mb-4">
    <div class="card-body">
        <form method="GET">
            <div class="form-grid form-grid-3">
                <div class="form-group full"><label>Search by Name</label><input type="text" name="name" value="<?=e($name)?>" placeholder="Enter donor name…"></div>
                <div class="form-group"><label>Blood Group</label><select name="blood_group"><option value="">Any</option><?php foreach(KDMS_BLOOD_GROUPS as $bg): ?><option value="<?=e($bg)?>" <?=$blood===$bg?'selected':''?>><?=e($bg)?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Country</label>
                    <select name="country" id="searchCountry" onchange="kdmsCityCascade('searchCountry','searchCity', true)">
                        <option value="">Any</option>
                        <?php foreach(KDMS_COUNTRIES as $c): ?><option value="<?=e($c)?>" <?=$country===$c?'selected':''?>><?=e($c)?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>City</label>
                    <select name="city" id="searchCity">
                        <option value="">Any</option>
                        <?php foreach(($country ? kdms_cities_for($country) : kdms_all_cities()) as $c): ?><option value="<?=e($c)?>" <?=$city===$c?'selected':''?>><?=e($c)?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>Donor Type</label><select name="donor_type"><option value="">Any</option><option value="Living" <?=$dtype==='Living'?'selected':''?>>Living</option><option value="Deceased" <?=$dtype==='Deceased'?'selected':''?>>Deceased</option></select></div>
                <div class="form-group"><label>HLA Type</label><select name="hla_type"><option value="">Any</option><?php foreach($hla_types as $h): ?><option value="<?=e($h)?>" <?=$hla===$h?'selected':''?>><?=e($h)?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Crossmatch</label><select name="crossmatch"><option value="">Any</option><option value="Negative" <?=$cross==='Negative'?'selected':''?>>Negative</option><option value="Positive" <?=$cross==='Positive'?'selected':''?>>Positive</option></select></div>
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;padding-top:16px;">
                <a href="<?=base_url('/pages/search.php')?>" class="btn btn-ghost">Clear</a>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-magnifying-glass"></i> Search Donors</button>
            </div>
        </form>
    </div>
</div>

<?php if ($searched): ?>
<div class="glass-card no-hover">
    <div class="card-header"><h3>Search Results</h3><span class="count-badge"><?=count($results)?></span></div>
    <div class="table-wrap">
        <?php if($results): ?>
        <table id="mainTable">
            <thead><tr><th>Donor</th><th>Blood</th><th>Country</th><th>City</th><th>Type</th><th>HLA</th><th>Crossmatch</th><th>GFR</th><th>Hospital</th><th class="no-export">Actions</th></tr></thead>
            <tbody>
            <?php foreach($results as $d): $bgClass='bg-'.str_replace(['+','-'],['pos','neg'],$d['blood_group']); ?>
            <tr>
                <td><div class="d-flex align-center gap-2"><div class="avatar-circle <?=e($bgClass)?>"><?=e(strtoupper(substr($d['name'],0,1)))?></div><span style="font-weight:600;font-size:.88rem;"><?=e($d['name'])?></span></div></td>
                <td><span class="badge <?=e($bgClass)?>"><?=e($d['blood_group'])?></span></td>
                <td><?=e($d['country'])?></td>
                <td><?=e($d['city'])?></td>
                <td><span class="badge <?=$d['donor_type']==='Living'?'badge-success':'badge-purple'?>"><?=e($d['donor_type'])?></span></td>
                <td class="td-mono"><?=e($d['tissue_type_hla']??'—')?></td>
                <td><?php if($d['latest_crossmatch']): ?><span class="badge <?=$d['latest_crossmatch']==='Negative'?'badge-success':($d['latest_crossmatch']==='Positive'?'badge-danger':'badge-warning')?>"><?=e($d['latest_crossmatch'])?></span><?php else: ?>—<?php endif; ?></td>
                <td class="td-mono"><?=$d['gfr_numeric']?e($d['gfr_numeric']):'—'?></td>
                <td style="font-size:.82rem;"><?=e($d['hospital_name']??'—')?></td>
                <td class="no-export"><a href="<?=base_url('/pages/donors/view.php?id='.(int)$d['donor_id'])?>" class="btn btn-info btn-xs"><i class="fa-solid fa-eye"></i> View</a></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-magnifying-glass"></i></div><div class="empty-title">No Matching Donors</div><div class="empty-message">Try adjusting your search criteria.</div></div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>
<script>window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
