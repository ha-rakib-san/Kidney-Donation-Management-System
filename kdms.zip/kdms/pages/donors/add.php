<?php
/**
 * KDMS Pro — Add Donor
 */
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_role(['superadmin','admin','doctor']);

$page_title = 'Add Donor';
$errors     = [];

$hospitals = Database::fetchAll("SELECT hospital_id, name, city, country FROM hospitals WHERE is_active=1 ORDER BY name");
$blood_groups = KDMS_BLOOD_GROUPS;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $name     = trim($_POST['name']      ?? '');
    $dob      = trim($_POST['dob']       ?? '');
    $gender   = trim($_POST['gender']    ?? '');
    $blood    = trim($_POST['blood_group'] ?? '');
    $country  = trim($_POST['country']   ?? '');
    $city     = trim($_POST['city']      ?? '');
    $address  = trim($_POST['address']   ?? '');
    $contact  = trim($_POST['contact']   ?? '');
    $email    = trim($_POST['email']     ?? '');
    $emerg    = trim($_POST['emergency_contact'] ?? '');
    $dtype    = trim($_POST['donor_type']  ?? 'Living');
    $status   = trim($_POST['status']      ?? 'Available');
    $hosp_id  = (int)($_POST['hospital_id'] ?? 0) ?: null;
    $consent  = !empty($_POST['consent_signed']) ? 1 : 0;
    $cons_date= $consent ? trim($_POST['consent_date'] ?? '') : null;
    $med_hist = trim($_POST['medical_history'] ?? '');
    $notes    = trim($_POST['notes']     ?? '');
    $nid      = trim($_POST['nid']       ?? '') ?: null;

    // Validate
    if (!$name)    $errors[] = 'Full name is required.';
    if (!$blood || !in_array($blood, $blood_groups)) $errors[] = 'Valid blood group is required.';
    if (!$gender)  $errors[] = 'Gender is required.';
    if (!$country) $errors[] = 'Country is required.';
    if (!$city)    $errors[] = 'City is required.';
    if ($dob) {
        $age = (int)((time() - strtotime($dob)) / 31557600);
        if ($age < 18) $errors[] = 'Donor must be at least 18 years old.';
        if ($age > 65) $errors[] = 'Donor age cannot exceed 65 years.';
    }

    if (!$errors) {
        try {
            $id = Database::execute(
                "INSERT INTO donors (name,dob,gender,blood_group,country,city,address,contact,email,
                 emergency_contact,donor_type,status,hospital_id,registered_by,consent_signed,
                 consent_date,medical_history,notes,nid)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [$name,$dob?:null,$gender,$blood,$country,$city,$address,$contact,$email,
                 $emerg,$dtype,$status,$hosp_id,current_user()['user_id'],$consent,
                 $cons_date?:null,$med_hist,$notes,$nid]
            );
            log_action('CREATE','donors',(int)$id,null,
                ['name'=>$name,'blood_group'=>$blood,'country'=>$country,'city'=>$city,'donor_type'=>$dtype]);
            flash('success', "Donor '{$name}' added successfully.");
            redirect('/pages/donors/index.php');
        } catch (PDOException $e) {
            if (str_contains($e->getMessage(), 'Donor must be')) {
                $errors[] = 'Database: Donor age validation failed.';
            } elseif (str_contains($e->getMessage(), 'nid')) {
                $errors[] = 'This NID number is already registered.';
            } else {
                $errors[] = 'Database error: ' . $e->getMessage();
            }
        }
    }
}

require_once KDMS_ROOT . '/includes/header.php';
?>

<div class="breadcrumb">
    <a href="<?= base_url('/pages/dashboard.php') ?>">Dashboard</a>
    <span class="breadcrumb-sep">›</span>
    <a href="<?= base_url('/pages/donors/index.php') ?>">Donors</a>
    <span class="breadcrumb-sep">›</span>
    <span class="breadcrumb-current">Add Donor</span>
</div>

<div class="page-header">
    <div class="page-header-left">
        <div class="page-icon"><i class="fa-solid fa-user-plus"></i></div>
        <div><h1>Add New Donor</h1><p class="text-sm text-muted">Register a new kidney donor</p></div>
    </div>
    <div class="page-actions">
        <a href="<?= base_url('/pages/donors/index.php') ?>" class="btn btn-ghost">
            <i class="fa-solid fa-arrow-left"></i> Back to Donors
        </a>
    </div>
</div>

<?php if ($errors): ?>
<div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;" role="alert">
    <span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span>
    <div>
        <?php foreach ($errors as $e): ?>
        <div class="flash-text"><?= e($e) ?></div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<div class="glass-card no-hover">
    <div class="card-header">
        <h3><i class="fa-solid fa-heart-pulse text-cyan" style="margin-right:8px;"></i>Donor Information</h3>
        <span class="badge badge-muted">All <span style="color:var(--accent-crimson);">*</span> fields required</span>
    </div>
    <div class="card-body">
        <form method="POST" class="kdms-form" novalidate>
            <?= csrf_field() ?>

            <div class="form-grid form-grid-3">
                <div class="form-group">
                    <label for="name">Full Name <span class="req">*</span></label>
                    <input type="text" id="name" name="name" value="<?= e($_POST['name'] ?? '') ?>" placeholder="e.g. Md. Rakibul Hasan" required maxlength="100">
                </div>
                <div class="form-group">
                    <label for="nid">National ID (NID)</label>
                    <input type="text" id="nid" name="nid" value="<?= e($_POST['nid'] ?? '') ?>" placeholder="10 or 17 digit NID" maxlength="20">
                </div>
                <div class="form-group">
                    <label for="dob">Date of Birth <span class="req">*</span></label>
                    <input type="date" id="dob" name="dob" value="<?= e($_POST['dob'] ?? '') ?>"
                           max="<?= date('Y-m-d', strtotime('-18 years')) ?>"
                           min="<?= date('Y-m-d', strtotime('-65 years')) ?>"
                           required>
                    <span class="form-help" id="ageDisplay"></span>
                </div>
                <div class="form-group">
                    <label for="gender">Gender <span class="req">*</span></label>
                    <select id="gender" name="gender" required>
                        <option value="">Select gender…</option>
                        <?php foreach (['Male','Female','Other'] as $g): ?>
                        <option value="<?= $g ?>" <?= ($_POST['gender'] ?? '') === $g ? 'selected' : '' ?>><?= $g ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="blood_group">Blood Group <span class="req">*</span></label>
                    <select id="blood_group" name="blood_group" required>
                        <option value="">Select blood group…</option>
                        <?php foreach ($blood_groups as $bg): ?>
                        <option value="<?= $bg ?>" <?= ($_POST['blood_group'] ?? '') === $bg ? 'selected' : '' ?>><?= $bg ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="country">Country <span class="req">*</span></label>
                    <?= kdms_country_select('country', $_POST['country'] ?? null, 'onchange="kdmsCityCascade(\'country\',\'city\')"') ?>
                </div>
                <div class="form-group">
                    <label for="city">City <span class="req">*</span></label>
                    <?= kdms_city_select('city', $_POST['country'] ?? null, $_POST['city'] ?? null) ?>
                </div>
                <div class="form-group">
                    <label for="contact">Phone Number</label>
                    <input type="tel" id="contact" name="contact" value="<?= e($_POST['contact'] ?? '') ?>" placeholder="01XXXXXXXXX" maxlength="20">
                </div>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" placeholder="email@example.com" maxlength="120">
                </div>
                <div class="form-group">
                    <label for="emergency_contact">Emergency Contact</label>
                    <input type="tel" id="emergency_contact" name="emergency_contact" value="<?= e($_POST['emergency_contact'] ?? '') ?>" placeholder="01XXXXXXXXX" maxlength="20">
                </div>
                <div class="form-group">
                    <label for="donor_type">Donor Type <span class="req">*</span></label>
                    <select id="donor_type" name="donor_type" required>
                        <option value="Living"   <?= ($_POST['donor_type'] ?? 'Living') === 'Living'   ? 'selected' : '' ?>>Living</option>
                        <option value="Deceased" <?= ($_POST['donor_type'] ?? '') === 'Deceased' ? 'selected' : '' ?>>Deceased</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status">Status <span class="req">*</span></label>
                    <select id="status" name="status" required>
                        <?php foreach (['Available','Unavailable','Suspended'] as $s): ?>
                        <option value="<?= $s ?>" <?= ($_POST['status'] ?? 'Available') === $s ? 'selected' : '' ?>><?= $s ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="hospital_id">Assigned Hospital</label>
                    <select id="hospital_id" name="hospital_id">
                        <option value="">— No Hospital —</option>
                        <?php foreach ($hospitals as $h): ?>
                        <option value="<?= (int)$h['hospital_id'] ?>" <?= ((int)($_POST['hospital_id'] ?? 0)) === (int)$h['hospital_id'] ? 'selected' : '' ?>>
                            <?= e($h['name']) ?> (<?= e($h['city']) ?>, <?= e($h['country']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group full">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" rows="2" placeholder="Full address…"><?= e($_POST['address'] ?? '') ?></textarea>
                </div>
                <div class="form-group full">
                    <label for="medical_history">Medical History</label>
                    <textarea id="medical_history" name="medical_history" rows="3" placeholder="Relevant medical history, conditions, medications…"><?= e($_POST['medical_history'] ?? '') ?></textarea>
                </div>
                <div class="form-group full">
                    <label for="notes">Additional Notes</label>
                    <textarea id="notes" name="notes" rows="2" placeholder="Any additional notes…"><?= e($_POST['notes'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- Consent -->
            <div class="glass-card no-hover mt-3" style="padding:18px 20px;">
                <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
                    <label class="login-remember" style="margin:0;">
                        <input type="checkbox" name="consent_signed" value="1" id="consent_signed"
                               <?= !empty($_POST['consent_signed']) ? 'checked' : '' ?>>
                        Informed consent obtained and signed by donor
                    </label>
                    <div class="form-group" id="consent_date_wrap" style="margin:0;<?= empty($_POST['consent_signed']) ? 'display:none;' : '' ?>">
                        <input type="date" name="consent_date" value="<?= e($_POST['consent_date'] ?? date('Y-m-d')) ?>" style="padding:6px 12px;">
                    </div>
                </div>
            </div>

            <div class="card-footer" style="display:flex;gap:10px;justify-content:flex-end;padding:20px 0 0;">
                <a href="<?= base_url('/pages/donors/index.php') ?>" class="btn btn-ghost">Cancel</a>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-floppy-disk"></i> Save Donor
                </button>
            </div>
        </form>
    </div>
</div>

<script>
window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;
// Age display
document.getElementById('dob').addEventListener('change', function() {
    const dob = new Date(this.value);
    const age = Math.floor((Date.now() - dob.getTime()) / 31557600000);
    document.getElementById('ageDisplay').textContent = age > 0 ? `Age: ${age} years` : '';
});

// Consent date toggle
document.getElementById('consent_signed').addEventListener('change', function() {
    document.getElementById('consent_date_wrap').style.display = this.checked ? 'block' : 'none';
});
</script>

<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
