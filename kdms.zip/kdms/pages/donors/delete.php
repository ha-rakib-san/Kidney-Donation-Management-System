<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('/pages/donors/index.php'); }
csrf_verify();

$id = (int)($_POST['id'] ?? 0);
if (!$id) { flash('danger','Invalid donor ID.'); redirect('/pages/donors/index.php'); }

$donor = Database::fetchOne("SELECT name FROM donors WHERE donor_id=?", [$id]);
if (!$donor) { flash('danger','Donor not found.'); redirect('/pages/donors/index.php'); }

try {
    Database::execute("DELETE FROM donors WHERE donor_id=?", [$id]);
    log_action('DELETE','donors',$id,['name'=>$donor['name']],null,'Donor deleted by admin');
    flash('success',"Donor '{$donor['name']}' has been deleted.");
} catch (PDOException $e) {
    if (str_contains($e->getMessage(), 'Cannot delete donor')) {
        flash('danger','Cannot delete donor with active or approved compatibility matches.');
    } else {
        flash('danger','Error deleting donor: ' . $e->getMessage());
    }
}
redirect('/pages/donors/index.php');
