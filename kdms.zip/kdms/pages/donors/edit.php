<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin','doctor']);

$page_title = 'Edit Donor';
$id         = (int)($_GET['id'] ?? 0);
if (!$id) { flash('danger','Invalid donor ID.'); redirect('/pages/donors/index.php'); }

$donor = Database::fetchOne("SELECT * FROM donors WHERE donor_id=?", [$id]);
if (!$donor) { flash('danger','Donor not found.'); redirect('/pages/donors/index.php'); }

$errors    = [];
$hospitals = Database::fetchAll("SELECT hospital_id,name,city,country FROM hospitals WHERE is_active=1 ORDER BY name");
$blood_groups = KDMS_BLOOD_GROUPS;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $old = $donor;

    $name    = trim($_POST['name']         ?? '');
    $dob     = trim($_POST['dob']          ?? '');
    $gender  = trim($_POST['gender']       ?? '');
    $blood   = trim($_POST['blood_group']  ?? '');
    $country = trim($_POST['country']      ?? '');
    $city    = trim($_POST['city']         ?? '');
    $address = trim($_POST['address']      ?? '');
    $contact = trim($_POST['contact']      ?? '');
    $email   = trim($_POST['email']        ?? '');
    $emerg   = trim($_POST['emergency_contact'] ?? '');
    $dtype   = trim($_POST['donor_type']   ?? 'Living');
    $status  = trim($_POST['status']       ?? 'Available');
    $hosp_id = (int)($_POST['hospital_id'] ?? 0) ?: null;
    $consent = !empty($_POST['consent_signed']) ? 1 : 0;
    $cons_date = $consent ? (trim($_POST['consent_date'] ?? '') ?: null) : null;
    $med_hist  = trim($_POST['medical_history'] ?? '');
    $notes     = trim($_POST['notes']      ?? '');
    $nid       = trim($_POST['nid']        ?? '') ?: null;

    if (!$name)  $errors[] = 'Full name is required.';
    if (!$blood || !in_array($blood, $blood_groups)) $errors[] = 'Valid blood group required.';
    if (!$gender)  $errors[] = 'Gender is required.';
    if (!$country) $errors[] = 'Country is required.';
    if (!$city)    $errors[] = 'City is required.';

    if (!$errors) {
        try {
            Database::execute(
                "UPDATE donors SET name=?,dob=?,gender=?,blood_group=?,country=?,city=?,address=?,contact=?,
                 email=?,emergency_contact=?,donor_type=?,status=?,hospital_id=?,consent_signed=?,
                 consent_date=?,medical_history=?,notes=?,nid=?,updated_at=CURRENT_TIMESTAMP WHERE donor_id=?",
                [$name,$dob?:null,$gender,$blood,$country,$city,$address,$contact,$email,
                 $emerg,$dtype,$status,$hosp_id,$consent,$cons_date,$med_hist,$notes,$nid,$id]
            );
            Procedures::recalculateMatchesForPerson($id, 'Donor');
            log_action('UPDATE','donors',$id,$old,
                ['name'=>$name,'blood_group'=>$blood,'status'=>$status]);
            flash('success',"Donor '{$name}' updated successfully.");
            redirect('/pages/donors/view.php?id='.$id);
        } catch (PDOException $e) {
            $errors[] = 'Database error: ' . $e->getMessage();
        }
    }
    // Re-populate form with POST data on error
    $donor = array_merge($donor, $_POST);
}

require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb">
    <a href="<?= base_url('/pages/dashboard.php') ?>">Dashboard</a><span class="breadcrumb-sep">›</span>
    <a href="<?= base_url('/pages/donors/index.php') ?>">Donors</a><span class="breadcrumb-sep">›</span>
    <a href="<?= base_url('/pages/donors/view.php?id='.$id) ?>"><?= e($donor['name']) ?></a><span class="breadcrumb-sep">›</span>
    <span class="breadcrumb-current">Edit</span>
</div>
<div class="page-header">
    <div class="page-header-left">
        <div class="page-icon"><i class="fa-solid fa-pen-to-square"></i></div>
        <div><h1>Edit Donor</h1><p class="text-sm text-muted"><?= e($donor['name']) ?></p></div>
    </div>
    <div class="page-actions">
        <a href="<?= base_url('/pages/donors/view.php?id='.$id) ?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a>
    </div>
</div>

<?php if ($errors): ?>
<div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;" role="alert">
    <span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span>
    <div><?php foreach ($errors as $err): ?><div><?= e($err) ?></div><?php endforeach; ?></div>
</div>
<?php endif; ?>

<div class="glass-card no-hover">
    <div class="card-header"><h3><i class="fa-solid fa-heart-pulse text-cyan" style="margin-right:8px;"></i>Update Donor Information</h3></div>
    <div class="card-body">
        <form method="POST" class="kdms-form" novalidate>
            <?= csrf_field() ?>
            <div class="form-grid form-grid-3">
                <div class="form-group">
                    <label for="name">Full Name <span class="req">*</span></label>
                    <input type="text" id="name" name="name" value="<?= e($donor['name']) ?>" required maxlength="100">
                </div>
                <div class="form-group">
                    <label for="nid">National ID</label>
                    <input type="text" id="nid" name="nid" value="<?= e($donor['nid'] ?? '') ?>" maxlength="20">
                </div>
                <div class="form-group">
                    <label for="dob">Date of Birth</label>
                    <input type="date" id="dob" name="dob" value="<?= e($donor['dob'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label for="gender">Gender <span class="req">*</span></label>
                    <select id="gender" name="gender" required>
                        <?php foreach (['Male','Female','Other'] as $g): ?>
                        <option value="<?= $g ?>" <?= $donor['gender'] === $g ? 'selected' : '' ?>><?= $g ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="blood_group">Blood Group <span class="req">*</span></label>
                    <select id="blood_group" name="blood_group" required>
                        <?php foreach ($blood_groups as $bg): ?>
                        <option value="<?= $bg ?>" <?= $donor['blood_group'] === $bg ? 'selected' : '' ?>><?= $bg ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="country">Country <span class="req">*</span></label>
                    <?= kdms_country_select('country', $donor['country'] ?? null, 'onchange="kdmsCityCascade(\'country\',\'city\')"') ?>
                </div>
                <div class="form-group">
                    <label for="city">City <span class="req">*</span></label>
                    <?= kdms_city_select('city', $donor['country'] ?? null, $donor['city'] ?? null) ?>
                </div>
                <div class="form-group">
                    <label for="contact">Phone</label>
                    <input type="tel" id="contact" name="contact" value="<?= e($donor['contact'] ?? '') ?>" maxlength="20">
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?= e($donor['email'] ?? '') ?>" maxlength="120">
                </div>
                <div class="form-group">
                    <label for="emergency_contact">Emergency Contact</label>
                    <input type="tel" id="emergency_contact" name="emergency_contact" value="<?= e($donor['emergency_contact'] ?? '') ?>" maxlength="20">
                </div>
                <div class="form-group">
                    <label for="donor_type">Donor Type</label>
                    <select id="donor_type" name="donor_type">
                        <option value="Living"   <?= $donor['donor_type'] === 'Living'   ? 'selected' : '' ?>>Living</option>
                        <option value="Deceased" <?= $donor['donor_type'] === 'Deceased' ? 'selected' : '' ?>>Deceased</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status">
                        <?php foreach (['Available','Unavailable','Transplanted','Suspended'] as $s): ?>
                        <option value="<?= $s ?>" <?= $donor['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="hospital_id">Hospital</label>
                    <select id="hospital_id" name="hospital_id">
                        <option value="">— None —</option>
                        <?php foreach ($hospitals as $h): ?>
                        <option value="<?= (int)$h['hospital_id'] ?>" <?= ((int)$donor['hospital_id']) === (int)$h['hospital_id'] ? 'selected' : '' ?>>
                            <?= e($h['name']) ?> (<?= e($h['city']) ?>, <?= e($h['country']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group full">
                    <label for="address">Address</label>
                    <textarea id="address" name="address" rows="2"><?= e($donor['address'] ?? '') ?></textarea>
                </div>
                <div class="form-group full">
                    <label for="medical_history">Medical History</label>
                    <textarea id="medical_history" name="medical_history" rows="3"><?= e($donor['medical_history'] ?? '') ?></textarea>
                </div>
                <div class="form-group full">
                    <label for="notes">Notes</label>
                    <textarea id="notes" name="notes" rows="2"><?= e($donor['notes'] ?? '') ?></textarea>
                </div>
            </div>
            <div class="glass-card no-hover mt-3" style="padding:16px 20px;">
                <label class="login-remember" style="margin:0;">
                    <input type="checkbox" name="consent_signed" value="1" id="consent_signed" <?= $donor['consent_signed'] ? 'checked' : '' ?>>
                    Informed consent signed
                </label>
                <div id="consent_date_wrap" style="margin-top:10px;<?= !$donor['consent_signed'] ? 'display:none;' : '' ?>">
                    <input type="date" name="consent_date" value="<?= e($donor['consent_date'] ?? '') ?>" style="padding:6px 12px;max-width:200px;">
                </div>
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;">
                <a href="<?= base_url('/pages/donors/view.php?id='.$id) ?>" class="btn btn-ghost">Cancel</a>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Changes</button>
            </div>
        </form>
    </div>
</div>
<script>
window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;
document.getElementById('consent_signed').addEventListener('change',function(){
    document.getElementById('consent_date_wrap').style.display=this.checked?'block':'none';
});
</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
