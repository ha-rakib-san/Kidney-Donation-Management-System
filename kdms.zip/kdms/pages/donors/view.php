<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','doctor','donor','auditor']);

$id = (int)($_GET['id'] ?? 0);
if (!$id) { flash('danger','Invalid donor.'); redirect('/pages/donors/index.php'); }

// Donors may only view their own profile
if (current_role() === 'donor') {
    $user = current_user();
    if ((int)($user['linked_id'] ?? 0) !== $id) { flash('danger','Access denied.'); redirect('/pages/dashboard.php'); }
}

$donor = Database::fetchOne("
    SELECT d.*, h.name AS hospital_name, h.city AS hospital_city,
           u.full_name AS registered_by_name
    FROM donors d
    LEFT JOIN hospitals h ON d.hospital_id = h.hospital_id
    LEFT JOIN users u ON d.registered_by = u.user_id
    WHERE d.donor_id=?", [$id]);

if (!$donor) { flash('danger','Donor not found.'); redirect('/pages/donors/index.php'); }

$tests = Database::fetchAll(
    "SELECT mt.*, doc.name AS doctor_name
     FROM medical_tests mt LEFT JOIN doctors doc ON mt.doctor_id=doc.doctor_id
     WHERE mt.person_id=? AND mt.person_type='Donor' ORDER BY mt.test_date DESC", [$id]);

$matches = Database::fetchAll(
    "SELECT cm.*, r.name AS recipient_name, r.blood_group AS recipient_blood
     FROM compatibility_matches cm JOIN recipients r ON cm.recipient_id=r.recipient_id
     WHERE cm.donor_id=? ORDER BY cm.match_date DESC LIMIT 10", [$id]);

$page_title = 'Donor: ' . $donor['name'];
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb">
    <a href="<?= base_url('/pages/dashboard.php') ?>">Dashboard</a><span class="breadcrumb-sep">›</span>
    <?php if (!has_role(['donor'])): ?><a href="<?= base_url('/pages/donors/index.php') ?>">Donors</a><span class="breadcrumb-sep">›</span><?php endif; ?>
    <span class="breadcrumb-current"><?= e($donor['name']) ?></span>
</div>

<div class="page-header">
    <div class="page-header-left">
        <div class="avatar-circle" style="width:56px;height:56px;font-size:1.2rem;background:rgba(0,212,255,0.15);color:var(--accent-cyan);">
            <?= strtoupper(substr($donor['name'],0,2)) ?>
        </div>
        <div>
            <h1><?= e($donor['name']) ?></h1>
            <div class="d-flex gap-2 mt-1">
                <span class="badge <?= status_class($donor['status']) ?>"><?= e($donor['status']) ?></span>
                <span class="badge badge-muted"><?= e($donor['blood_group']) ?></span>
                <span class="badge badge-muted"><?= e($donor['donor_type']) ?></span>
            </div>
        </div>
    </div>
    <div class="page-actions">
        <?php if (has_role(['superadmin','admin','doctor'])): ?>
        <a href="<?= base_url('/pages/donors/edit.php?id='.$id) ?>" class="btn btn-info">
            <i class="fa-solid fa-pen"></i> Edit
        </a>
        <?php endif; ?>
        <?php if (has_role(['superadmin','admin'])): ?>
        <button class="btn btn-danger"
            data-delete="<?= base_url('/pages/donors/delete.php') ?>"
            data-id="<?= $id ?>"
            data-msg="Permanently delete donor '<?= e($donor['name']) ?>'?">
            <i class="fa-solid fa-trash-can"></i> Delete
        </button>
        <?php endif; ?>
        <a href="<?= base_url('/pages/donors/index.php') ?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a>
    </div>
</div>

<div class="detail-grid mb-4">
    <!-- Personal Info -->
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-user text-cyan" style="margin-right:8px;"></i>Personal Details</h3></div>
        <div class="card-body">
            <div class="detail-section">
                <div class="detail-row"><span class="detail-label">Name</span><span class="detail-value"><?= e($donor['name']) ?></span></div>
                <div class="detail-row"><span class="detail-label">Date of Birth</span><span class="detail-value"><?= $donor['dob'] ? fmt_date($donor['dob']) . ' (' . calc_age($donor['dob']) . ')' : '—' ?></span></div>
                <div class="detail-row"><span class="detail-label">Gender</span><span class="detail-value"><?= e($donor['gender']) ?></span></div>
                <div class="detail-row"><span class="detail-label">Blood Group</span>
                    <span class="detail-value"><span class="badge bg-<?= str_replace(['+','-'],['pos','neg'],$donor['blood_group']) ?>"><?= e($donor['blood_group']) ?></span></span>
                </div>
                <div class="detail-row"><span class="detail-label">NID</span><span class="detail-value td-mono"><?= e($donor['nid'] ?? '—') ?></span></div>
                <div class="detail-row"><span class="detail-label">Contact</span><span class="detail-value"><?= e($donor['contact'] ?? '—') ?></span></div>
                <div class="detail-row"><span class="detail-label">Email</span><span class="detail-value"><?= e($donor['email'] ?? '—') ?></span></div>
                <div class="detail-row"><span class="detail-label">Emergency</span><span class="detail-value"><?= e($donor['emergency_contact'] ?? '—') ?></span></div>
                <div class="detail-row"><span class="detail-label">City / Country</span><span class="detail-value"><?= e($donor['city']) ?>, <?= e($donor['country']) ?></span></div>
                <div class="detail-row"><span class="detail-label">Address</span><span class="detail-value text-sm"><?= e($donor['address'] ?? '—') ?></span></div>
            </div>
        </div>
    </div>

    <!-- Donor Status & Clinical -->
    <div class="glass-card no-hover">
        <div class="card-header"><h3><i class="fa-solid fa-heart-pulse text-red" style="margin-right:8px;"></i>Clinical Details</h3></div>
        <div class="card-body">
            <div class="detail-section">
                <div class="detail-row"><span class="detail-label">Donor Type</span><span class="detail-value"><span class="badge <?= $donor['donor_type']==='Living' ? 'badge-success' : 'badge-purple' ?>"><?= e($donor['donor_type']) ?></span></span></div>
                <div class="detail-row"><span class="detail-label">Status</span><span class="detail-value"><span class="badge <?= status_class($donor['status']) ?>"><?= e($donor['status']) ?></span></span></div>
                <div class="detail-row"><span class="detail-label">Risk Score</span>
                    <span class="detail-value">
                        <span class="td-mono" style="color:<?= (int)$donor['risk_score'] < 20 ? 'var(--accent-green)' : ((int)$donor['risk_score'] < 50 ? 'var(--accent-gold)' : 'var(--accent-crimson)') ?>;">
                            <?= (int)$donor['risk_score'] ?>/100
                        </span>
                    </span>
                </div>
                <div class="detail-row"><span class="detail-label">Hospital</span><span class="detail-value"><?= e($donor['hospital_name'] ?? '—') ?></span></div>
                <div class="detail-row"><span class="detail-label">Consent</span>
                    <span class="detail-value">
                        <?php if ($donor['consent_signed']): ?>
                        <span class="badge badge-success"><i class="fa-solid fa-check"></i> Signed <?= $donor['consent_date'] ? '('.fmt_date($donor['consent_date']).')' : '' ?></span>
                        <?php else: ?>
                        <span class="badge badge-warning">Not obtained</span>
                        <?php endif; ?>
                    </span>
                </div>
                <div class="detail-row"><span class="detail-label">Registered</span><span class="detail-value td-mono"><?= fmt_datetime($donor['created_at']) ?></span></div>
                <div class="detail-row"><span class="detail-label">By</span><span class="detail-value"><?= e($donor['registered_by_name'] ?? '—') ?></span></div>
                <?php if ($donor['medical_history']): ?>
                <hr class="detail-divider">
                <div class="detail-row" style="flex-direction:column;gap:4px;">
                    <span class="detail-label">Medical History</span>
                    <span class="detail-value text-sm"><?= nl2br(e($donor['medical_history'])) ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Medical Tests -->
<div class="glass-card no-hover mb-4">
    <div class="card-header">
        <h3><i class="fa-solid fa-flask-vial text-blue" style="margin-right:8px;"></i>Medical Tests (<?= count($tests) ?>)</h3>
        <?php if (has_role(['superadmin','admin','doctor'])): ?>
        <a href="<?= base_url('/pages/tests/add.php?person_id='.$id.'&person_type=Donor') ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> Add Test</a>
        <?php endif; ?>
    </div>
    <div class="table-wrap">
        <?php if ($tests): ?>
        <table>
            <thead><tr><th>Date</th><th>Doctor</th><th>HLA</th><th>Crossmatch</th><th>GFR</th><th>Creatinine</th><th>BMI</th><th>BP</th><th>Hb</th><th>PRA</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($tests as $t): ?>
            <tr>
                <td class="td-mono"><?= fmt_date($t['test_date']) ?></td>
                <td><?= e($t['doctor_name'] ?? '—') ?></td>
                <td class="td-mono"><?= e($t['tissue_type_hla'] ?? '—') ?></td>
                <td><span class="badge <?= $t['crossmatch']==='Negative' ? 'badge-success' : ($t['crossmatch']==='Positive' ? 'badge-danger' : 'badge-warning') ?>"><?= e($t['crossmatch']) ?></span></td>
                <td class="td-mono"><?= $t['gfr_numeric']!==null ? fmt_decimal10($t['gfr_numeric']) : '—' ?></td>
                <td class="td-mono"><?= $t['creatinine_level']!==null ? fmt_decimal10($t['creatinine_level']) : '—' ?></td>
                <td class="td-mono"><?= $t['bmi']!==null ? fmt_decimal10($t['bmi']) : '—' ?></td>
                <td class="td-mono"><?= ($t['systolic_bp']!==null&&$t['diastolic_bp']!==null) ? fmt_decimal10($t['systolic_bp']).'/'.fmt_decimal10($t['diastolic_bp']) : '—' ?></td>
                <td class="td-mono"><?= $t['hemoglobin']!==null ? fmt_decimal10($t['hemoglobin']) : '—' ?></td>
                <td class="td-mono"><?= $t['pra_percentage']!==null ? fmt_decimal10($t['pra_percentage']).'%' : '—' ?></td>
                <td>
                    <a href="<?= base_url('/pages/tests/edit.php?id='.(int)$t['test_id']) ?>" class="btn btn-ghost btn-xs"><i class="fa-solid fa-pen"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-flask-vial"></i></div><div class="empty-message">No medical tests recorded yet.</div></div>
        <?php endif; ?>
    </div>
</div>

<!-- Compatibility Matches -->
<?php if (!has_role(['donor']) || count($matches)): ?>
<div class="glass-card no-hover">
    <div class="card-header"><h3><i class="fa-solid fa-dna text-purple" style="margin-right:8px;"></i>Compatibility Matches (<?= count($matches) ?>)</h3></div>
    <div class="table-wrap">
        <?php if ($matches): ?>
        <table>
            <thead><tr><th>Recipient</th><th>Blood</th><th>Score</th><th>Result</th><th>Date</th></tr></thead>
            <tbody>
            <?php foreach ($matches as $m): ?>
            <tr>
                <td><?= e($m['recipient_name']) ?></td>
                <td><span class="badge bg-<?= str_replace(['+','-'],['pos','neg'],$m['recipient_blood']) ?>"><?= e($m['recipient_blood']) ?></span></td>
                <td><div data-score-ring="<?= e(fmt_decimal10($m['match_score'])) ?>" style="width:44px;height:44px;position:relative;"></div></td>
                <td><span class="badge <?= status_class($m['review_result']) ?>"><?= e($m['review_result']) ?></span></td>
                <td class="td-mono text-muted"><?= fmt_date($m['match_date']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-dna"></i></div><div class="empty-message">No compatibility matches found.</div></div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
