<?php
/**
 * KDMS Pro — Donors List
 *
 * International edition: the city-only filter bar is replaced with a
 * country + city filter pair (includes/constants.php), and — when a
 * recipient is selected from the new "Match for a Recipient" panel — the
 * list switches into one of two recipient-relative filters:
 *
 *   sort=score    Filter 1: every Available donor ranked by compatibility
 *                 score against the chosen recipient, highest first.
 *   sort=location Filter 2: donors grouped by country — the recipient's own
 *                 country first, then other countries ordered by the
 *                 distance from their nearest donor hospital to the
 *                 recipient's hospital (closest country next, and so on).
 *                 Inside every country group, donors are ranked by
 *                 compatibility score, highest first.
 */
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin','doctor','auditor']);

$page_title = 'Donors';

$recipient_id = (int) ($_GET['recipient_id'] ?? 0);
$sort_mode    = ($_GET['sort'] ?? 'score') === 'location' ? 'location' : 'score';

$waiting_recipients = Database::fetchAll(
    "SELECT recipient_id, name, blood_group, country, city, urgency_level FROM recipients WHERE wait_status IN ('Waiting','Matched') ORDER BY name ASC"
);

$match_groups   = null; // used in location mode
$match_rows     = null; // used in score mode
$selected_recip = null;

if ($recipient_id > 0) {
    $selected_recip = Database::fetchOne('SELECT * FROM recipients WHERE recipient_id = ?', [$recipient_id]);
    if ($selected_recip) {
        $candidates = Procedures::donorsForRecipient($recipient_id);
        if ($sort_mode === 'location') {
            $match_groups = Procedures::sortByLocation($candidates, (string) $selected_recip['country']);
        } else {
            $match_rows = Procedures::sortByCompatibility($candidates);
        }
    }
}

// ─── Standard browse-mode filters (used when no recipient is selected) ──────
$filter_blood   = trim($_GET['blood_group'] ?? '');
$filter_country = trim($_GET['country']     ?? '');
$filter_city    = trim($_GET['city']        ?? '');
$filter_status  = trim($_GET['status']      ?? '');
$filter_type    = trim($_GET['type']        ?? '');
$filter_search  = trim($_GET['search']      ?? '');
$page           = max(1, (int) ($_GET['page'] ?? 1));
$per_page       = 20;

$donors = [];
$total  = 0;
$pages  = 0;

if (!$selected_recip) {
    $where  = ['1=1'];
    $params = [];
    if ($filter_blood)   { $where[] = 'd.blood_group = ?'; $params[] = $filter_blood; }
    if ($filter_country) { $where[] = 'd.country = ?';     $params[] = $filter_country; }
    if ($filter_city)    { $where[] = 'd.city = ?';        $params[] = $filter_city; }
    if ($filter_status)  { $where[] = 'd.status = ?';      $params[] = $filter_status; }
    if ($filter_type)    { $where[] = 'd.donor_type = ?';  $params[] = $filter_type; }
    if ($filter_search)  { $where[] = 'd.name LIKE ?';     $params[] = '%' . $filter_search . '%'; }

    $whereStr = implode(' AND ', $where);
    $countSql = "SELECT COUNT(*) AS cnt FROM donors d WHERE $whereStr";
    $total    = (int) (Database::fetchOne($countSql, $params)['cnt'] ?? 0);
    $pages    = (int) ceil($total / $per_page);
    $offset   = ($page - 1) * $per_page;

    $donors = Database::fetchAll("
        SELECT d.*,
               h.name AS hospital_name,
               mt.tissue_type_hla, mt.crossmatch AS latest_crossmatch,
               mt.gfr_numeric, mt.infection_screen, mt.test_date AS latest_test_date
        FROM donors d
        LEFT JOIN hospitals h ON d.hospital_id = h.hospital_id
        LEFT JOIN (
            SELECT mt1.* FROM medical_tests mt1
            INNER JOIN (SELECT person_id, MAX(test_id) AS mid FROM medical_tests WHERE person_type='Donor' AND is_valid=1 GROUP BY person_id) m2 ON mt1.test_id = m2.mid
        ) mt ON d.donor_id = mt.person_id
        WHERE $whereStr
        ORDER BY d.donor_id DESC
        LIMIT $per_page OFFSET $offset
    ", $params);
}

require_once KDMS_ROOT . '/includes/header.php';

/** Small inline renderer shared by both score-mode and location-mode rows. */
function render_match_row(array $row): void
{
    $d = $row['donor'];
    $s = $row['score'];
    $bgClass = 'bg-' . str_replace(['+', '-'], ['pos', 'neg'], $d['blood_group']);
    $scoreClass = $s['total'] >= 85 ? 'badge-cyan' : ($s['total'] >= 70 ? 'badge-success' : ($s['total'] >= 50 ? 'badge-warning' : 'badge-danger'));
    $dist = $row['distance_km'] !== null ? fmt_decimal10($row['distance_km']) . ' km' : '—';
    ?>
    <tr>
        <td><div class="d-flex align-center gap-2"><div class="avatar-circle <?= e($bgClass) ?>"><?= e(strtoupper(substr($d['name'], 0, 1))) ?></div><span style="font-weight:600;font-size:.88rem;"><?= e($d['name']) ?></span></div></td>
        <td><span class="badge <?= e($bgClass) ?>"><?= e($d['blood_group']) ?></span></td>
        <td><?= e($d['hospital_name'] ?? '—') ?><div class="text-xs text-muted"><?= e($d['hospital_city'] ?? $d['city']) ?>, <?= e($d['hospital_country'] ?? $d['country']) ?></div></td>
        <td class="td-mono"><?= e($dist) ?></td>
        <td><span class="badge <?= e($scoreClass) ?>" style="font-family:var(--font-mono);font-weight:700;"><?= e(fmt_decimal10($s['total'])) ?>%</span></td>
        <td class="no-export"><a href="<?= base_url('/pages/donors/view.php?id=' . (int) $d['donor_id']) ?>" class="btn btn-info btn-xs"><i class="fa-solid fa-eye"></i></a></td>
    </tr>
    <?php
}
?>

<div class="breadcrumb"><a href="<?= base_url('/pages/dashboard.php') ?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Donors</span></div>

<div class="page-header">
    <div class="page-header-left">
        <div class="page-icon"><i class="fa-solid fa-heart-pulse"></i></div>
        <div>
            <h1>Donors</h1>
            <p class="text-sm text-muted">Global donor registry — <?= count(KDMS_COUNTRIES) ?> countries</p>
        </div>
        <span class="count-badge"><?= $selected_recip ? ($match_rows ? count($match_rows) : array_sum(array_map(fn($g) => count($g['donors']), $match_groups ?? []))) : $total ?></span>
    </div>
    <div class="page-actions">
        <?php if (has_role(['superadmin','admin','doctor'])): ?>
        <a href="<?= base_url('/pages/donors/add.php') ?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Donor</a>
        <?php endif; ?>
        <?php if (has_role(['superadmin','admin'])): ?>
        <button class="btn btn-ghost" data-export-csv="mainTable" data-filename="donors-<?= date('Y-m-d') ?>.csv"><i class="fa-solid fa-file-csv"></i> Export CSV</button>
        <?php endif; ?>
    </div>
</div>

<!-- ─── Match-for-recipient panel: the two new recipient-relative filters ─── -->
<div class="glass-card no-hover mb-4">
    <div class="card-header"><h3><i class="fa-solid fa-route"></i> Match Donors for a Recipient</h3></div>
    <div class="card-body">
        <form method="GET" class="form-grid form-grid-3" style="align-items:end;">
            <div class="form-group full">
                <label>Recipient</label>
                <select name="recipient_id" onchange="this.form.submit()">
                    <option value="0">— Browse all donors (no recipient selected) —</option>
                    <?php foreach ($waiting_recipients as $r): ?>
                    <option value="<?= (int) $r['recipient_id'] ?>" <?= $recipient_id === (int) $r['recipient_id'] ? 'selected' : '' ?>>
                        <?= e($r['name']) ?> — <?= e($r['blood_group']) ?> — <?= e($r['city']) ?>, <?= e($r['country']) ?> (<?= e($r['urgency_level']) ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php if ($selected_recip): ?>
            <div class="form-group">
                <label>Sort donors by</label>
                <div class="btn-group" style="width:100%;">
                    <a href="?<?= http_build_query(['recipient_id' => $recipient_id, 'sort' => 'score']) ?>" class="btn btn-sm <?= $sort_mode === 'score' ? 'btn-primary' : 'btn-ghost' ?>" style="flex:1;"><i class="fa-solid fa-percent"></i> Compatibility Score</a>
                    <a href="?<?= http_build_query(['recipient_id' => $recipient_id, 'sort' => 'location']) ?>" class="btn btn-sm <?= $sort_mode === 'location' ? 'btn-primary' : 'btn-ghost' ?>" style="flex:1;"><i class="fa-solid fa-earth-americas"></i> Location Proximity</a>
                </div>
            </div>
            <input type="hidden" name="sort" value="<?= e($sort_mode) ?>">
            <?php endif; ?>
        </form>
        <?php if ($selected_recip): ?>
        <p class="text-xs text-muted mt-2">
            <i class="fa-solid fa-circle-info"></i>
            Matching against <strong><?= e($selected_recip['name']) ?></strong> (<?= e($selected_recip['blood_group']) ?>, <?= e($selected_recip['city']) ?>, <?= e($selected_recip['country']) ?>).
            <?= $sort_mode === 'score'
                ? 'Showing every Available donor ranked by compatibility score, highest first.'
                : "Donors are grouped by country — {$selected_recip['country']} first, then the next-closest countries by distance — and ranked by compatibility score within each group." ?>
        </p>
        <?php endif; ?>
    </div>
</div>

<?php if ($selected_recip): ?>
<!-- ─── Recipient-relative results (Filter 1 or Filter 2) ─────────────────── -->
<div class="glass-card no-hover">
    <div class="card-header"><h3>Candidate Donors</h3></div>
    <div class="table-wrap">
        <?php if ($sort_mode === 'score'): ?>
            <?php if ($match_rows): ?>
            <table id="mainTable">
                <thead><tr><th>Donor</th><th>Blood</th><th>Hospital</th><th>Distance</th><th>Score</th><th class="no-export">Actions</th></tr></thead>
                <tbody><?php foreach ($match_rows as $row) { render_match_row($row); } ?></tbody>
            </table>
            <?php else: ?>
            <div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-heart-pulse"></i></div><div class="empty-title">No Available Donors</div></div>
            <?php endif; ?>
        <?php else: ?>
            <?php if ($match_groups): foreach ($match_groups as $group): ?>
            <div style="padding:14px 20px 6px;display:flex;align-items:center;gap:10px;border-top:1px solid var(--border-subtle);">
                <span class="badge <?= $group['is_home_country'] ? 'badge-cyan' : 'badge-purple' ?>"><?= $group['is_home_country'] ? 'HOME COUNTRY' : 'INTERNATIONAL' ?></span>
                <strong><?= e($group['country']) ?></strong>
                <?php if ($group['min_distance_km'] !== null && !$group['is_home_country']): ?>
                <span class="text-xs text-muted">closest hospital ≈ <?= e(fmt_decimal10($group['min_distance_km'])) ?> km away</span>
                <?php endif; ?>
                <span class="count-badge"><?= count($group['donors']) ?></span>
            </div>
            <table id="mainTable" style="margin-bottom:6px;">
                <thead><tr><th>Donor</th><th>Blood</th><th>Hospital</th><th>Distance</th><th>Score</th><th class="no-export">Actions</th></tr></thead>
                <tbody><?php foreach ($group['donors'] as $row) { render_match_row($row); } ?></tbody>
            </table>
            <?php endforeach; else: ?>
            <div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-earth-americas"></i></div><div class="empty-title">No Available Donors</div></div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php else: ?>
<!-- ─── Standard browse mode (no recipient selected) ───────────────────────── -->
<div class="glass-card no-hover mb-4">
    <form method="GET" id="filterForm">
        <div class="filter-bar">
            <div class="form-group">
                <label>Search Name</label>
                <input type="text" name="search" value="<?= e($filter_search) ?>" placeholder="Search donors…">
            </div>
            <div class="form-group">
                <label>Blood Group</label>
                <select name="blood_group">
                    <option value="">All Groups</option>
                    <?php foreach (KDMS_BLOOD_GROUPS as $bg): ?>
                    <option value="<?= e($bg) ?>" <?= $filter_blood === $bg ? 'selected' : '' ?>><?= e($bg) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Country</label>
                <select name="country" id="filterCountry" onchange="kdmsCityCascade('filterCountry','filterCity', true)">
                    <option value="">All Countries</option>
                    <?php foreach (KDMS_COUNTRIES as $c): ?>
                    <option value="<?= e($c) ?>" <?= $filter_country === $c ? 'selected' : '' ?>><?= e($c) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>City</label>
                <select name="city" id="filterCity">
                    <option value="">All Cities</option>
                    <?php foreach (($filter_country ? kdms_cities_for($filter_country) : kdms_all_cities()) as $c): ?>
                    <option value="<?= e($c) ?>" <?= $filter_city === $c ? 'selected' : '' ?>><?= e($c) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Status</label>
                <select name="status">
                    <option value="">All Status</option>
                    <?php foreach (['Available','Unavailable','Transplanted','Suspended'] as $s): ?>
                    <option value="<?= e($s) ?>" <?= $filter_status === $s ? 'selected' : '' ?>><?= e($s) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Type</label>
                <select name="type">
                    <option value="">All Types</option>
                    <option value="Living"   <?= $filter_type === 'Living'   ? 'selected' : '' ?>>Living</option>
                    <option value="Deceased" <?= $filter_type === 'Deceased' ? 'selected' : '' ?>>Deceased</option>
                </select>
            </div>
            <div class="form-group" style="justify-content:flex-end;">
                <label>&nbsp;</label>
                <div class="btn-group">
                    <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button>
                    <a href="<?= base_url('/pages/donors/index.php') ?>" class="btn btn-ghost btn-sm">Clear</a>
                </div>
            </div>
        </div>
    </form>

    <?php if (has_role(['superadmin','admin'])): ?>
    <div class="bulk-bar" id="bulkBar" style="padding:10px 20px;">
        <span class="bulk-count">0 selected</span>
        <form method="POST" action="<?= base_url('/pages/donors/delete.php') ?>" id="bulkForm" style="display:contents;">
            <?= csrf_field() ?>
            <input type="hidden" name="bulk_action" value="delete">
            <button type="button" class="btn btn-danger btn-sm" onclick="bulkDelete()"><i class="fa-solid fa-trash-can"></i> Delete Selected</button>
        </form>
    </div>
    <?php endif; ?>

    <div class="table-wrap">
        <?php if ($donors): ?>
        <table id="mainTable">
            <thead>
                <tr>
                    <?php if (has_role(['superadmin','admin'])): ?>
                    <th style="width:40px;"><input type="checkbox" class="row-checkbox" id="masterCheck" aria-label="Select all"></th>
                    <?php endif; ?>
                    <th data-sort="name">Donor</th>
                    <th data-sort="blood_group">Blood</th>
                    <th data-sort="country">Country</th>
                    <th data-sort="city">City</th>
                    <th data-sort="donor_type">Type</th>
                    <th data-sort="status">Status</th>
                    <th>HLA / Crossmatch</th>
                    <th data-sort="hospital_name">Hospital</th>
                    <th data-sort="created_at">Registered</th>
                    <th class="no-export">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($donors as $d):
                $initials = strtoupper(substr($d['name'], 0, 1));
                $bgClass  = 'bg-' . str_replace(['+','-'], ['pos','neg'], $d['blood_group']);
            ?>
            <tr <?= $d['status'] === 'Unavailable' || $d['status'] === 'Suspended' ? 'style="opacity:.7;"' : '' ?>>
                <?php if (has_role(['superadmin','admin'])): ?>
                <td><input type="checkbox" class="row-checkbox" value="<?= (int) $d['donor_id'] ?>" aria-label="Select <?= e($d['name']) ?>"></td>
                <?php endif; ?>
                <td>
                    <div class="d-flex align-center gap-2">
                        <div class="avatar-circle <?= e($bgClass) ?>"><?= e($initials) ?></div>
                        <div>
                            <div style="font-weight:600;font-size:.88rem;" data-col="name"><?= e($d['name']) ?></div>
                            <?php if ($d['contact']): ?>
                            <div style="font-size:.72rem;color:var(--text-muted);"><?= e($d['contact']) ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </td>
                <td><span class="badge <?= e($bgClass) ?>" data-col="blood_group"><?= e($d['blood_group']) ?></span></td>
                <td data-col="country"><?= e($d['country']) ?></td>
                <td data-col="city"><i class="fa-solid fa-location-dot text-muted" style="margin-right:4px;font-size:.75rem;"></i><?= e($d['city']) ?></td>
                <td data-col="donor_type"><span class="badge <?= $d['donor_type']==='Living' ? 'badge-success' : 'badge-purple' ?>"><?= e($d['donor_type']) ?></span></td>
                <td data-col="status"><span class="badge <?= status_class($d['status']) ?>"><?= e($d['status']) ?></span></td>
                <td>
                    <?php if ($d['tissue_type_hla']): ?>
                    <div class="td-mono text-sm"><?= e($d['tissue_type_hla']) ?></div>
                    <div class="mt-1"><span class="badge badge-xs <?= $d['latest_crossmatch']==='Negative' ? 'badge-success' : ($d['latest_crossmatch']==='Positive' ? 'badge-danger' : 'badge-warning') ?>"><?= e($d['latest_crossmatch']) ?></span></div>
                    <?php else: ?>
                    <span class="text-muted text-xs">No test</span>
                    <?php endif; ?>
                </td>
                <td data-col="hospital_name" style="font-size:.82rem;color:var(--text-secondary);"><?= e($d['hospital_name'] ?? '—') ?></td>
                <td class="td-mono text-muted td-sm" data-col="created_at"><?= fmt_date($d['created_at']) ?></td>
                <td class="no-export">
                    <div class="btn-group">
                        <a href="<?= base_url('/pages/donors/view.php?id=' . (int) $d['donor_id']) ?>" class="btn btn-info btn-xs" title="View"><i class="fa-solid fa-eye"></i></a>
                        <?php if (has_role(['superadmin','admin','doctor'])): ?>
                        <a href="<?= base_url('/pages/donors/edit.php?id=' . (int) $d['donor_id']) ?>" class="btn btn-ghost btn-xs" title="Edit"><i class="fa-solid fa-pen"></i></a>
                        <?php endif; ?>
                        <?php if (has_role(['superadmin','admin'])): ?>
                        <button class="btn btn-danger btn-xs"
                            data-delete="<?= base_url('/pages/donors/delete.php') ?>"
                            data-id="<?= (int) $d['donor_id'] ?>"
                            data-msg="Delete donor '<?= e($d['name']) ?>'? This cannot be undone."
                            title="Delete">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state">
            <div class="empty-icon"><i class="fa-solid fa-heart-pulse"></i></div>
            <div class="empty-title">No Donors Found</div>
            <div class="empty-message">No donors match your current filters. Try adjusting the search criteria.</div>
            <?php if (has_role(['superadmin','admin','doctor'])): ?>
            <a href="<?= base_url('/pages/donors/add.php') ?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add First Donor</a>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($pages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page - 1])) ?>" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a>
        <?php else: ?>
        <span class="page-btn disabled"><i class="fa-solid fa-chevron-left"></i></span>
        <?php endif; ?>

        <?php for ($p = max(1, $page - 2); $p <= min($pages, $page + 2); $p++): ?>
        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $p])) ?>" class="page-btn <?= $p === $page ? 'active' : '' ?>"><?= $p ?></a>
        <?php endfor; ?>

        <?php if ($page < $pages): ?>
        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page + 1])) ?>" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a>
        <?php else: ?>
        <span class="page-btn disabled"><i class="fa-solid fa-chevron-right"></i></span>
        <?php endif; ?>

        <span class="pagination-info">Page <?= $page ?> of <?= $pages ?> &bull; <?= $total ?> records</span>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<script>
window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;
function bulkDelete() {
    const ids = BulkSelect.getSelected('mainTable');
    if (!ids.length) return Toast.show('No donors selected', 'warning');
    DeleteModal.open({
        id: ids.join(','),
        action: '<?= base_url('/pages/donors/delete.php') ?>',
        msg: `Delete ${ids.length} selected donor(s)? This action cannot be undone.`,
    });
}
document.getElementById('masterCheck')?.addEventListener('change', function() {
    document.querySelectorAll('#mainTable tbody .row-checkbox').forEach(cb => cb.checked = this.checked);
});
</script>

<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
