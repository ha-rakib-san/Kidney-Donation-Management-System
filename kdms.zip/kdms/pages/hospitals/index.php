<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_role(['superadmin','admin','auditor']);

$page_title = 'Hospitals';
$search  = trim($_GET['search']  ?? '');
$country = trim($_GET['country'] ?? '');
$city    = trim($_GET['city']    ?? '');
$page   = max(1,(int)($_GET['page'] ?? 1));
$per_page = 20;

$where = ['1=1']; $params = [];
if ($search)  { $where[] = 'h.name LIKE ?';    $params[] = '%'.$search.'%'; }
if ($country) { $where[] = 'h.country = ?';    $params[] = $country; }
if ($city)    { $where[] = 'h.city = ?';       $params[] = $city; }
$ws = implode(' AND ', $where);
$total = (int)(Database::fetchOne("SELECT COUNT(*) AS c FROM hospitals h WHERE $ws",$params)['c']??0);
$pages = (int)ceil($total/$per_page);
$offset= ($page-1)*$per_page;
$hospitals = Database::fetchAll("
    SELECT h.*,
           (SELECT COUNT(*) FROM donors WHERE hospital_id=h.hospital_id) AS donor_count,
           (SELECT COUNT(*) FROM recipients WHERE hospital_id=h.hospital_id) AS recipient_count,
           (SELECT COUNT(*) FROM doctors WHERE hospital_id=h.hospital_id AND is_active=1) AS doctor_count,
           (SELECT COUNT(*) FROM transplants WHERE hospital_id=h.hospital_id) AS transplant_count
    FROM hospitals h WHERE $ws ORDER BY h.name LIMIT $per_page OFFSET $offset",$params);

require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Hospitals</span></div>
<div class="page-header">
    <div class="page-header-left">
        <div class="page-icon"><i class="fa-solid fa-hospital"></i></div>
        <div><h1>Hospitals</h1><p class="text-sm text-muted">Medical centres registry</p></div>
        <span class="count-badge"><?=$total?></span>
    </div>
    <div class="page-actions">
        <?php if(has_role(['superadmin','admin'])): ?>
        <a href="<?=base_url('/pages/hospitals/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Hospital</a>
        <?php endif; ?>
        <button class="btn btn-ghost" data-export-csv="mainTable" data-filename="hospitals-<?=date('Y-m-d')?>.csv"><i class="fa-solid fa-file-csv"></i> Export</button>
    </div>
</div>
<div class="glass-card no-hover">
    <form method="GET">
        <div class="filter-bar">
            <div class="form-group"><label>Search</label><input type="text" name="search" value="<?=e($search)?>" placeholder="Hospital name…"></div>
            <div class="form-group"><label>Country</label><select name="country" id="filterCountryH" onchange="kdmsCityCascade('filterCountryH','filterCityH', true)"><option value="">All Countries</option><?php foreach(KDMS_COUNTRIES as $c): ?><option value="<?=e($c)?>" <?=$country===$c?'selected':''?>><?=e($c)?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>City</label><select name="city" id="filterCityH"><option value="">All Cities</option><?php foreach(($country?kdms_cities_for($country):kdms_all_cities()) as $c): ?><option value="<?=e($c)?>" <?=$city===$c?'selected':''?>><?=e($c)?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>&nbsp;</label><div class="btn-group"><button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-filter"></i> Filter</button><a href="<?=base_url('/pages/hospitals/index.php')?>" class="btn btn-ghost btn-sm">Clear</a></div></div>
        </div>
    </form>
    <div class="table-wrap">
        <?php if($hospitals): ?>
        <table id="mainTable">
            <thead><tr><th data-sort="name">Hospital</th><th>Country</th><th>City</th><th>Certified</th><th>Beds</th><th>Doctors</th><th>Donors</th><th>Recipients</th><th>Transplants</th><th class="no-export">Actions</th></tr></thead>
            <tbody>
            <?php foreach($hospitals as $h): ?>
            <tr>
                <td><div style="font-weight:600;font-size:.88rem;" data-col="name"><?=e($h['name'])?></div><div style="font-size:.72rem;color:var(--text-muted);"><?=e($h['short_code'])?></div></td>
                <td><?=e($h['country'])?></td>
                <td><?=e($h['city'])?></td>
                <td><?php if($h['transplant_certified']): ?><span class="badge badge-success"><i class="fa-solid fa-check"></i> Yes</span><?php else: ?><span class="badge badge-muted">No</span><?php endif; ?></td>
                <td class="td-mono"><?=$h['bed_count']?e($h['bed_count']):'—'?></td>
                <td class="td-mono text-cyan"><?=(int)$h['doctor_count']?></td>
                <td class="td-mono"><?=(int)$h['donor_count']?></td>
                <td class="td-mono"><?=(int)$h['recipient_count']?></td>
                <td class="td-mono text-green"><?=(int)$h['transplant_count']?></td>
                <td class="no-export">
                    <div class="btn-group">
                        <a href="<?=base_url('/pages/hospitals/view.php?id='.(int)$h['hospital_id'])?>" class="btn btn-info btn-xs" title="View"><i class="fa-solid fa-eye"></i></a>
                        <?php if(has_role(['superadmin','admin'])): ?>
                        <a href="<?=base_url('/pages/hospitals/edit.php?id='.(int)$h['hospital_id'])?>" class="btn btn-ghost btn-xs" title="Edit"><i class="fa-solid fa-pen"></i></a>
                        <button class="btn btn-danger btn-xs" data-delete="<?=base_url('/pages/hospitals/delete.php')?>" data-id="<?=(int)$h['hospital_id']?>" data-msg="Delete hospital '<?=e($h['name'])?>'?"><i class="fa-solid fa-trash-can"></i></button>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
        <div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-hospital"></i></div><div class="empty-title">No Hospitals Found</div><?php if(has_role(['superadmin','admin'])): ?><a href="<?=base_url('/pages/hospitals/add.php')?>" class="btn btn-primary"><i class="fa-solid fa-plus"></i> Add Hospital</a><?php endif; ?></div>
        <?php endif; ?>
    </div>
    <?php if($pages>1): ?><div class="pagination"><?php if($page>1): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page-1]))?>" class="page-btn"><i class="fa-solid fa-chevron-left"></i></a><?php endif; ?><?php for($p=max(1,$page-2);$p<=min($pages,$page+2);$p++): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$p]))?>" class="page-btn <?=$p===$page?'active':''?>"><?=$p?></a><?php endfor; ?><?php if($page<$pages): ?><a href="?<?=http_build_query(array_merge($_GET,['page'=>$page+1]))?>" class="page-btn"><i class="fa-solid fa-chevron-right"></i></a><?php endif; ?><span class="pagination-info"><?=$total?> records</span></div><?php endif; ?>
</div>
<script>window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
