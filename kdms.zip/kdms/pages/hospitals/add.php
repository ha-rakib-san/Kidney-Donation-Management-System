<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_role(['superadmin','admin']);

$page_title = 'Add Hospital';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $name     = trim($_POST['name']          ?? '');
    $code     = strtoupper(trim($_POST['short_code'] ?? ''));
    $country  = trim($_POST['country']       ?? '');
    $city     = trim($_POST['city']          ?? '');
    $address  = trim($_POST['address']       ?? '');
    $phone    = trim($_POST['contact_phone'] ?? '');
    $email    = trim($_POST['contact_email'] ?? '');
    $license  = trim($_POST['license_no']    ?? '');
    $beds     = (int)($_POST['bed_count']    ?? 0) ?: null;
    $cert     = !empty($_POST['transplant_certified']) ? 1 : 0;
    $lat      = trim($_POST['lat']  ?? '') ?: null;
    $lng      = trim($_POST['lng']  ?? '') ?: null;

    if (!$name)    $errors[] = 'Hospital name is required.';
    if (!$code)    $errors[] = 'Short code is required.';
    if (!$country) $errors[] = 'Country is required.';
    if (!$city)    $errors[] = 'City is required.';

    if (!$errors) {
        try {
            $id = Database::execute(
                "INSERT INTO hospitals (name,short_code,country,city,address,contact_phone,contact_email,license_no,bed_count,transplant_certified,lat,lng)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                [$name,$code,$country,$city,$address,$phone,$email,$license,$beds,$cert,$lat,$lng]
            );
            log_action('CREATE','hospitals',(int)$id,null,['name'=>$name,'country'=>$country,'city'=>$city]);
            flash('success',"Hospital '{$name}' added.");
            redirect('/pages/hospitals/index.php');
        } catch (PDOException $e) {
            $errors[] = str_contains($e->getMessage(),'short_code') ? 'Short code already exists.' : 'DB error: '.$e->getMessage();
        }
    }
}
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/hospitals/index.php')?>">Hospitals</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Add Hospital</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-hospital-user"></i></div><div><h1>Add Hospital</h1><p class="text-sm text-muted">Register a new medical centre</p></div></div>
    <div class="page-actions"><a href="<?=base_url('/pages/hospitals/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;" role="alert"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>
<div class="glass-card no-hover">
    <div class="card-header"><h3><i class="fa-solid fa-hospital text-cyan" style="margin-right:8px;"></i>Hospital Information</h3></div>
    <div class="card-body">
        <form method="POST" class="kdms-form" novalidate>
            <?=csrf_field()?>
            <div class="form-grid form-grid-3">
                <div class="form-group" style="grid-column:span 2;"><label>Hospital Name <span class="req">*</span></label><input type="text" name="name" value="<?=e($_POST['name']??'')?>" required maxlength="120" placeholder="e.g. Dhaka Medical College Hospital"></div>
                <div class="form-group"><label>Short Code <span class="req">*</span></label><input type="text" name="short_code" value="<?=e($_POST['short_code']??'')?>" required maxlength="10" placeholder="e.g. DMCH" style="text-transform:uppercase;"></div>
                <div class="form-group"><label>Country <span class="req">*</span></label><?= kdms_country_select('country', $_POST['country'] ?? null, 'onchange="kdmsCityCascade(\'country\',\'city\')"') ?></div>
                <div class="form-group"><label>City <span class="req">*</span></label><?= kdms_city_select('city', $_POST['country'] ?? null, $_POST['city'] ?? null) ?></div>
                <div class="form-group"><label>Contact Phone</label><input type="tel" name="contact_phone" value="<?=e($_POST['contact_phone']??'')?>" maxlength="20"></div>
                <div class="form-group"><label>Contact Email</label><input type="email" name="contact_email" value="<?=e($_POST['contact_email']??'')?>" maxlength="120"></div>
                <div class="form-group"><label>License Number</label><input type="text" name="license_no" value="<?=e($_POST['license_no']??'')?>" maxlength="50"></div>
                <div class="form-group"><label>Total Beds</label><input type="number" name="bed_count" value="<?=e($_POST['bed_count']??'')?>" min="1" max="9999"></div>
                <div class="form-group"><label>Latitude</label><input type="number" name="lat" value="<?=e($_POST['lat']??'')?>" step="0.0000001" placeholder="e.g. 23.7261"></div>
                <div class="form-group"><label>Longitude</label><input type="number" name="lng" value="<?=e($_POST['lng']??'')?>" step="0.0000001" placeholder="e.g. 90.3959"></div>
                <div class="form-group full"><label>Address</label><textarea name="address" rows="2"><?=e($_POST['address']??'')?></textarea></div>
            </div>
            <div class="glass-card no-hover mt-3" style="padding:16px 20px;">
                <label class="login-remember" style="margin:0;"><input type="checkbox" name="transplant_certified" value="1" <?=!empty($_POST['transplant_certified'])?'checked':''?>> Transplant Certified (capable of performing kidney transplants)</label>
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;">
                <a href="<?=base_url('/pages/hospitals/index.php')?>" class="btn btn-ghost">Cancel</a>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save Hospital</button>
            </div>
        </form>
    </div>
</div>
<script>window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
