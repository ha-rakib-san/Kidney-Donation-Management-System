<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';
require_once KDMS_ROOT . '/lib/Procedures.php';
require_role(['superadmin','admin']);
$id = (int)($_GET['id'] ?? 0);
if (!$id) { flash('danger','Invalid ID.'); redirect('/pages/hospitals/index.php'); }
$hosp = Database::fetchOne("SELECT * FROM hospitals WHERE hospital_id=?", [$id]);
if (!$hosp) { flash('danger','Hospital not found.'); redirect('/pages/hospitals/index.php'); }
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify(); $old = $hosp;
    $name=$_POST['name']??''; $code=strtoupper(trim($_POST['short_code']??'')); $country=$_POST['country']??''; $city=$_POST['city']??'';
    $address=$_POST['address']??''; $phone=$_POST['contact_phone']??''; $email=$_POST['contact_email']??'';
    $license=$_POST['license_no']??''; $beds=(int)($_POST['bed_count']??0)?:null; $cert=!empty($_POST['transplant_certified'])?1:0;
    $lat=decimal_value($_POST['lat']??null); $lng=decimal_value($_POST['lng']??null);
    if(!$name) $errors[]='Name required.'; if(!$country) $errors[]='Country required.'; if(!$city) $errors[]='City required.';
    if(!$errors) {
        try {
            Database::execute("UPDATE hospitals SET name=?,short_code=?,country=?,city=?,address=?,contact_phone=?,contact_email=?,license_no=?,bed_count=?,transplant_certified=?,lat=?,lng=?,updated_at=CURRENT_TIMESTAMP WHERE hospital_id=?",
                [$name,$code,$country,$city,$address,$phone,$email,$license,$beds,$cert,$lat,$lng,$id]);
            Procedures::recalculateMatchesForHospital($id);
            log_action('UPDATE','hospitals',$id,$old,['name'=>$name,'country'=>$country,'city'=>$city]);
            flash('success',"Hospital updated."); redirect('/pages/hospitals/view.php?id='.$id);
        } catch (PDOException $e) { $errors[]='DB error: '.$e->getMessage(); }
    }
    $hosp=array_merge($hosp,$_POST);
}
$page_title='Edit Hospital';
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/hospitals/index.php')?>">Hospitals</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current">Edit</span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-pen-to-square"></i></div><div><h1>Edit Hospital</h1><p class="text-sm text-muted"><?=e($hosp['name'])?></p></div></div>
    <div class="page-actions"><a href="<?=base_url('/pages/hospitals/view.php?id='.$id)?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<?php if($errors): ?><div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;"><span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span><div><?php foreach($errors as $err): ?><div><?=e($err)?></div><?php endforeach; ?></div></div><?php endif; ?>
<div class="glass-card no-hover"><div class="card-body">
<form method="POST" class="kdms-form" novalidate><?=csrf_field()?>
<div class="form-grid form-grid-3">
    <div class="form-group" style="grid-column:span 2;"><label>Name <span class="req">*</span></label><input type="text" name="name" value="<?=e($hosp['name'])?>" required maxlength="120"></div>
    <div class="form-group"><label>Short Code</label><input type="text" name="short_code" value="<?=e($hosp['short_code'])?>" maxlength="10" style="text-transform:uppercase;"></div>
    <div class="form-group"><label>Country</label><?= kdms_country_select('country', $hosp['country'] ?? null, 'onchange="kdmsCityCascade(\'country\',\'city\')"') ?></div>
    <div class="form-group"><label>City</label><?= kdms_city_select('city', $hosp['country'] ?? null, $hosp['city'] ?? null) ?></div>
    <div class="form-group"><label>Phone</label><input type="tel" name="contact_phone" value="<?=e($hosp['contact_phone']??'')?>" maxlength="20"></div>
    <div class="form-group"><label>Email</label><input type="email" name="contact_email" value="<?=e($hosp['contact_email']??'')?>" maxlength="120"></div>
    <div class="form-group"><label>License</label><input type="text" name="license_no" value="<?=e($hosp['license_no']??'')?>" maxlength="50"></div>
    <div class="form-group"><label>Beds</label><input type="number" name="bed_count" value="<?=e($hosp['bed_count']??'')?>" min="1"></div>
    <div class="form-group"><label>Latitude</label><input type="number" name="lat" value="<?=e($hosp['lat']??'')?>" step="0.0000000001"></div>
    <div class="form-group"><label>Longitude</label><input type="number" name="lng" value="<?=e($hosp['lng']??'')?>" step="0.0000000001"></div>
    <div class="form-group full"><label>Address</label><textarea name="address" rows="2"><?=e($hosp['address']??'')?></textarea></div>
</div>
<div class="glass-card no-hover mt-3" style="padding:16px 20px;"><label class="login-remember" style="margin:0;"><input type="checkbox" name="transplant_certified" value="1" <?=$hosp['transplant_certified']?'checked':''?>> Transplant Certified</label></div>
<div style="display:flex;gap:10px;justify-content:flex-end;padding-top:20px;">
    <a href="<?=base_url('/pages/hospitals/view.php?id='.$id)?>" class="btn btn-ghost">Cancel</a>
    <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> Save</button>
</div>
</form></div></div>
<script>window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;</script>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
