<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { redirect('/pages/hospitals/index.php'); }
csrf_verify();
$id = (int)($_POST['id'] ?? 0);
$h  = Database::fetchOne("SELECT name FROM hospitals WHERE hospital_id=?",[$id]);
if (!$h) { flash('danger','Not found.'); redirect('/pages/hospitals/index.php'); }
try {
    Database::execute("UPDATE hospitals SET is_active=0 WHERE hospital_id=?",[$id]);
    log_action('DELETE','hospitals',$id,['name'=>$h['name']]);
    flash('success',"Hospital '{$h['name']}' deactivated.");
} catch (PDOException $e) { flash('danger','Error: '.$e->getMessage()); }
redirect('/pages/hospitals/index.php');
