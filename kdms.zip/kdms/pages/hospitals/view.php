<?php
declare(strict_types=1);
define('KDMS_ROOT', dirname(dirname(__DIR__)));
require_once KDMS_ROOT . '/includes/auth.php';
require_role(['superadmin','admin','auditor']);
$id = (int)($_GET['id'] ?? 0);
if (!$id) { flash('danger','Invalid ID.'); redirect('/pages/hospitals/index.php'); }
$hosp = Database::fetchOne("SELECT h.*, (SELECT COUNT(*) FROM donors WHERE hospital_id=h.hospital_id) AS donor_count, (SELECT COUNT(*) FROM recipients WHERE hospital_id=h.hospital_id) AS recipient_count, (SELECT COUNT(*) FROM doctors WHERE hospital_id=h.hospital_id AND is_active=1) AS doctor_count, (SELECT COUNT(*) FROM transplants WHERE hospital_id=h.hospital_id) AS transplant_count FROM hospitals h WHERE h.hospital_id=?",[$id]);
if (!$hosp) { flash('danger','Not found.'); redirect('/pages/hospitals/index.php'); }
$doctors = Database::fetchAll("SELECT doctor_id,name,specialization,transplants_done FROM doctors WHERE hospital_id=? AND is_active=1 ORDER BY name",[$id]);
$page_title = $hosp['name'];
require_once KDMS_ROOT . '/includes/header.php';
?>
<div class="breadcrumb"><a href="<?=base_url('/pages/dashboard.php')?>">Dashboard</a><span class="breadcrumb-sep">›</span><a href="<?=base_url('/pages/hospitals/index.php')?>">Hospitals</a><span class="breadcrumb-sep">›</span><span class="breadcrumb-current"><?=e($hosp['name'])?></span></div>
<div class="page-header">
    <div class="page-header-left"><div class="page-icon"><i class="fa-solid fa-hospital"></i></div><div><h1><?=e($hosp['name'])?></h1><div class="d-flex gap-2 mt-1"><span class="badge badge-info"><?=e($hosp['short_code'])?></span><span class="badge badge-muted"><?=e($hosp['city'])?>, <?=e($hosp['country'])?></span><?php if($hosp['transplant_certified']): ?><span class="badge badge-success"><i class="fa-solid fa-check"></i> Transplant Certified</span><?php endif; ?></div></div></div>
    <div class="page-actions"><?php if(has_role(['superadmin','admin'])): ?><a href="<?=base_url('/pages/hospitals/edit.php?id='.$id)?>" class="btn btn-info"><i class="fa-solid fa-pen"></i> Edit</a><button class="btn btn-danger" data-delete="<?=base_url('/pages/hospitals/delete.php')?>" data-id="<?=$id?>" data-msg="Delete hospital '<?=e($hosp['name'])?>'?"><i class="fa-solid fa-trash-can"></i></button><?php endif; ?><a href="<?=base_url('/pages/hospitals/index.php')?>" class="btn btn-ghost"><i class="fa-solid fa-arrow-left"></i> Back</a></div>
</div>
<div class="stat-grid mb-4" style="grid-template-columns:repeat(4,1fr);">
    <div class="glass-card stat-card"><div class="stat-icon icon-cyan"><i class="fa-solid fa-user-doctor"></i></div><div class="stat-content"><div class="stat-value td-mono" data-count="<?=(int)$hosp['doctor_count']?>"><?=(int)$hosp['doctor_count']?></div><div class="stat-label">Doctors</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-green"><i class="fa-solid fa-heart-pulse"></i></div><div class="stat-content"><div class="stat-value td-mono" data-count="<?=(int)$hosp['donor_count']?>"><?=(int)$hosp['donor_count']?></div><div class="stat-label">Donors</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-red"><i class="fa-solid fa-bed-pulse"></i></div><div class="stat-content"><div class="stat-value td-mono" data-count="<?=(int)$hosp['recipient_count']?>"><?=(int)$hosp['recipient_count']?></div><div class="stat-label">Recipients</div></div></div>
    <div class="glass-card stat-card"><div class="stat-icon icon-purple"><i class="fa-solid fa-scalpel"></i></div><div class="stat-content"><div class="stat-value td-mono" data-count="<?=(int)$hosp['transplant_count']?>"><?=(int)$hosp['transplant_count']?></div><div class="stat-label">Transplants</div></div></div>
</div>
<div class="detail-grid mb-4">
    <div class="glass-card no-hover"><div class="card-header"><h3>Hospital Details</h3></div><div class="card-body"><div class="detail-section">
        <div class="detail-row"><span class="detail-label">Full Name</span><span class="detail-value"><?=e($hosp['name'])?></span></div>
        <div class="detail-row"><span class="detail-label">Short Code</span><span class="detail-value td-mono"><?=e($hosp['short_code'])?></span></div>
        <div class="detail-row"><span class="detail-label">Country</span><span class="detail-value"><?=e($hosp['country'])?></span></div>
        <div class="detail-row"><span class="detail-label">City</span><span class="detail-value"><?=e($hosp['city'])?></span></div>
        <div class="detail-row"><span class="detail-label">Address</span><span class="detail-value text-sm"><?=e($hosp['address']??'—')?></span></div>
        <div class="detail-row"><span class="detail-label">Phone</span><span class="detail-value"><?=e($hosp['contact_phone']??'—')?></span></div>
        <div class="detail-row"><span class="detail-label">Email</span><span class="detail-value"><?=e($hosp['contact_email']??'—')?></span></div>
        <div class="detail-row"><span class="detail-label">License</span><span class="detail-value td-mono"><?=e($hosp['license_no']??'—')?></span></div>
        <div class="detail-row"><span class="detail-label">Beds</span><span class="detail-value td-mono"><?=$hosp['bed_count']??'—'?></span></div>
        <div class="detail-row"><span class="detail-label">Transplant</span><span class="detail-value"><?=$hosp['transplant_certified']?'<span class="badge badge-success">Certified</span>':'<span class="badge badge-muted">Not certified</span>'?></span></div>
    </div></div></div>
    <div class="glass-card no-hover"><div class="card-header"><h3>Active Doctors (<?=count($doctors)?>)</h3></div><div class="table-wrap"><?php if($doctors): ?><table><thead><tr><th>Name</th><th>Specialization</th><th>Transplants</th></tr></thead><tbody><?php foreach($doctors as $d): ?><tr><td><a href="<?=base_url('/pages/doctors/view.php?id='.(int)$d['doctor_id'])?>" class="text-cyan"><?=e($d['name'])?></a></td><td><span class="badge badge-info text-xs"><?=e($d['specialization'])?></span></td><td class="td-mono text-green"><?=(int)$d['transplants_done']?></td></tr><?php endforeach; ?></tbody></table><?php else: ?><div class="empty-state"><div class="empty-icon"><i class="fa-solid fa-user-doctor"></i></div><div class="empty-message">No doctors assigned.</div></div><?php endif; ?></div></div>
</div>
<?php require_once KDMS_ROOT . '/includes/footer.php'; ?>
