<?php
/**
 * KDMS Pro — api/compatibility.php
 * POST: {donor_id, recipient_id} → returns compatibility score breakdown JSON
 */
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/lib/Procedures.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required.']);
    exit;
}

require_role(['superadmin','admin','doctor']);

$raw  = file_get_contents('php://input');
$body = json_decode($raw, true) ?? [];

// CSRF check (accept from JSON body or header)
$posted_token = $body['_csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (!hash_equals(csrf_token(), $posted_token)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Invalid security token.']);
    exit;
}

$donor_id     = (int)($body['donor_id']     ?? 0);
$recipient_id = (int)($body['recipient_id'] ?? 0);

if (!$donor_id || !$recipient_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'donor_id and recipient_id are required.']);
    exit;
}

try {
    $scoreData = Procedures::calculateCompatibility($donor_id, $recipient_id);

    if (!$scoreData || !isset($scoreData['total'])) {
        echo json_encode(['success' => false, 'message' => 'Could not compute compatibility score.']);
        exit;
    }

    echo json_encode([
        'success' => true,
        'data' => $scoreData,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    error_log('[KDMS api/compatibility] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to calculate compatibility.']);
}
