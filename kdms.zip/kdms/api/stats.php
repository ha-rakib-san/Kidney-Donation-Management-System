<?php
/**
 * KDMS Pro — api/stats.php
 * GET: dashboard KPI counts + trend data for real-time polling
 */
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required.']);
    exit;
}

try {
    $stats = Database::fetchOne("
        SELECT
            (SELECT COUNT(*) FROM hospitals  WHERE is_active=1)          AS total_hospitals,
            (SELECT COUNT(*) FROM doctors    WHERE is_active=1)          AS total_doctors,
            (SELECT COUNT(*) FROM donors     WHERE status='Available')   AS available_donors,
            (SELECT COUNT(*) FROM donors     WHERE status='Unavailable') AS unavailable_donors,
            (SELECT COUNT(*) FROM donors     WHERE status='Transplanted') AS transplanted_donors,
            (SELECT COUNT(*) FROM donors     WHERE status='Suspended')   AS suspended_donors,
            (SELECT COUNT(*) FROM donors)                                 AS total_donors,
            (SELECT COUNT(*) FROM recipients WHERE wait_status='Waiting') AS waiting_recipients,
            (SELECT COUNT(*) FROM recipients)                             AS total_recipients,
            (SELECT COUNT(*) FROM medical_tests WHERE is_valid=1)        AS total_tests,
            (SELECT COUNT(*) FROM compatibility_matches)                  AS total_matches,
            (SELECT COUNT(*) FROM compatibility_matches WHERE review_result='Approved') AS approved_matches,
            (SELECT COUNT(*) FROM compatibility_matches WHERE review_result='Pending')  AS pending_matches,
            (SELECT COUNT(*) FROM transplants)                            AS total_transplants,
            (SELECT COUNT(*) FROM transplants WHERE result='Successful')  AS successful_transplants,
            (SELECT COUNT(*) FROM transplants WHERE result='Ongoing')     AS ongoing_transplants,
            (SELECT COUNT(*) FROM follow_ups)                             AS total_followups,
            (SELECT COUNT(*) FROM recipients WHERE urgency_level='Critical' AND wait_status='Waiting') AS critical_recipients,
            (SELECT ROUND(COUNT(*)*100.0/NULLIF((SELECT COUNT(*) FROM transplants WHERE result IN ('Successful','Failed')),0),1)
             FROM transplants WHERE result='Successful')                  AS success_rate
    ") ?? [];

    // Monthly trends (last 12 months)
    $trends = Database::fetchAll("SELECT month_label, new_transplants, new_matches FROM v_monthly_trends ORDER BY yr ASC, mo ASC LIMIT 12");
    $stats['monthly_labels']      = array_column($trends, 'month_label');
    $stats['monthly_transplants'] = array_map('intval', array_column($trends, 'new_transplants'));
    $stats['monthly_matches']     = array_map('intval', array_column($trends, 'new_matches'));

    echo json_encode(['success' => true, 'data' => $stats]);
} catch (Throwable $e) {
    error_log('[KDMS api/stats] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to fetch stats.']);
}
