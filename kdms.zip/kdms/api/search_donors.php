<?php
/**
 * KDMS Pro — api/search_donors.php
 * GET: AJAX filtered donor search, returns JSON array
 */
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/lib/Procedures.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required.']);
    exit;
}

require_role(['superadmin','admin','doctor','auditor']);

try {
    $filters = [
        'blood_group' => trim($_GET['blood_group'] ?? ''),
        'country'     => trim($_GET['country']     ?? ''),
        'city'        => trim($_GET['city']        ?? ''),
        'donor_type'  => trim($_GET['donor_type']  ?? ''),
        'hla_type'    => trim($_GET['hla_type']    ?? ''),
        'crossmatch'  => trim($_GET['crossmatch']  ?? ''),
        'keyword'     => trim($_GET['search']      ?? ''),
        'limit'       => min(100, max(1, (int)($_GET['limit'] ?? 50))),
    ];

    $donors = Procedures::searchDonors($filters);

    echo json_encode(['success' => true, 'data' => $donors, 'count' => count($donors)]);
} catch (Throwable $e) {
    error_log('[KDMS api/search_donors] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Search failed.']);
}
