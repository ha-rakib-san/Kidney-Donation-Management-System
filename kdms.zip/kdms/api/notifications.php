<?php
/**
 * KDMS Pro — api/notifications.php
 * GET:  unread notification list (or ?count=1 for just the count) for current user
 * POST: mark notification(s) as read — {action: 'mark_read', id} or {action: 'mark_all_read'}
 */
declare(strict_types=1);
define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/includes/auth.php';

header('Content-Type: application/json');

if (!is_logged_in()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Authentication required.']);
    exit;
}

$user_id = (int)current_user()['user_id'];

try {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (!empty($_GET['count'])) {
            $row = Database::fetchOne("SELECT COUNT(*) AS c FROM notifications WHERE user_id=? AND is_read=0", [$user_id]);
            echo json_encode(['success' => true, 'data' => ['unread_count' => (int)($row['c'] ?? 0)]]);
            exit;
        }

        $notifications = Database::fetchAll(
            "SELECT notification_id, title, message, type, link_url, is_read, created_at
             FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 25",
            [$user_id]
        );
        echo json_encode(['success' => true, 'data' => $notifications]);
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $raw  = file_get_contents('php://input');
        $body = json_decode($raw, true) ?? $_POST;

        $posted_token = $body['_csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        if (!hash_equals(csrf_token(), $posted_token)) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => 'Invalid security token.']);
            exit;
        }

        $action = trim($body['action'] ?? '');

        if ($action === 'mark_read') {
            $id = (int)($body['id'] ?? 0);
            if (!$id) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => 'Notification id is required.']);
                exit;
            }
            Database::execute(
                "UPDATE notifications SET is_read=1, read_at=CURRENT_TIMESTAMP WHERE notification_id=? AND user_id=?",
                [$id, $user_id]
            );
            echo json_encode(['success' => true, 'message' => 'Notification marked as read.']);
            exit;
        }

        if ($action === 'mark_all_read') {
            Database::execute(
                "UPDATE notifications SET is_read=1, read_at=CURRENT_TIMESTAMP WHERE user_id=? AND is_read=0",
                [$user_id]
            );
            echo json_encode(['success' => true, 'message' => 'All notifications marked as read.']);
            exit;
        }

        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Unknown action.']);
        exit;
    }

    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
} catch (Throwable $e) {
    error_log('[KDMS api/notifications] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Request failed.']);
}
