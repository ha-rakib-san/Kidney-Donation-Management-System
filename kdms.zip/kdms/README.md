# KDMS Pro — Kidney Donation Management System

**Global Hybrid Edition · SQLite · 69 Hospitals · 30 Countries**

A full-stack PHP 8.2 + SQLite educational KDMS project with role-based access, real-time dashboards, automated compatibility suggestions, and a complete workflow from donor registration through post-transplant follow-up. It operates as an **international hybrid network** rather than a single-country system.

---

## ✨ Highlights

- **6-role RBAC system** (Superadmin, Admin, Doctor, Donor, Recipient, Auditor) with page-level role enforcement
- **Live compatibility score calculator** — real-time AJAX scoring as you select donor/recipient pairs
- **Two donor-list filters for cross-border matching** (see below) — rank by compatibility score, or by country/hospital proximity
- **16-table SQLite schema** with triggers, views, and a PHP service layer standing in for stored procedures/events
- **Three.js DNA helix** on the login page, GSAP-animated counters and transitions throughout
- **3 live Chart.js dashboards** refreshing every 30 seconds
- **Audit logging** for major authentication, CRUD, approval, rejection, export, and system actions
- **Global hybrid network** — the original 8 Bangladesh hospitals (preserved, unchanged) plus 61 new hospitals across 29 additional countries: the US, UK, Russia, China, Germany, Australia, India, Japan, South Korea, France, Italy, Spain, Canada, Brazil, South Africa, the UAE, Saudi Arabia, Singapore, Malaysia, Thailand, Turkey, Egypt, Nigeria, the Netherlands, Sweden, Pakistan, Indonesia, Mexico, and Switzerland — 69 hospitals total

---

## 🌍 The Two New Donor-List Filters

When a doctor/admin opens **Donors → Match Donors for a Recipient** and selects a recipient, the donor list switches into one of two recipient-relative views:

1. **By Compatibility Score** — every Available donor worldwide, ranked highest score first.
2. **By Location Proximity** — donors are grouped by country: the recipient's **own country first**, then the remaining countries ordered by how close their *nearest* donor hospital is to the recipient's hospital (closest country next, then the next-closest, and so on, using great-circle/Haversine distance between hospital lat/lng). **Inside every country group**, donors are still ranked by compatibility score, highest first.

This logic lives in `lib/Procedures.php` (`donorsForRecipient()`, `sortByCompatibility()`, `sortByLocation()`) and is rendered by `pages/donors/index.php`.

---

## 🏗️ Tech Stack

| Layer | Technology |
|---|---|
| Backend | PHP 8.2 (PDO, prepared statements, OOP) |
| Database | **SQLite 3.35+** (file-based, zero server process — see "Why SQLite" below) |
| Frontend | HTML5, CSS3 (custom properties), Vanilla JS ES6+ |
| 3D/Animation | Three.js r128, GSAP 3 |
| Charts | Chart.js 4 |
| Icons | Font Awesome 6.5 |
| Fonts | Space Grotesk + Inter + JetBrains Mono (Google Fonts) |

No frameworks (no Laravel/Vue/React) — built for maximum compatibility with a standard XAMPP localhost stack. PHP 8.2's bundled `pdo_sqlite` extension is all that's required; **no MySQL server, no phpMyAdmin import, no `my.ini` configuration**.

### Why SQLite instead of MySQL?

- **Zero setup**: the database is a single file at `storage/kdms.sqlite`, created and seeded automatically on first request — no service to start, no root password, no `CREATE DATABASE`.
- **Portable**: copy the whole `htdocs/kdms/` folder anywhere with PHP 8.2 and it just works.
- **Trade-offs, by design**: SQLite has no stored-procedure language, so the original 8 MySQL stored procedures now live as PHP methods on `lib/Procedures.php`. SQLite has no event scheduler, so the 4 scheduled jobs run "lazily" via `includes/scheduler.php` (or for real cron, `cron/maintenance.php`). SQLite has no `FULLTEXT INDEX`/`MATCH...AGAINST`; donor/recipient search uses an indexed `LIKE` query instead (an FTS5 virtual-table approach was tried first but triggered a reproducible database-corruption bug when its sync triggers fired from inside a cross-table cascade trigger — see the comment block at the top of `sql/01_schema.sql`).

---

## 📂 Project Structure

```
htdocs/kdms/
├── index.php, login.php, logout.php, register.php, install.php
├── config/database.php          ← PDO SQLite singleton + auto-bootstrap
├── lib/Procedures.php           ← PHP equivalents of the 8 MySQL stored procedures
│                                    + the two new donor-list filters
├── includes/                    ← auth.php, header.php, footer.php, constants.php (countries/cities)
├── pages/                       ← all CRUD views (donors, recipients, hospitals,
│                                    doctors, tests, matches, transplants, followups,
│                                    search, match_summary, reports, audit_log, profile)
├── api/                         ← stats.php, search_donors.php, compatibility.php, notifications.php
├── assets/css/                  ← main.css, animations.css, print.css
├── assets/js/                   ← app.js (incl. kdmsCityCascade), three-scene.js,
│                                    dashboard-charts.js, compatibility.js, notifications.js
├── storage/                     ← kdms.sqlite lives here (auto-created, gitignored)
└── sql/                         ← 01_schema → 06_seed + SETUP_GUIDE.md
```

---

## 🚀 Getting Started

See **[`sql/SETUP_GUIDE.md`](sql/SETUP_GUIDE.md)** for full step-by-step installation instructions.

**TL;DR:**
1. Copy this folder to `htdocs/kdms/`
2. Visit `http://localhost/kdms/install.php` once (creates and seeds `storage/kdms.sqlite`) — or just visit `http://localhost/kdms/` and let it auto-bootstrap on first load
3. Log in with `superadmin` / `password`

---

## 🧬 Precision Compatibility Scoring Algorithm

KDMS 2.0 uses a continuous, 10-decimal decision-support score. The central calculation is implemented once in `Procedures::calculateCompatibility()` and reused by live previews, new matches, recalculation, approval checks, and donor ranking.

| Factor | Maximum points | Logic |
|---|---:|---|
| ABO blood compatibility | 15 | Kidney ABO compatibility, with Rh ignored |
| Hospital distance | 20 | Haversine distance with continuous interpolation from 0 to 1,000 km |
| Crossmatch | 20 | Both latest records must be negative. Either positive result is a hard stop |
| HLA similarity | 15 | Tokenized HLA overlap using a continuous Dice similarity |
| Medical profile | 30 | Age difference, BMI, creatinine, GFR, blood pressure, hemoglobin, diabetes, hypertension, and recipient PRA/cPRA |

The medical test form records height, weight, calculated BMI, systolic and diastolic pressure, diabetes, hypertension, and PRA/cPRA in addition to the existing test fields. Numeric values are rounded and displayed at exactly 10 decimal places. Missing clinical values receive no points and prevent approval. ABO incompatibility, positive crossmatch, donor GFR below 60, and flagged donor infection screening block eligibility.

See `SCORING_MODEL.md` for the full formula, distance anchors, validation ranges, and limitations. The score is educational clinical decision support, not a substitute for transplant-team review.

---

## 🔐 Security Features

- PDO prepared statements exclusively (zero raw SQL interpolation)
- `password_hash()` / `password_verify()` (bcrypt) for all credentials
- CSRF tokens on every state-changing form
- Session fixation prevention (`session_regenerate_id()` on login)
- Brute-force lockout (5 failed attempts → 15-minute lock)
- XSS-safe output via the `e()` helper (`htmlspecialchars`)
- HTTP security headers (CSP, X-Frame-Options, X-Content-Type-Options)
- Role-guarded pages via `require_role()` middleware

---

## 📊 Database Highlights

- **16 application tables**, fully normalized, SQLite with `PRAGMA foreign_keys = ON`
- **8 PHP service methods** (`lib/Procedures.php`) standing in for the original MySQL stored procedures: compatibility scoring, auto-matching, waitlist prioritization, match approval, transplant completion, dashboard stats, donor search, monthly reports — plus the two new recipient-relative donor-list filters
- **10 triggers**: transplant outcome cascades, age validation, match-status guards, critical follow-up alerts, and audit logging
- **10 views**: approved matches, ranked waitlist, donor/recipient profiles, transplant summaries, doctor workload, hospital stats, monthly trends, critical cases
- **4 scheduled jobs** (lazy page-load trigger + optional real cron via `cron/maintenance.php`): daily waitlist reprioritization, weekly AI match suggestions, monthly cleanup, hourly stats caching

---

## 🌐 Global Hybrid Context

The system preserves its founding Bangladesh network (8 hospitals across Dhaka, Chattogram, Sylhet, Rajshahi, Khulna, Gazipur, Mymensingh, and Barishal divisions; Bangladeshi donor/recipient names; BMDC registration numbers for doctors) and extends it with 61 more hospitals across 29 additional countries. Every hospital, donor, and recipient record now carries both a `country` and `city` field; transplant costs are stored as `cost_amount` + an ISO `currency` code (BDT, USD, GBP, EUR, INR, CNY, AED, and more) rather than a single fixed currency.

---

## 📄 License

Educational / demonstration project. Not certified for real clinical use — consult local medical device and health data regulations before any production deployment.
