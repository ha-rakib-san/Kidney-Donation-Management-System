/**
 * KDMS Pro — app.js
 * Core UI logic: sidebar, GSAP animations, modals, tables, utilities
 */

'use strict';

/* ─── Sidebar ────────────────────────────────────────────────────────────────── */
const Sidebar = (() => {
  const sidebar   = document.getElementById('sidebar');
  const toggle    = document.getElementById('sidebarToggle');
  const toggleIcon = document.getElementById('toggleIcon');
  const overlay   = document.getElementById('sidebarOverlay');
  const hamburger = document.getElementById('hamburger');
  const main      = document.getElementById('main');
  const footer    = document.querySelector('.app-footer');

  let collapsed = localStorage.getItem('kdms_sidebar_collapsed') === '1';

  function applyState() {
    if (!sidebar) return;
    if (collapsed) {
      sidebar.classList.add('collapsed');
      main   && main.classList.add('expanded');
      footer && footer.classList.add('expanded');
    } else {
      sidebar.classList.remove('collapsed');
      main   && main.classList.remove('expanded');
      footer && footer.classList.remove('expanded');
    }
    if (toggleIcon) toggleIcon.className = collapsed ? 'fa-solid fa-chevron-right' : 'fa-solid fa-chevron-left';
  }

  function collapseToggle() {
    collapsed = !collapsed;
    localStorage.setItem('kdms_sidebar_collapsed', collapsed ? '1' : '0');
    applyState();
  }

  function openMobile() {
    sidebar  && sidebar.classList.add('mobile-open');
    overlay  && overlay.classList.add('visible');
    hamburger && hamburger.setAttribute('aria-expanded', 'true');
  }

  function closeMobile() {
    sidebar  && sidebar.classList.remove('mobile-open');
    overlay  && overlay.classList.remove('visible');
    hamburger && hamburger.setAttribute('aria-expanded', 'false');
  }

  toggle    && toggle.addEventListener('click', collapseToggle);
  hamburger && hamburger.addEventListener('click', openMobile);
  overlay   && overlay.addEventListener('click', closeMobile);

  applyState();
  return { collapseToggle, openMobile, closeMobile };
})();

/* ─── Theme Toggle ───────────────────────────────────────────────────────────── */
const Theme = (() => {
  const html  = document.documentElement;
  const btn   = document.getElementById('themeToggle');
  let theme   = localStorage.getItem('kdms_theme') || 'dark';

  function apply() {
    html.setAttribute('data-theme', theme);
    if (btn) btn.innerHTML = theme === 'dark'
      ? '<i class="fa-solid fa-sun"></i>'
      : '<i class="fa-solid fa-moon"></i>';
  }

  function toggle() {
    theme = theme === 'dark' ? 'light' : 'dark';
    localStorage.setItem('kdms_theme', theme);
    apply();
  }

  btn && btn.addEventListener('click', toggle);
  apply();
  return { toggle };
})();

/* ─── Flash Message Auto-dismiss ─────────────────────────────────────────────── */
const Flash = (() => {
  function init() {
    const msg = document.getElementById('flashMsg');
    if (!msg) return;
    setTimeout(() => {
      if (msg && msg.parentNode) {
        msg.style.animation = 'slideInRight 0.3s reverse forwards';
        setTimeout(() => msg.remove(), 300);
      }
    }, 4500);
  }
  init();
})();

/* ─── Toast System ───────────────────────────────────────────────────────────── */
const Toast = (() => {
  const container = document.getElementById('toastContainer');

  const ICONS = {
    success: 'fa-circle-check',
    danger:  'fa-circle-xmark',
    warning: 'fa-triangle-exclamation',
    info:    'fa-circle-info',
    urgent:  'fa-bell',
  };

  const COLORS = {
    success: 'rgba(0,229,160,0.12)',
    danger:  'rgba(255,45,85,0.12)',
    warning: 'rgba(255,184,0,0.12)',
    info:    'rgba(0,212,255,0.12)',
    urgent:  'rgba(255,45,85,0.15)',
  };
  const BORDERS = {
    success: 'rgba(0,229,160,0.3)',
    danger:  'rgba(255,45,85,0.3)',
    warning: 'rgba(255,184,0,0.3)',
    info:    'rgba(0,212,255,0.3)',
    urgent:  'rgba(255,45,85,0.4)',
  };

  function show(message, type = 'info', duration = 3500) {
    if (!container) return;
    const icon  = ICONS[type]   || ICONS.info;
    const bg    = COLORS[type]  || COLORS.info;
    const border= BORDERS[type] || BORDERS.info;
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.style.cssText = `background:${bg};border:1px solid ${border};backdrop-filter:blur(20px);`;
    toast.innerHTML = `
      <i class="fa-solid ${icon}" style="flex-shrink:0;"></i>
      <span style="flex:1;font-size:0.85rem;">${message}</span>
      <button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;color:inherit;font-size:0.85rem;padding:0 4px;">
        <i class="fa-solid fa-xmark"></i>
      </button>`;
    container.appendChild(toast);
    if (typeof gsap !== 'undefined') {
      gsap.from(toast, { x: 60, opacity: 0, duration: 0.3, ease: 'back.out(1.5)' });
    }
    setTimeout(() => {
      if (toast.parentNode) {
        toast.style.animation = 'toastSlideOut 0.3s forwards';
        setTimeout(() => toast.remove(), 300);
      }
    }, duration);
  }

  return { show };
})();
window.Toast = Toast;

/* ─── Delete Confirmation Modal ──────────────────────────────────────────────── */
const DeleteModal = (() => {
  const modal    = document.getElementById('deleteModal');
  const form     = document.getElementById('deleteModalForm');
  const idField  = document.getElementById('deleteModalId');
  const message  = document.getElementById('deleteModalMessage');
  const detail   = document.getElementById('deleteRecordDetail');
  const cancelBtn = document.getElementById('deleteCancelBtn');

  function open({ id, action, msg = null, detailHtml = null }) {
    if (!modal) return;
    if (idField)  idField.value = id;
    if (form)     form.action   = action;
    if (message && msg)  message.textContent = msg;
    if (detail && detailHtml) { detail.innerHTML = detailHtml; detail.style.display = 'block'; }
    modal.hidden = false;
    document.body.style.overflow = 'hidden';
    if (typeof gsap !== 'undefined') {
      gsap.from('.modal', { scale: 0.85, opacity: 0, duration: 0.3, ease: 'back.out(1.5)' });
    }
  }

  function close() {
    if (!modal) return;
    modal.hidden = true;
    document.body.style.overflow = '';
    if (detail) { detail.innerHTML = ''; detail.style.display = 'none'; }
  }

  cancelBtn && cancelBtn.addEventListener('click', close);
  modal     && modal.addEventListener('click', (e) => { if (e.target === modal) close(); });
  document  .addEventListener('keydown', (e) => { if (e.key === 'Escape' && modal && !modal.hidden) close(); });

  // Hook all [data-delete] buttons
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-delete]');
    if (!btn) return;
    e.preventDefault();
    open({
      id:         btn.dataset.id,
      action:     btn.dataset.action || btn.dataset.delete,
      msg:        btn.dataset.msg  || 'Are you sure you want to delete this record? This action cannot be undone.',
      detailHtml: btn.dataset.detail || null,
    });
  });

  return { open, close };
})();
window.DeleteModal = DeleteModal;

/* ─── Table Sort ─────────────────────────────────────────────────────────────── */
const TableSort = (() => {
  function init(tableId) {
    const table = document.getElementById(tableId);
    if (!table) return;
    const headers = table.querySelectorAll('thead th[data-sort]');
    let currentCol = null, currentDir = 'asc';

    headers.forEach(th => {
      th.style.cursor = 'pointer';
      th.addEventListener('click', () => {
        const col = th.dataset.sort;
        if (currentCol === col) {
          currentDir = currentDir === 'asc' ? 'desc' : 'asc';
        } else {
          currentCol = col; currentDir = 'asc';
        }
        headers.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
        th.classList.add(currentDir === 'asc' ? 'sort-asc' : 'sort-desc');
        sortTable(table, col, currentDir);
      });
    });
  }

  function sortTable(table, col, dir) {
    const tbody = table.querySelector('tbody');
    const rows  = Array.from(tbody.querySelectorAll('tr'));
    rows.sort((a, b) => {
      const va = a.querySelector(`[data-col="${col}"]`)?.textContent.trim() || '';
      const vb = b.querySelector(`[data-col="${col}"]`)?.textContent.trim() || '';
      const na = parseFloat(va), nb = parseFloat(vb);
      const compare = (!isNaN(na) && !isNaN(nb)) ? na - nb : va.localeCompare(vb);
      return dir === 'asc' ? compare : -compare;
    });
    rows.forEach(r => tbody.appendChild(r));
  }

  return { init };
})();
window.TableSort = TableSort;

/* ─── Bulk Select ────────────────────────────────────────────────────────────── */
const BulkSelect = (() => {
  function init(tableId, bulkBarId) {
    const table   = document.getElementById(tableId);
    const bulkBar = document.getElementById(bulkBarId);
    if (!table || !bulkBar) return;

    const masterCb = table.querySelector('thead .row-checkbox');
    const countEl  = bulkBar.querySelector('.bulk-count');

    function updateBulkBar() {
      const checked = table.querySelectorAll('tbody .row-checkbox:checked');
      if (checked.length > 0) {
        bulkBar.classList.add('visible');
        if (countEl) countEl.textContent = checked.length + ' selected';
      } else {
        bulkBar.classList.remove('visible');
      }
    }

    masterCb && masterCb.addEventListener('change', () => {
      table.querySelectorAll('tbody .row-checkbox').forEach(cb => { cb.checked = masterCb.checked; });
      updateBulkBar();
    });

    table.addEventListener('change', (e) => {
      if (e.target.classList.contains('row-checkbox')) updateBulkBar();
    });
  }

  function getSelected(tableId) {
    const table = document.getElementById(tableId);
    if (!table) return [];
    return Array.from(table.querySelectorAll('tbody .row-checkbox:checked')).map(cb => cb.value);
  }

  return { init, getSelected };
})();
window.BulkSelect = BulkSelect;

/* ─── GSAP Counter Animations ────────────────────────────────────────────────── */
const Counters = (() => {
  function init() {
    if (typeof gsap === 'undefined') {
      // Fallback without GSAP
      document.querySelectorAll('[data-count]').forEach(el => {
        el.textContent = el.dataset.count;
      });
      return;
    }
    const elements = document.querySelectorAll('[data-count]');
    elements.forEach((el, i) => {
      const target = parseFloat(el.dataset.count) || 0;
      const isFloat = String(el.dataset.count).includes('.');
      const state = { val: 0 };
      el.textContent = isFloat ? '0.0' : '0';
      gsap.to(state, {
        val: target,
        duration: 1.5,
        delay: i * 0.07,
        ease: 'power2.out',
        onUpdate: () => {
          el.textContent = isFloat ? state.val.toFixed(1) : String(Math.round(state.val));
        },
        onComplete: () => {
          el.textContent = isFloat ? target.toFixed(1) : String(Math.round(target));
        },
      });
    });
  }
  return { init };
})();

/* ─── IntersectionObserver Reveal ────────────────────────────────────────────── */
const Reveal = (() => {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  function init() {
    document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
  }
  return { init };
})();

/* ─── Score Ring ─────────────────────────────────────────────────────────────── */
const ScoreRing = (() => {
  function render(el, score) {
    if (!el) return;
    const CIRCUMFERENCE = 2 * Math.PI * 24; // r=24
    const offset        = CIRCUMFERENCE * (1 - score / 100);
    const color         = score >= 85 ? '#00D4FF'
                        : score >= 70 ? '#00E5A0'
                        : score >= 50 ? '#FFB800'
                        : '#FF2D55';
    el.innerHTML = `
      <svg viewBox="0 0 54 54">
        <circle class="ring-bg"   cx="27" cy="27" r="24"/>
        <circle class="ring-fill" cx="27" cy="27" r="24"
          stroke="${color}"
          stroke-dasharray="${CIRCUMFERENCE}"
          stroke-dashoffset="${offset}"
          style="transition:stroke-dashoffset 1s cubic-bezier(.22,1,.36,1);"/>
      </svg>
      <div class="ring-text" style="color:${color};font-size:.58rem;">${score.toFixed(2)}%</div>`;
    el.title = `Compatibility score: ${score.toFixed(10)}%`;
  }

  function renderAll() {
    document.querySelectorAll('[data-score-ring]').forEach(el => {
      render(el, parseFloat(el.dataset.scoreRing) || 0);
    });
  }

  return { render, renderAll };
})();

/* ─── CSV Export ─────────────────────────────────────────────────────────────── */
const CSV = (() => {
  function exportTable(tableId, filename = 'export.csv') {
    const table = document.getElementById(tableId);
    if (!table) return;
    const rows  = Array.from(table.querySelectorAll('tr'));
    const csv   = rows.map(row =>
      Array.from(row.querySelectorAll('th, td'))
          .filter(cell => !cell.classList.contains('no-export'))
          .map(cell => `"${cell.innerText.replace(/"/g, '""').trim()}"`)
          .join(',')
    ).join('\n');

    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
    Toast.show('CSV exported successfully', 'success');
  }

  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-export-csv]');
    if (!btn) return;
    exportTable(btn.dataset.exportCsv, btn.dataset.filename || 'kdms-export.csv');
  });

  return { exportTable };
})();
window.CSV = CSV;

/* ─── GFR Stage Classifier ───────────────────────────────────────────────────── */
function classifyGFR(gfr) {
  if (!gfr || gfr <= 0) return null;
  const g = parseFloat(gfr);
  if (g >= 90) return { stage: 1, label: 'Stage 1 — Normal',                 color: '#00E5A0' };
  if (g >= 60) return { stage: 2, label: 'Stage 2 — Mildly Decreased',        color: '#00D4FF' };
  if (g >= 45) return { stage: '3a', label: 'Stage 3a — Mildly-Moderately',   color: '#FFB800' };
  if (g >= 30) return { stage: '3b', label: 'Stage 3b — Moderately-Severely', color: '#FF8800' };
  if (g >= 15) return { stage: 4, label: 'Stage 4 — Severely Decreased',      color: '#FF2D55' };
  return           { stage: 5, label: 'Stage 5 — Kidney Failure',              color: '#CC0033' };
}
window.classifyGFR = classifyGFR;

/* ─── Blood Group Badge Color ────────────────────────────────────────────────── */
function bloodBadgeClass(bg) {
  const map = { 'O+': 'bg-Opos', 'O-': 'bg-Oneg', 'A+': 'bg-Apos', 'A-': 'bg-Aneg',
                'B+': 'bg-Bpos', 'B-': 'bg-Bneg', 'AB+': 'bg-ABpos', 'AB-': 'bg-ABneg' };
  return map[bg] || '';
}
window.bloodBadgeClass = bloodBadgeClass;

/* ─── Notification Dropdown Toggle ──────────────────────────────────────────── */
const NotifDropdown = (() => {
  const dropdown  = document.getElementById('notifDropdown');
  const topbarBtn = document.getElementById('topbarNotif');

  function toggle() {
    if (!dropdown) return;
    dropdown.hidden = !dropdown.hidden;
    if (!dropdown.hidden) Notifications.load();
  }

  topbarBtn && topbarBtn.addEventListener('click', (e) => { e.stopPropagation(); toggle(); });

  document.addEventListener('click', (e) => {
    if (dropdown && !dropdown.hidden && !dropdown.contains(e.target) && e.target !== topbarBtn) {
      dropdown.hidden = true;
    }
  });

  return { toggle };
})();

/* ─── Page Init ──────────────────────────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  Counters.init();
  Reveal.init();
  ScoreRing.renderAll();

  // GSAP stagger for cards/panels
  if (typeof gsap !== 'undefined') {
    gsap.from('.glass-card, .stat-card', {
      y: 24, opacity: 0, duration: 0.5,
      stagger: 0.06, ease: 'power2.out',
      clearProps: 'all',
    });
  }

  // Init all tables with sort
  document.querySelectorAll('table[id]').forEach(t => TableSort.init(t.id));

  // Init bulk select
  if (document.getElementById('mainTable')) {
    BulkSelect.init('mainTable', 'bulkBar');
  }

  // Auto-focus first input in forms
  const firstInput = document.querySelector('.kdms-form input:not([type=hidden]):not([disabled])');
  if (firstInput) firstInput.focus();
});

/**
 * KDMS Pro — International country -> city cascade.
 *
 * Re-populates a <select id="citySelectId"> with the cities for whatever
 * country is currently chosen in <select id="countrySelectId">, using the
 * KDMS_CITIES_BY_COUNTRY map each page exposes via
 * `window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;`
 * (see includes/constants.php). If keepFirstBlank is true, an "All / Select
 * city…" placeholder option is kept at the top.
 */
function kdmsCityCascade(countrySelectId, citySelectId, keepFirstBlank) {
  const countrySel = document.getElementById(countrySelectId);
  const citySel = document.getElementById(citySelectId);
  if (!countrySel || !citySel) return;

  const country = countrySel.value;
  const citiesByCountry = window.KDMS_CITIES_BY_COUNTRY || {};
  const cities = country ? (citiesByCountry[country] || []) : Object.values(citiesByCountry).flat();
  const previousValue = citySel.value;
  const uniqueSorted = Array.from(new Set(cities)).sort();

  citySel.innerHTML = '';
  const placeholder = document.createElement('option');
  placeholder.value = '';
  placeholder.textContent = keepFirstBlank
    ? (country ? 'All Cities' : 'All Cities')
    : (uniqueSorted.length ? 'Select City…' : 'Select country first…');
  citySel.appendChild(placeholder);

  uniqueSorted.forEach(city => {
    const opt = document.createElement('option');
    opt.value = city;
    opt.textContent = city;
    if (city === previousValue) opt.selected = true;
    citySel.appendChild(opt);
  });
}
