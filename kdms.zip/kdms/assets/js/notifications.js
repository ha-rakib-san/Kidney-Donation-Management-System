/**
 * KDMS Pro — notifications.js
 * Real-time notification polling, dropdown rendering, mark-as-read
 */

'use strict';

const Notifications = (() => {
  const list      = document.getElementById('notifList');
  const markAllBtn = document.getElementById('markAllRead');
  let polling     = null;

  const TYPE_ICONS = {
    success:    { icon: 'fa-circle-check',          color: '#00E5A0' },
    warning:    { icon: 'fa-triangle-exclamation',  color: '#FFB800' },
    urgent:     { icon: 'fa-bell',                  color: '#FF2D55' },
    match:      { icon: 'fa-dna',                   color: '#00D4FF' },
    transplant: { icon: 'fa-scalpel',               color: '#8B5CF6' },
    info:       { icon: 'fa-circle-info',           color: '#8899BB' },
  };

  function timeAgo(dateStr) {
    const diff  = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
    if (diff < 60)    return 'just now';
    if (diff < 3600)  return Math.floor(diff / 60) + 'm ago';
    if (diff < 86400) return Math.floor(diff / 3600) + 'h ago';
    return Math.floor(diff / 86400) + 'd ago';
  }

  function renderItem(n) {
    const t   = TYPE_ICONS[n.type] || TYPE_ICONS.info;
    const li  = document.createElement('li');
    li.className = `notif-item notif-type-${n.type} ${n.is_read == 0 ? 'unread' : ''}`;
    li.dataset.id = n.notification_id;
    li.innerHTML  = `
      <span class="notif-icon" style="color:${t.color};">
        <i class="fa-solid ${t.icon}"></i>
      </span>
      <div class="notif-content">
        <div class="notif-title">${escapeHtml(n.title)}</div>
        <div class="notif-msg">${escapeHtml(n.message.substring(0, 90))}${n.message.length > 90 ? '…' : ''}</div>
        <div class="notif-time">${timeAgo(n.created_at)}</div>
      </div>`;
    li.addEventListener('click', () => markRead(n.notification_id, n.link_url));
    return li;
  }

  function escapeHtml(str) {
    return String(str ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  async function load() {
    if (!list) return;
    list.innerHTML = '<li class="notif-loading"><i class="fa-solid fa-spinner anim-spin"></i> Loading…</li>';
    try {
      const res  = await fetch(`${window.KDMS.baseUrl}/api/notifications.php`, {
        headers: { 'X-CSRF-Token': window.KDMS.csrfToken },
      });
      const json = await res.json();
      list.innerHTML = '';
      if (!json.success || !json.data?.length) {
        list.innerHTML = '<li style="padding:20px;text-align:center;color:#445577;font-size:.85rem;">No notifications</li>';
        return;
      }
      json.data.forEach(n => list.appendChild(renderItem(n)));
    } catch (e) {
      list.innerHTML = '<li style="padding:20px;text-align:center;color:#FF2D55;font-size:.85rem;">Failed to load</li>';
    }
  }

  async function markRead(id, linkUrl) {
    try {
      await fetch(`${window.KDMS.baseUrl}/api/notifications.php`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': window.KDMS.csrfToken },
        body:    JSON.stringify({ action: 'mark_read', id, _csrf_token: window.KDMS.csrfToken }),
      });
      const li = list?.querySelector(`[data-id="${id}"]`);
      if (li) li.classList.remove('unread');
      updateBadge(-1);
    } catch (e) { /* silent */ }
    if (linkUrl) window.location.href = linkUrl;
  }

  async function markAllRead() {
    try {
      await fetch(`${window.KDMS.baseUrl}/api/notifications.php`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': window.KDMS.csrfToken },
        body:    JSON.stringify({ action: 'mark_all_read', _csrf_token: window.KDMS.csrfToken }),
      });
      list?.querySelectorAll('.notif-item.unread').forEach(li => li.classList.remove('unread'));
      updateBadge(0, true);
      Toast.show('All notifications marked as read', 'success');
    } catch (e) { /* silent */ }
  }

  function updateBadge(delta, reset = false) {
    const badges = document.querySelectorAll('.notif-badge, .notif-badge-sm');
    badges.forEach(b => {
      const current = parseInt(b.textContent) || 0;
      const newVal  = reset ? 0 : Math.max(0, current + delta);
      if (newVal === 0) {
        b.remove();
      } else {
        b.textContent = newVal > 99 ? '99+' : newVal;
      }
    });
  }

  async function pollCount() {
    try {
      const res  = await fetch(`${window.KDMS.baseUrl}/api/notifications.php?count=1`, {
        headers: { 'X-CSRF-Token': window.KDMS.csrfToken },
      });
      const json = await res.json();
      if (!json.success) return;
      const count = json.data?.unread_count || 0;
      // Update all badges
      document.querySelectorAll('.notif-badge, .notif-badge-sm').forEach(b => {
        if (count === 0) {
          b.remove();
        } else {
          b.textContent = count > 99 ? '99+' : count;
        }
      });
      // If new notifications arrived and no badge exists, add one
      if (count > 0 && !document.querySelector('.notif-badge-sm')) {
        const topBtn = document.getElementById('topbarNotif');
        if (topBtn) {
          const badge = document.createElement('span');
          badge.className   = 'notif-badge-sm';
          badge.textContent = count;
          topBtn.appendChild(badge);
        }
      }
    } catch (e) { /* silent */ }
  }

  function startPolling(intervalMs = 30000) {
    if (polling) clearInterval(polling);
    polling = setInterval(pollCount, intervalMs);
  }

  function stopPolling() {
    if (polling) clearInterval(polling);
  }

  // Mark all button
  markAllBtn && markAllBtn.addEventListener('click', markAllRead);

  return { load, markRead, markAllRead, startPolling, stopPolling, updateBadge };
})();

window.Notifications = Notifications;

// Start polling when logged in
document.addEventListener('DOMContentLoaded', () => {
  if (window.KDMS && window.KDMS.userId > 0) {
    Notifications.startPolling(30000);
  }
});
