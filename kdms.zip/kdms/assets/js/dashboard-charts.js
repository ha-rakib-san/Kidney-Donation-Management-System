/**
 * KDMS Pro — dashboard-charts.js
 * Chart.js 4: Monthly transplant trends, Donor status doughnut, Blood group bar
 * Real-time 30-second polling via /api/stats.php
 */

'use strict';

const DashboardCharts = (() => {
  let lineChart = null, doughnutChart = null, barChart = null;
  let refreshInterval = null;

  // Chart defaults
  Chart.defaults.color          = '#8899BB';
  Chart.defaults.font.family    = "'Inter', sans-serif";
  Chart.defaults.borderColor    = 'rgba(0,212,255,0.08)';
  Chart.defaults.plugins.legend.labels.boxWidth = 12;
  Chart.defaults.plugins.legend.labels.padding  = 16;

  const CYAN    = '#00D4FF';
  const GREEN   = '#00E5A0';
  const RED     = '#FF2D55';
  const GOLD    = '#FFB800';
  const PURPLE  = '#8B5CF6';
  const BLUE    = '#3B82F6';

  /* ─── Gradient helper ─────────────────────────────────────────────────────── */
  function makeGradient(ctx, colorTop, colorBot) {
    const g = ctx.createLinearGradient(0, 0, 0, ctx.canvas.height);
    g.addColorStop(0, colorTop);
    g.addColorStop(1, colorBot);
    return g;
  }

  /* ─── 1. Monthly Transplant Trends (Line) ────────────────────────────────── */
  function initLineChart(canvasId, data) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const grad = makeGradient(ctx, 'rgba(0,212,255,0.35)', 'rgba(0,212,255,0.00)');

    if (lineChart) lineChart.destroy();
    lineChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels:   data.labels   || [],
        datasets: [
          {
            label:           'Transplants',
            data:            data.transplants || [],
            borderColor:     CYAN,
            backgroundColor: grad,
            borderWidth:     2.5,
            pointBackgroundColor: CYAN,
            pointRadius:     4,
            pointHoverRadius:6,
            fill:            true,
            tension:         0.4,
          },
          {
            label:           'Matches',
            data:            data.matches || [],
            borderColor:     GREEN,
            backgroundColor: 'rgba(0,229,160,0.08)',
            borderWidth:     2,
            pointBackgroundColor: GREEN,
            pointRadius:     3,
            pointHoverRadius:5,
            fill:            true,
            tension:         0.4,
            borderDash:      [4, 3],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend:  { position: 'top', align: 'end' },
          tooltip: {
            backgroundColor: 'rgba(5,11,24,0.95)',
            borderColor:     'rgba(0,212,255,0.3)',
            borderWidth:     1,
            padding:         12,
            titleFont: { family: "'Space Grotesk', sans-serif", size: 13 },
          },
        },
        scales: {
          x: {
            grid:  { color: 'rgba(255,255,255,0.03)' },
            ticks: { color: '#445577', maxRotation: 0 },
          },
          y: {
            grid:  { color: 'rgba(255,255,255,0.04)' },
            ticks: { color: '#445577', precision: 0 },
            beginAtZero: true,
          },
        },
      },
    });
  }

  /* ─── 2. Donor Status Distribution (Doughnut) ────────────────────────────── */
  function initDoughnutChart(canvasId, data) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    if (doughnutChart) doughnutChart.destroy();
    doughnutChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Available', 'Unavailable', 'Transplanted', 'Suspended'],
        datasets: [{
          data:            [data.available||0, data.unavailable||0, data.transplanted||0, data.suspended||0],
          backgroundColor: [
            'rgba(0,229,160,0.75)',
            'rgba(255,184,0,0.75)',
            'rgba(0,212,255,0.75)',
            'rgba(255,45,85,0.75)',
          ],
          borderColor:     ['#00E5A0', '#FFB800', '#00D4FF', '#FF2D55'],
          borderWidth:     2,
          hoverOffset:     6,
        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '68%',
        plugins: {
          legend: { position: 'bottom', labels: { padding: 14 } },
          tooltip: {
            backgroundColor: 'rgba(5,11,24,0.95)',
            borderColor: 'rgba(0,212,255,0.3)',
            borderWidth: 1,
            padding: 10,
            callbacks: {
              label: (ctx) => ` ${ctx.label}: ${ctx.raw} donors`,
            },
          },
        },
      },
    });
  }

  /* ─── 3. Matches by Blood Group (Bar) ───────────────────────────────────────── */
  function initBarChart(canvasId, data) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    if (barChart) barChart.destroy();
    barChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels:   data.labels   || ['A+','A-','B+','B-','O+','O-','AB+','AB-'],
        datasets: [
          {
            label:           'Donors',
            data:            data.donors       || [],
            backgroundColor: 'rgba(0,212,255,0.55)',
            borderColor:     CYAN,
            borderWidth:     1.5,
            borderRadius:    4,
          },
          {
            label:           'Recipients',
            data:            data.recipients   || [],
            backgroundColor: 'rgba(255,45,85,0.50)',
            borderColor:     RED,
            borderWidth:     1.5,
            borderRadius:    4,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend:  { position: 'top', align: 'end' },
          tooltip: {
            backgroundColor: 'rgba(5,11,24,0.95)',
            borderColor: 'rgba(0,212,255,0.3)',
            borderWidth: 1,
            padding: 10,
          },
        },
        scales: {
          x: { grid: { display: false }, ticks: { color: '#445577' } },
          y: {
            grid:  { color: 'rgba(255,255,255,0.04)' },
            ticks: { color: '#445577', precision: 0 },
            beginAtZero: true,
          },
        },
      },
    });
  }

  /* ─── Update KPI Cards ───────────────────────────────────────────────────── */
  function updateKPIs(stats) {
    const map = {
      'kpi-hospitals':    stats.total_hospitals,
      'kpi-doctors':      stats.total_doctors,
      'kpi-donors':       stats.available_donors,
      'kpi-recipients':   stats.waiting_recipients,
      'kpi-tests':        stats.total_tests,
      'kpi-matches':      stats.total_matches,
      'kpi-transplants':  stats.total_transplants,
      'kpi-followups':    stats.total_followups,
      'kpi-critical':     stats.critical_recipients,
      'kpi-success-rate': stats.success_rate,
    };
    Object.entries(map).forEach(([id, val]) => {
      const el = document.getElementById(id);
      if (el && val !== undefined) {
        if (typeof gsap !== 'undefined') {
          const current = parseFloat(el.textContent) || 0;
          const target  = parseFloat(val) || 0;
          gsap.to({ v: current }, {
            v: target, duration: 0.8, ease: 'power2.out',
            onUpdate: function() { el.textContent = String(val).includes('.') ? this.targets()[0].v.toFixed(1) : Math.round(this.targets()[0].v); },
          });
        } else {
          el.textContent = val;
        }
      }
    });
  }

  /* ─── Fetch stats from API ───────────────────────────────────────────────── */
  async function fetchAndUpdate() {
    try {
      const res  = await fetch(`${window.KDMS.baseUrl}/api/stats.php`, {
        headers: { 'X-CSRF-Token': window.KDMS.csrfToken },
      });
      const json = await res.json();
      if (!json.success) return;

      const s = json.data;
      updateKPIs(s);

      // Update charts if trend data is present
      if (s.monthly_labels && lineChart) {
        lineChart.data.labels           = s.monthly_labels;
        lineChart.data.datasets[0].data = s.monthly_transplants;
        lineChart.data.datasets[1].data = s.monthly_matches;
        lineChart.update('none');
      }
      if (doughnutChart) {
        doughnutChart.data.datasets[0].data = [
          s.available_donors || 0,
          s.unavailable_donors || 0,
          s.transplanted_donors || 0,
          s.suspended_donors || 0,
        ];
        doughnutChart.update('none');
      }
    } catch (e) {
      console.warn('[KDMS] Stats fetch error:', e);
    }
  }

  /* ─── Public Init ────────────────────────────────────────────────────────── */
  function init(initialData) {
    if (!initialData) return;

    // Slight delay for GSAP card animations to complete
    setTimeout(() => {
      initLineChart('chartMonthlyTrends', initialData.monthly || {});
      initDoughnutChart('chartDonorStatus',    initialData.donor_status || {});
      initBarChart('chartBloodGroup',           initialData.blood_group  || {});
    }, 300);

    // Start 30-second polling
    refreshInterval = setInterval(fetchAndUpdate, 30000);
  }

  function destroy() {
    if (refreshInterval) clearInterval(refreshInterval);
    [lineChart, doughnutChart, barChart].forEach(c => c && c.destroy());
  }

  return { init, fetchAndUpdate, destroy };
})();

window.DashboardCharts = DashboardCharts;
