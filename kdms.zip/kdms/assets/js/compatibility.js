/**
 * KDMS Pro — precision compatibility preview
 */
'use strict';

const CompatibilityCalc = (() => {
  let debounceTimer = null;
  let lastDonorId = null;
  let lastRecipientId = null;

  const byId = (id) => document.getElementById(id);
  const scorePanel = byId('compatScorePanel');
  const scoreValue = byId('compatScoreValue');
  const scoreLabel = byId('compatScoreLabel');
  const submitBtn = byId('matchSubmitBtn');
  const crossmatchBadge = byId('crossmatchResultBadge');
  const donorSelect = byId('donorSelect');
  const recipientSelect = byId('recipientSelect');

  const bars = {
    blood: { bar: byId('scoreBarBlood'), text: byId('scoreBloodPts'), max: 15 },
    location: { bar: byId('scoreBarLoc'), text: byId('scoreLocPts'), max: 20 },
    crossmatch: { bar: byId('scoreBarCross'), text: byId('scoreCrossPts'), max: 20 },
    hla: { bar: byId('scoreBarHLA'), text: byId('scoreHLAPts'), max: 15 },
    medical: { bar: byId('scoreBarMedical'), text: byId('scoreMedicalPts'), max: 30 },
  };

  const medicalOutputs = {
    age_score: [byId('scoreAgePts'), 3],
    bmi_score: [byId('scoreBmiPts'), 3],
    creatinine_score: [byId('scoreCreatininePts'), 4],
    gfr_score: [byId('scoreGfrPts'), 5],
    blood_pressure_score: [byId('scoreBpPts'), 3],
    hemoglobin_score: [byId('scoreHemoglobinPts'), 3],
    diabetes_score: [byId('scoreDiabetesPts'), 2],
    hypertension_score: [byId('scoreHypertensionPts'), 2],
    pra_score: [byId('scorePraPts'), 5],
  };

  const decimal10 = (value) => {
    const n = Number(value);
    return Number.isFinite(n) ? n.toFixed(10) : '0.0000000000';
  };

  function scoreColor(score) {
    if (score >= 85) return '#00D4FF';
    if (score >= 70) return '#00E5A0';
    if (score >= 50) return '#FFB800';
    return '#FF2D55';
  }

  function scoreText(data) {
    if ((data.hard_stops || []).length) return 'Clinically Ineligible';
    if (!data.is_eligible) return 'Preliminary Score, Testing Incomplete';
    if (data.total >= 85) return 'Excellent Match';
    if (data.total >= 70) return 'Good Match';
    if (data.total >= 50) return 'Fair Match';
    return 'Poor Match';
  }

  function animateBar(item, points, color) {
    if (!item || !item.bar) return;
    const value = Number(points) || 0;
    const percent = Math.max(0, Math.min(100, (value / item.max) * 100));
    item.bar.style.width = '0%';
    item.bar.style.background = color;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      item.bar.style.width = `${percent}%`;
    }));
    if (item.text) item.text.textContent = `${decimal10(value)}/${item.max}`;
  }

  function renderWarnings(data) {
    const container = byId('compatWarnings');
    if (!container) return;
    const hardStops = data.hard_stops || [];
    const warnings = data.warnings || [];
    const missing = data.missing_fields || [];
    const sections = [];
    if (hardStops.length) {
      sections.push(`<div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin:0 0 10px;">${hardStops.map(x => `<div><i class="fa-solid fa-circle-xmark"></i> ${escapeHtml(x)}</div>`).join('')}</div>`);
    }
    if (warnings.length) {
      sections.push(`<div class="flash-message flash-warning" style="position:relative;top:0;right:0;margin:0 0 10px;">${warnings.map(x => `<div><i class="fa-solid fa-triangle-exclamation"></i> ${escapeHtml(x)}</div>`).join('')}</div>`);
    }
    if (missing.length) {
      sections.push(`<div class="text-sm text-muted"><strong>Missing inputs:</strong> ${missing.map(escapeHtml).join(', ')}</div>`);
    }
    container.innerHTML = sections.join('');
  }

  function escapeHtml(value) {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

  function renderScore(data) {
    if (!scorePanel) return;
    scorePanel.style.display = 'block';

    const total = Number(data.total) || 0;
    const color = scoreColor(total);
    if (scoreValue) {
      if (typeof gsap !== 'undefined') {
        const state = { value: Number.parseFloat(scoreValue.textContent) || 0 };
        gsap.to(state, {
          value: total,
          duration: 0.8,
          ease: 'power2.out',
          onUpdate: () => { scoreValue.textContent = state.value.toFixed(10); },
        });
      } else {
        scoreValue.textContent = decimal10(total);
      }
      scoreValue.style.color = color;
    }
    if (scoreLabel) {
      scoreLabel.textContent = scoreText(data);
      scoreLabel.style.color = color;
    }

    animateBar(bars.blood, data.blood_score, color);
    animateBar(bars.location, data.location_score, color);
    animateBar(bars.crossmatch, data.crossmatch_score, color);
    animateBar(bars.hla, data.hla_score, color);
    animateBar(bars.medical, data.medical_score, color);

    Object.entries(medicalOutputs).forEach(([key, [element, max]]) => {
      if (element) element.textContent = `${decimal10(data[key])}/${max}`;
    });

    if (crossmatchBadge) {
      const value = data.crossmatch || 'Pending';
      crossmatchBadge.textContent = value;
      crossmatchBadge.className = `badge ${value === 'Negative' ? 'badge-success' : value === 'Positive' ? 'badge-danger' : 'badge-warning'}`;
    }

    const metadata = byId('compatMetadata');
    if (metadata) {
      const distance = data.distance_km === null || data.distance_km === undefined
        ? 'Unavailable'
        : `${decimal10(data.distance_km)} km`;
      const ageDifference = data.age_difference_years === null || data.age_difference_years === undefined
        ? 'Unavailable'
        : `${decimal10(data.age_difference_years)} years`;
      metadata.innerHTML = [
        `<strong>Distance:</strong> ${distance}`,
        `<strong>Age difference:</strong> ${ageDifference}`,
        `<strong>HLA similarity:</strong> ${decimal10((Number(data.hla_similarity) || 0) * 100)}%`,
        `<strong>Data completeness:</strong> ${decimal10(data.data_completeness)}%`,
        `<strong>Formula:</strong> ${escapeHtml(data.score_version || 'KDMS-2.0')}`,
      ].join(' &nbsp;•&nbsp; ');
    }

    renderWarnings(data);

    if (submitBtn) {
      submitBtn.disabled = !data.is_eligible;
      submitBtn.style.opacity = data.is_eligible ? '1' : '0.4';
      submitBtn.title = data.is_eligible ? '' : 'Resolve hard stops and complete required testing first.';
    }
  }

  function showLoading() {
    if (scoreValue) scoreValue.textContent = '—';
    if (scoreLabel) {
      scoreLabel.textContent = 'Calculating precision score…';
      scoreLabel.style.color = '#445577';
    }
    Object.values(bars).forEach(item => {
      if (item.bar) item.bar.style.width = '0%';
    });
  }

  async function calculate(donorId, recipientId) {
    if (!donorId || !recipientId) return;
    if (donorId === lastDonorId && recipientId === lastRecipientId) return;
    lastDonorId = donorId;
    lastRecipientId = recipientId;
    showLoading();

    try {
      const response = await fetch(`${window.KDMS.baseUrl}/api/compatibility.php`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': window.KDMS.csrfToken,
        },
        body: JSON.stringify({
          donor_id: donorId,
          recipient_id: recipientId,
          _csrf_token: window.KDMS.csrfToken,
        }),
      });
      const json = await response.json();
      if (json.success && json.data) {
        renderScore(json.data);
      } else if (scoreLabel) {
        scoreLabel.textContent = json.message || 'Could not compute score';
      }
    } catch (error) {
      console.warn('[KDMS compatibility]', error);
      if (scoreLabel) scoreLabel.textContent = 'Network error';
    }
  }

  function selectionChanged() {
    const donorId = donorSelect?.value;
    const recipientId = recipientSelect?.value;
    if (!donorId || !recipientId) return;
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => calculate(donorId, recipientId), 250);
  }

  function init() {
    donorSelect?.addEventListener('change', selectionChanged);
    recipientSelect?.addEventListener('change', selectionChanged);
    if (donorSelect?.value && recipientSelect?.value) {
      calculate(donorSelect.value, recipientSelect.value);
    }
  }

  return { init, calculate, renderScore };
})();

document.addEventListener('DOMContentLoaded', () => CompatibilityCalc.init());
window.CompatibilityCalc = CompatibilityCalc;
