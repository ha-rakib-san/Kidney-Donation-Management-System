/**
 * KDMS Pro — three-scene.js
 * Three.js r128: DNA double-helix (login) + node-graph (dashboard hero)
 */

'use strict';

/* ─── Login Page: DNA Double Helix ─────────────────────────────────────────── */
const KDMSThree = (() => {

  let scene, camera, renderer, animId;
  let helixGroup, particleSystem;
  let mouse = { x: 0, y: 0 };
  let targetRotation = { x: 0, y: 0 };

  function initLoginScene(canvasId) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || typeof THREE === 'undefined') return;

    // Scene
    scene    = new THREE.Scene();
    scene.fog = new THREE.Fog(0x050B18, 20, 80);
    camera   = new THREE.PerspectiveCamera(60, canvas.clientWidth / canvas.clientHeight, 0.1, 200);
    camera.position.set(0, 0, 22);

    renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x050B18, 1);

    // Lighting
    const ambLight = new THREE.AmbientLight(0x003366, 0.6);
    scene.add(ambLight);
    const dirLight = new THREE.DirectionalLight(0x00D4FF, 1.2);
    dirLight.position.set(5, 10, 5);
    scene.add(dirLight);
    const redLight = new THREE.PointLight(0xFF2D55, 0.8, 30);
    redLight.position.set(-8, 0, 5);
    scene.add(redLight);

    // Build DNA helix
    helixGroup = new THREE.Group();
    scene.add(helixGroup);
    _buildDNAHelix();

    // Particle field (background molecules)
    _buildParticles();

    // Mouse parallax
    document.addEventListener('mousemove', (e) => {
      mouse.x = (e.clientX / window.innerWidth  - 0.5) * 2;
      mouse.y = (e.clientY / window.innerHeight - 0.5) * 2;
    });

    window.addEventListener('resize', _onResize);
    _animate();
  }

  function _buildDNAHelix() {
    const cyanMat   = new THREE.MeshPhongMaterial({ color: 0x00D4FF, emissive: 0x003344, shininess: 80 });
    const crimsonMat = new THREE.MeshPhongMaterial({ color: 0xFF2D55, emissive: 0x330011, shininess: 60 });
    const strandMat  = new THREE.MeshPhongMaterial({ color: 0x00D4FF, emissive: 0x002233, transparent: true, opacity: 0.55 });
    const bondMat    = new THREE.MeshPhongMaterial({ color: 0xFF2D55, emissive: 0x330011, transparent: true, opacity: 0.65 });

    const nodeGeo = new THREE.SphereGeometry(0.22, 12, 12);
    const TURNS   = 5;
    const STEPS   = 28 * TURNS;
    const HEIGHT  = 18;
    const RADIUS  = 2.2;

    const strand1Points = [];
    const strand2Points = [];

    for (let i = 0; i <= STEPS; i++) {
      const t   = i / STEPS;
      const y   = (t - 0.5) * HEIGHT;
      const ang = t * Math.PI * 2 * TURNS;

      const x1 =  Math.cos(ang) * RADIUS;
      const z1 =  Math.sin(ang) * RADIUS;
      const x2 = -Math.cos(ang) * RADIUS;
      const z2 = -Math.sin(ang) * RADIUS;

      strand1Points.push(new THREE.Vector3(x1, y, z1));
      strand2Points.push(new THREE.Vector3(x2, y, z2));

      // Nucleotide nodes every few steps
      if (i % 3 === 0) {
        const n1 = new THREE.Mesh(nodeGeo, cyanMat.clone());
        n1.position.set(x1, y, z1);
        n1.userData.baseY = y;
        n1.userData.baseScale = 1;
        helixGroup.add(n1);

        const n2 = new THREE.Mesh(nodeGeo, cyanMat.clone());
        n2.position.set(x2, y, z2);
        n2.userData.baseY = y;
        helixGroup.add(n2);

        // Base pair bond (cross-connector)
        if (i % 9 === 0) {
          const bondLen = Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(z2 - z1, 2));
          const bondGeo = new THREE.CylinderGeometry(0.05, 0.05, bondLen, 6);
          const bond    = new THREE.Mesh(bondGeo, bondMat);
          bond.position.set((x1 + x2) / 2, y, (z1 + z2) / 2);
          bond.lookAt(new THREE.Vector3(x2, y, z2));
          bond.rotateX(Math.PI / 2);
          helixGroup.add(bond);
        }
      }
    }

    // Strand tubes
    function makeTube(points, mat) {
      const curve = new THREE.CatmullRomCurve3(points);
      const geo   = new THREE.TubeGeometry(curve, STEPS * 3, 0.08, 6, false);
      helixGroup.add(new THREE.Mesh(geo, mat));
    }
    makeTube(strand1Points, strandMat.clone());
    makeTube(strand2Points, strandMat.clone());

    helixGroup.position.set(-2, 0, -2);
  }

  function _buildParticles() {
    const count    = 220;
    const positions = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      positions[i * 3]     = (Math.random() - 0.5) * 40;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 30;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 20 - 5;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({ color: 0x00D4FF, size: 0.08, transparent: true, opacity: 0.35 });
    particleSystem = new THREE.Points(geo, mat);
    scene.add(particleSystem);
  }

  function _animate() {
    animId = requestAnimationFrame(_animate);
    const t = Date.now() * 0.001;

    // Smooth mouse parallax
    targetRotation.y += (mouse.x * 0.15 - targetRotation.y) * 0.04;
    targetRotation.x += (mouse.y * 0.10 - targetRotation.x) * 0.04;

    helixGroup.rotation.y = t * 0.18 + targetRotation.y;
    helixGroup.rotation.x = targetRotation.x;

    // Pulse nucleotide nodes
    helixGroup.children.forEach((child, idx) => {
      if (child.geometry && child.geometry.type === 'SphereGeometry') {
        const pulse = 1 + Math.sin(t * 2 + idx * 0.4) * 0.12;
        child.scale.setScalar(pulse);
      }
    });

    // Drift particles
    if (particleSystem) {
      particleSystem.rotation.y = t * 0.03;
      particleSystem.rotation.x = t * 0.01;
    }

    renderer.render(scene, camera);
  }

  function _onResize() {
    const canvas = renderer.domElement;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
  }

  function destroy() {
    if (animId) cancelAnimationFrame(animId);
    if (renderer) renderer.dispose();
  }

  /* ─── Dashboard node-graph (subtle background) ──────────────────────────── */
  function initDashboardScene(canvasId) {
    const canvas = document.getElementById(canvasId);
    if (!canvas || typeof THREE === 'undefined') return;

    const dScene    = new THREE.Scene();
    const dCamera   = new THREE.PerspectiveCamera(70, canvas.clientWidth / canvas.clientHeight, 0.1, 100);
    dCamera.position.set(0, 0, 18);

    const dRenderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    dRenderer.setSize(canvas.clientWidth, canvas.clientHeight);
    dRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    dRenderer.setClearColor(0x000000, 0);

    const nodeGroup = new THREE.Group();
    dScene.add(nodeGroup);

    // Randomly placed nodes
    const NODE_COUNT = 16;
    const nodes = [];
    const nodeMat = new THREE.MeshPhongMaterial({ color: 0x00D4FF, emissive: 0x002244, transparent: true, opacity: 0.6 });
    const nodeGeo = new THREE.SphereGeometry(0.18, 10, 10);

    for (let i = 0; i < NODE_COUNT; i++) {
      const mesh = new THREE.Mesh(nodeGeo, nodeMat.clone());
      mesh.position.set(
        (Math.random() - 0.5) * 22,
        (Math.random() - 0.5) * 12,
        (Math.random() - 0.5) * 6
      );
      mesh.userData.phase = Math.random() * Math.PI * 2;
      nodeGroup.add(mesh);
      nodes.push(mesh);
    }

    // Connect nearby nodes with lines
    const lineMat = new THREE.LineBasicMaterial({ color: 0x00D4FF, transparent: true, opacity: 0.12 });
    nodes.forEach((a, i) => {
      nodes.forEach((b, j) => {
        if (j <= i) return;
        const dist = a.position.distanceTo(b.position);
        if (dist < 8) {
          const geo = new THREE.BufferGeometry().setFromPoints([a.position, b.position]);
          nodeGroup.add(new THREE.Line(geo, lineMat));
        }
      });
    });

    const ambLight2 = new THREE.AmbientLight(0x003366, 0.4);
    dScene.add(ambLight2);

    let animId2;
    function animateDash() {
      animId2 = requestAnimationFrame(animateDash);
      const t = Date.now() * 0.001;
      nodeGroup.rotation.y = t * 0.04;
      nodes.forEach(n => {
        const pulse = 1 + Math.sin(t * 1.5 + n.userData.phase) * 0.15;
        n.scale.setScalar(pulse);
        n.material.opacity = 0.35 + Math.sin(t + n.userData.phase) * 0.15;
      });
      dRenderer.render(dScene, dCamera);
    }
    animateDash();

    window.addEventListener('resize', () => {
      const w = canvas.clientWidth, h = canvas.clientHeight;
      dCamera.aspect = w / h;
      dCamera.updateProjectionMatrix();
      dRenderer.setSize(w, h);
    });
  }

  return { initLoginScene, initDashboardScene, destroy };
})();

// Auto-init based on page
document.addEventListener('DOMContentLoaded', () => {
  if (document.getElementById('loginCanvas'))    KDMSThree.initLoginScene('loginCanvas');
  if (document.getElementById('dashboardCanvas')) KDMSThree.initDashboardScene('dashboardCanvas');
});
