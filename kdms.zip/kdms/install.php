<?php
/**
 * KDMS Pro — install.php
 *
 * One-time installer for the SQLite backend. Visiting this page creates
 * storage/kdms.sqlite from sql/01_schema.sql through sql/06_seed.sql (in the
 * dependency order documented in config/database.php) and reports progress.
 *
 * This is the SQLite-era equivalent of "import these 6 files via
 * phpMyAdmin" from the old MySQL setup guide — except it's automatic.
 * NOTE: config/database.php already runs this same bootstrap automatically
 * the first time anything connects to a missing database file, so most
 * people will never need to visit this page at all; it exists for anyone
 * who wants to see the import happen explicitly, or to re-run it after
 * deleting storage/kdms.sqlite.
 */
declare(strict_types=1);
define('KDMS_ROOT', __DIR__);

$dbPath = KDMS_ROOT . '/storage/kdms.sqlite';
$alreadyExists = is_file($dbPath);
$forceReset = isset($_GET['reset']) && $_GET['reset'] === '1';

if ($forceReset && $alreadyExists) {
    @unlink($dbPath);
    @unlink($dbPath . '-wal');
    @unlink($dbPath . '-shm');
    @unlink($dbPath . '-journal');
    $alreadyExists = false;
}

require_once KDMS_ROOT . '/config/database.php';

$steps = [];
$error = null;

try {
    if (!$alreadyExists) {
        if (!is_dir(KDMS_ROOT . '/storage')) {
            mkdir(KDMS_ROOT . '/storage', 0775, true);
        }
        $pdo = new PDO('sqlite:' . $dbPath);
        $pdo->exec('PRAGMA foreign_keys = ON');
        foreach (DB_BOOTSTRAP_FILES as $file) {
            $path = KDMS_ROOT . '/sql/' . $file;
            $sql = file_get_contents($path);
            $pdo->exec((string) $sql);
            $steps[] = $file;
        }
        require_once KDMS_ROOT . '/lib/Procedures.php';
        Procedures::recalculateAllMatches();
    }
    $counts = [];
    $check = new PDO('sqlite:' . $dbPath);
    foreach (['hospitals','doctors','donors','recipients','compatibility_matches','transplants','users'] as $t) {
        $counts[$t] = (int) $check->query("SELECT COUNT(*) c FROM {$t}")->fetch()['c'];
    }
} catch (Throwable $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Install — KDMS Pro</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;700&family=Inter:wght@300;400;500;600&family=JetBrains+Mono&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="/kdms/assets/css/main.css">
</head>
<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;">
<div class="glass-card no-hover" style="max-width:640px;width:100%;padding:40px;">
    <h1 style="font-family:var(--font-display);margin-bottom:6px;">KDMS Pro <span style="color:var(--accent-cyan);">Installer</span></h1>
    <p class="text-sm text-muted" style="margin-bottom:24px;">SQLite database bootstrap — Global Hybrid Edition</p>

    <?php if ($error): ?>
        <div class="flash-message flash-danger" style="position:relative;top:0;right:0;">
            <span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span>
            <div class="flash-text">Install failed: <?= htmlspecialchars($error) ?></div>
        </div>
    <?php elseif ($alreadyExists && !$steps): ?>
        <div class="flash-message flash-warning" style="position:relative;top:0;right:0;">
            <span class="flash-icon"><i class="fa-solid fa-triangle-exclamation"></i></span>
            <div class="flash-text">storage/kdms.sqlite already exists — nothing to do. Use <code>?reset=1</code> to wipe and reseed.</div>
        </div>
    <?php else: ?>
        <div class="flash-message flash-success" style="position:relative;top:0;right:0;">
            <span class="flash-icon"><i class="fa-solid fa-circle-check"></i></span>
            <div class="flash-text">Database created and seeded successfully.</div>
        </div>
        <ul style="margin:16px 0;padding-left:20px;color:var(--text-secondary);font-size:.88rem;">
            <?php foreach ($steps as $s): ?><li><?= htmlspecialchars($s) ?></li><?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <?php if (!$error && isset($counts)): ?>
    <div class="form-grid form-grid-3" style="margin-top:20px;">
        <?php foreach ($counts as $table => $count): ?>
        <div class="glass-card no-hover" style="padding:14px;text-align:center;">
            <div style="font-family:var(--font-mono);font-size:1.4rem;font-weight:700;color:var(--accent-cyan);"><?= $count ?></div>
            <div style="font-size:.72rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.05em;"><?= str_replace('_',' ',$table) ?></div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <div style="margin-top:28px;display:flex;gap:10px;">
        <a href="/kdms/login.php" class="btn btn-primary"><i class="fa-solid fa-right-to-bracket"></i> Go to Login</a>
        <a href="/kdms/install.php?reset=1" class="btn btn-ghost" onclick="return confirm('This will WIPE the existing database and reseed from scratch. Continue?')"><i class="fa-solid fa-rotate"></i> Reset &amp; Reseed</a>
    </div>
</div>
</body>
</html>
