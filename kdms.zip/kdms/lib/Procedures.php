<?php
/**
 * KDMS Pro — Procedures
 *
 * SQLite has no stored-procedure language, so every one of the eight
 * original MySQL stored procedures (sql/02_procedures.sql, kept as
 * documentation only) lives here as a static method instead. This class
 * also implements the two donor-list filters for the international network:
 *
 *   - Procedures::donorsForRecipient()   gathers Available, eligible donors
 *     for a given recipient with a computed compatibility score AND the
 *     great-circle distance from the donor's hospital to the recipient's
 *     hospital.
 *   - Procedures::sortByCompatibility()  Filter 1: highest score first.
 *   - Procedures::sortByLocation()       Filter 2: donors are grouped by
 *     country — the recipient's own country always first, then other
 *     countries ordered by how close their nearest donor hospital is to the
 *     recipient's hospital (closest country next, then the next-closest,
 *     and so on). Inside every country group, donors are ordered by
 *     compatibility score, highest first.
 */

declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';

class Procedures
{
    // ─── 1. Precision compatibility scoring ───────────────────────────────
    /**
     * Calculates a deterministic 0-100 clinical decision-support score.
     *
     * Weighting:
     *   ABO blood compatibility 15 + distance 20 + crossmatch 20 + HLA 15
     *   + medical profile 30 = 100.
     *
     * Every calculation is retained at 10 decimal places. Missing data is
     * never assumed to be normal. A positive crossmatch or ABO incompatibility
     * is a hard stop and produces a final score of zero.
     */
    public static function calculateCompatibility(int $donorId, int $recipientId): array
    {
        $donor = Database::fetchOne(
            'SELECT d.*, h.lat AS hospital_lat, h.lng AS hospital_lng, h.country AS hospital_country, h.city AS hospital_city
             FROM donors d LEFT JOIN hospitals h ON d.hospital_id = h.hospital_id
             WHERE d.donor_id = ?',
            [$donorId]
        );
        $recipient = Database::fetchOne(
            'SELECT r.*, h.lat AS hospital_lat, h.lng AS hospital_lng, h.country AS hospital_country, h.city AS hospital_city
             FROM recipients r LEFT JOIN hospitals h ON r.hospital_id = h.hospital_id
             WHERE r.recipient_id = ?',
            [$recipientId]
        );

        if (!$donor || !$recipient) {
            return self::emptyCompatibility('Donor or recipient not found.');
        }

        $donorTest = self::latestMedicalTest($donorId, 'Donor');
        $recipientTest = self::latestMedicalTest($recipientId, 'Recipient');

        $blood = self::bloodCompatibilityScore((string)$donor['blood_group'], (string)$recipient['blood_group']);
        $location = self::locationCompatibility($donor, $recipient);

        // The current schema stores crossmatch results in each person's latest
        // medical record. Treat either positive result as a hard stop, require
        // both sides to be verified negative, and otherwise keep the pair pending.
        $donorCrossmatch = trim((string)($donorTest['crossmatch'] ?? 'Pending'));
        $recipientCrossmatch = trim((string)($recipientTest['crossmatch'] ?? 'Pending'));
        $validCrossmatchValues = ['Negative', 'Positive', 'Pending'];
        if (!in_array($donorCrossmatch, $validCrossmatchValues, true)) $donorCrossmatch = 'Pending';
        if (!in_array($recipientCrossmatch, $validCrossmatchValues, true)) $recipientCrossmatch = 'Pending';
        if ($donorCrossmatch === 'Positive' || $recipientCrossmatch === 'Positive') {
            $crossmatch = 'Positive';
        } elseif ($donorCrossmatch === 'Negative' && $recipientCrossmatch === 'Negative') {
            $crossmatch = 'Negative';
        } else {
            $crossmatch = 'Pending';
        }
        $crossmatchScore = $crossmatch === 'Negative' ? 20.0 : 0.0;

        $donorHla = trim((string)($donorTest['tissue_type_hla'] ?? ''));
        $recipientHla = trim((string)($recipientTest['tissue_type_hla'] ?? ''));
        $hla = self::hlaCompatibilityScore($donorHla, $recipientHla);
        $medical = self::medicalCompatibilityScore($donor, $recipient, $donorTest, $recipientTest);

        $rawTotal = self::round10(
            $blood['score'] + $location['score'] + $crossmatchScore + $hla['score'] + $medical['score']
        );

        $warnings = $medical['warnings'];
        $hardStops = [];
        if (!$blood['compatible']) {
            $hardStops[] = 'ABO blood groups are incompatible.';
        }
        if ($crossmatch === 'Positive') {
            $hardStops[] = 'Positive crossmatch indicates donor-specific antibody incompatibility.';
        } elseif ($crossmatch !== 'Negative') {
            $warnings[] = 'A verified negative crossmatch is required before approval.';
        }
        if (!$donorTest || !$recipientTest) {
            $warnings[] = 'Both donor and recipient require a valid medical test record.';
        }
        if ($donorTest && self::number($donorTest['gfr_numeric'] ?? null) !== null
            && (float)$donorTest['gfr_numeric'] < 60.0) {
            $hardStops[] = 'Donor GFR is below 60 mL/min/1.73 m².';
        }
        if ($donorTest && (
            ($donorTest['infection_screen'] ?? 'Clear') === 'Flagged'
            || ($donorTest['hiv'] ?? 'Negative') === 'Positive'
            || ($donorTest['hepatitis_b'] ?? 'Negative') === 'Positive'
            || ($donorTest['hepatitis_c'] ?? 'Negative') === 'Positive'
        )) {
            $hardStops[] = 'Donor infection screening requires specialist clearance.';
        }

        if ($donorHla === '' || $recipientHla === '') {
            $warnings[] = 'Both donor and recipient HLA values are required for approval.';
        }
        if ($medical['missing_fields'] !== []) {
            $warnings[] = 'Complete all precision medical fields before approval.';
        }

        $isEligible = $blood['compatible']
            && $crossmatch === 'Negative'
            && $donorTest !== null
            && $recipientTest !== null
            && $donorHla !== ''
            && $recipientHla !== ''
            && $medical['missing_fields'] === []
            && $hardStops === [];

        $total = $hardStops === [] ? min(100.0, $rawTotal) : 0.0;
        $detail = sprintf(
            'Blood %.10f/15 · Distance %.10f/20 · Crossmatch %.10f/20 · HLA %.10f/15 · Medical %.10f/30',
            $blood['score'], $location['score'], $crossmatchScore, $hla['score'], $medical['score']
        );

        $result = [
            'total'                    => self::round10($total),
            'raw_total'                => self::round10($rawTotal),
            'blood_score'              => self::round10($blood['score']),
            'location_score'           => self::round10($location['score']),
            'crossmatch_score'         => self::round10($crossmatchScore),
            'hla_score'                => self::round10($hla['score']),
            'medical_score'            => self::round10($medical['score']),
            'age_score'                => self::round10($medical['components']['age']),
            'bmi_score'                => self::round10($medical['components']['bmi']),
            'creatinine_score'         => self::round10($medical['components']['creatinine']),
            'gfr_score'                => self::round10($medical['components']['gfr']),
            'blood_pressure_score'     => self::round10($medical['components']['blood_pressure']),
            'hemoglobin_score'         => self::round10($medical['components']['hemoglobin']),
            'diabetes_score'           => self::round10($medical['components']['diabetes']),
            'hypertension_score'       => self::round10($medical['components']['hypertension']),
            'pra_score'                => self::round10($medical['components']['pra']),
            'distance_km'              => $location['distance_km'],
            'location_method'          => $location['method'],
            'age_difference_years'     => $medical['age_difference_years'],
            'donor_age_years'          => $medical['donor_age_years'],
            'recipient_age_years'      => $medical['recipient_age_years'],
            'data_completeness'        => self::round10($medical['completeness']),
            'crossmatch'               => $crossmatch,
            'crossmatch_source'        => 'Donor and recipient latest tests',
            'donor_crossmatch'         => $donorCrossmatch,
            'recipient_crossmatch'     => $recipientCrossmatch,
            'donor_hla'                => $donorHla,
            'recipient_hla'            => $recipientHla,
            'hla_similarity'           => self::round10($hla['similarity']),
            'hla_matches'              => $hla['matches'],
            'hla_union_count'          => $hla['union_count'],
            'donor_country'            => (string)$donor['country'],
            'recipient_country'        => (string)$recipient['country'],
            'is_eligible'              => $isEligible,
            'hard_stops'               => array_values(array_unique($hardStops)),
            'warnings'                 => array_values(array_unique($warnings)),
            'missing_fields'           => $medical['missing_fields'],
            'medical_values'           => $medical['values'],
            'score_version'            => 'KDMS-2.0',
            'detail'                   => $detail,
        ];

        return $result;
    }

    /** Create a match using the same scoring engine used by the live preview. */
    public static function createCompatibilityMatch(int $donorId, int $recipientId, bool $aiSuggested = false): int
    {
        $s = self::calculateCompatibility($donorId, $recipientId);
        $sql = "INSERT INTO compatibility_matches (
                    donor_id, recipient_id, match_score, blood_score, location_score,
                    crossmatch_score, hla_score, medical_score, age_score, bmi_score,
                    creatinine_score, gfr_score, blood_pressure_score, hemoglobin_score,
                    diabetes_score, hypertension_score, pra_score, distance_km,
                    age_difference_years, data_completeness, is_eligible, score_version,
                    score_detail_json, tissue_hla_donor, tissue_hla_recipient,
                    crossmatch_result, review_result, is_ai_suggested
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'Pending', ?)";
        $id = Database::execute($sql, [
            $donorId, $recipientId, $s['total'], $s['blood_score'], $s['location_score'],
            $s['crossmatch_score'], $s['hla_score'], $s['medical_score'], $s['age_score'], $s['bmi_score'],
            $s['creatinine_score'], $s['gfr_score'], $s['blood_pressure_score'], $s['hemoglobin_score'],
            $s['diabetes_score'], $s['hypertension_score'], $s['pra_score'], $s['distance_km'],
            $s['age_difference_years'], $s['data_completeness'], $s['is_eligible'] ? 1 : 0, $s['score_version'],
            json_encode($s, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $s['donor_hla'], $s['recipient_hla'],
            $s['crossmatch'], $aiSuggested ? 1 : 0,
        ]);
        return (int)$id;
    }

    // ─── 2. sp_auto_match_donors_for_recipient ───────────────────────────────
    public static function autoMatchDonorsForRecipient(int $recipientId, int $minScore = 40): array
    {
        $recipient = Database::fetchOne('SELECT * FROM recipients WHERE recipient_id = ?', [$recipientId]);
        if (!$recipient || $recipient['wait_status'] !== 'Waiting') {
            return [];
        }

        $donors = Database::fetchAll("SELECT donor_id FROM donors WHERE status = 'Available'");
        $created = [];
        foreach ($donors as $d) {
            $existing = Database::fetchOne(
                'SELECT match_id FROM compatibility_matches WHERE donor_id = ? AND recipient_id = ?',
                [$d['donor_id'], $recipientId]
            );
            if ($existing) {
                continue;
            }
            $score = self::calculateCompatibility((int)$d['donor_id'], $recipientId);
            if (!$score['is_eligible'] || $score['total'] < $minScore) {
                continue;
            }
            try {
                $matchId = self::createCompatibilityMatch((int)$d['donor_id'], $recipientId, true);
                $created[] = ['donor_id' => $d['donor_id'], 'match_id' => $matchId, 'score' => $score['total']];
            } catch (PDOException) {
                continue;
            }
        }
        return $created;
    }

    // ─── 3. sp_prioritize_waitlist ────────────────────────────────────────────
    public static function prioritizeWaitlist(): int
    {
        $weights = ['Critical' => 4.0, 'High' => 3.0, 'Medium' => 2.0, 'Low' => 1.0];
        $waiting = Database::fetchAll("SELECT * FROM recipients WHERE wait_status = 'Waiting'");

        $scored = [];
        foreach ($waiting as $r) {
            $waitDays = (int) floor((time() - strtotime((string) $r['wait_since'])) / 86400);
            $urgencyWeight = $weights[$r['urgency_level']] ?? 2.0;
            $gfr = (float) ($r['gfr_level'] ?? 30);
            $gfrScore = max(0, min(25, (30 - $gfr) / 30 * 25)); // lower GFR -> higher score, capped 25
            $ageUrgency = 15.0; // placeholder weight kept for parity with the documented formula
            $priority = ($urgencyWeight * 40) + (min($waitDays, 365) / 30 * 20) + $gfrScore + ($ageUrgency * 0 + 0);
            $scored[] = ['recipient_id' => $r['recipient_id'], 'priority' => round($priority, 2), 'weight' => $urgencyWeight, 'wait_days' => $waitDays];
        }

        usort($scored, static fn($a, $b) => $b['priority'] <=> $a['priority']);

        Database::beginTransaction();
        try {
            $pos = 1;
            foreach ($scored as $s) {
                $exists = Database::fetchOne('SELECT queue_id FROM waitlist_queue WHERE recipient_id = ?', [$s['recipient_id']]);
                if ($exists) {
                    Database::execute(
                        'UPDATE waitlist_queue SET queue_position = ?, priority_score = ?, urgency_weight = ?, last_recalculated = CURRENT_TIMESTAMP WHERE recipient_id = ?',
                        [$pos, $s['priority'], $s['weight'], $s['recipient_id']]
                    );
                } else {
                    Database::execute(
                        'INSERT INTO waitlist_queue (recipient_id, queue_position, priority_score, urgency_weight) VALUES (?, ?, ?, ?)',
                        [$s['recipient_id'], $pos, $s['priority'], $s['weight']]
                    );
                }
                $pos++;
            }
            Database::commit();
        } catch (PDOException $e) {
            Database::rollback();
            throw $e;
        }
        return count($scored);
    }

    // ─── 4. sp_approve_match / reject ────────────────────────────────────────
    public static function approveMatch(int $matchId, int $reviewerUserId, ?string $notes = null): bool
    {
        self::recalculateMatch($matchId);
        $match = Database::fetchOne('SELECT * FROM compatibility_matches WHERE match_id = ?', [$matchId]);
        if (!$match || $match['review_result'] !== 'Pending') {
            return false;
        }
        if ((int)($match['is_eligible'] ?? 0) !== 1) {
            throw new RuntimeException('This match is not clinically eligible. Resolve hard stops and complete all required testing first.');
        }
        Database::execute(
            "UPDATE compatibility_matches SET review_result = 'Approved', reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP, review_notes = ? WHERE match_id = ?",
            [$reviewerUserId, $notes, $matchId]
        );
        Database::execute(
            "UPDATE recipients SET wait_status = 'Matched', updated_at = CURRENT_TIMESTAMP WHERE recipient_id = ?",
            [$match['recipient_id']]
        );
        self::notifyDoctorsFor((int) $match['donor_id'], 'Match #' . $matchId . ' Approved', 'The compatibility match has been approved and is ready for transplant scheduling.', 'success');
        self::audit($reviewerUserId, 'APPROVE', 'compatibility_matches', $matchId, null, ['review_result' => 'Approved'], 'Match approved');
        return true;
    }

    public static function rejectMatch(int $matchId, int $reviewerUserId, ?string $notes = null): bool
    {
        $match = Database::fetchOne('SELECT * FROM compatibility_matches WHERE match_id = ?', [$matchId]);
        if (!$match || $match['review_result'] !== 'Pending') {
            return false;
        }
        Database::execute(
            "UPDATE compatibility_matches SET review_result = 'Rejected', reviewed_by = ?, reviewed_at = CURRENT_TIMESTAMP, review_notes = ? WHERE match_id = ?",
            [$reviewerUserId, $notes, $matchId]
        );
        self::audit($reviewerUserId, 'REJECT', 'compatibility_matches', $matchId, null, ['review_result' => 'Rejected'], 'Match rejected');
        return true;
    }

    // ─── 5. sp_complete_transplant ───────────────────────────────────────────
    public static function completeTransplant(int $transplantId, string $result, ?string $notes = null): bool
    {
        if (!in_array($result, ['Successful', 'Failed', 'Cancelled', 'Ongoing'], true)) {
            throw new InvalidArgumentException('Invalid transplant result');
        }
        // trg_transplant_success / trg_transplant_failed in 03_triggers.sql do the
        // donor/recipient/doctor/waitlist cascade automatically on this UPDATE.
        Database::execute(
            'UPDATE transplants SET result = ?, notes = COALESCE(?, notes), updated_at = CURRENT_TIMESTAMP WHERE transplant_id = ?',
            [$result, $notes, $transplantId]
        );
        return true;
    }

    // ─── 6. sp_get_dashboard_stats ───────────────────────────────────────────
    public static function getDashboardStats(): array
    {
        return [
            'hospitals'   => (int) Database::fetchOne('SELECT COUNT(*) c FROM hospitals')['c'],
            'countries'   => (int) Database::fetchOne('SELECT COUNT(DISTINCT country) c FROM hospitals')['c'],
            'doctors'     => (int) Database::fetchOne('SELECT COUNT(*) c FROM doctors')['c'],
            'donors'      => (int) Database::fetchOne('SELECT COUNT(*) c FROM donors')['c'],
            'recipients'  => (int) Database::fetchOne('SELECT COUNT(*) c FROM recipients')['c'],
            'matches'     => (int) Database::fetchOne('SELECT COUNT(*) c FROM compatibility_matches')['c'],
            'transplants' => (int) Database::fetchOne('SELECT COUNT(*) c FROM transplants')['c'],
            'followups'   => (int) Database::fetchOne('SELECT COUNT(*) c FROM follow_ups')['c'],
        ];
    }

    // ─── 7. sp_search_donors ──────────────────────────────────────────────────
    public static function searchDonors(array $filters): array
    {
        $sql = 'SELECT d.*, h.name AS hospital_name, h.country AS hospital_country FROM donors d LEFT JOIN hospitals h ON d.hospital_id = h.hospital_id WHERE 1=1';
        $params = [];

        if (!empty($filters['blood_group'])) {
            $sql .= ' AND d.blood_group = ?';
            $params[] = $filters['blood_group'];
        }
        if (!empty($filters['country'])) {
            $sql .= ' AND d.country = ?';
            $params[] = $filters['country'];
        }
        if (!empty($filters['city'])) {
            $sql .= ' AND d.city = ?';
            $params[] = $filters['city'];
        }
        if (!empty($filters['donor_type'])) {
            $sql .= ' AND d.donor_type = ?';
            $params[] = $filters['donor_type'];
        }
        if (!empty($filters['status'])) {
            $sql .= ' AND d.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['keyword'])) {
            // LIKE-based search (see schema header note on the FTS5 -> LIKE decision)
            $sql .= ' AND d.name LIKE ?';
            $params[] = '%' . $filters['keyword'] . '%';
        }
        if (!empty($filters['hla_type'])) {
            $sql .= ' AND d.donor_id IN (SELECT person_id FROM medical_tests WHERE person_type = "Donor" AND tissue_type_hla = ?)';
            $params[] = $filters['hla_type'];
        }
        if (!empty($filters['crossmatch'])) {
            $sql .= ' AND d.donor_id IN (SELECT person_id FROM medical_tests WHERE person_type = "Donor" AND crossmatch = ?)';
            $params[] = $filters['crossmatch'];
        }

        $sql .= ' ORDER BY d.name ASC';
        if (!empty($filters['limit'])) {
            $sql .= ' LIMIT ' . (int) $filters['limit'];
        }

        return Database::fetchAll($sql, $params);
    }

    // ─── 8. sp_generate_monthly_report ───────────────────────────────────────
    public static function generateMonthlyReport(int $year, int $month): array
    {
        $ym = sprintf('%04d-%02d', $year, $month);

        $newDonors = Database::fetchOne(
            "SELECT COUNT(*) c FROM donors WHERE strftime('%Y-%m', created_at) = ?", [$ym]
        )['c'];
        $newRecipients = Database::fetchOne(
            "SELECT COUNT(*) c FROM recipients WHERE strftime('%Y-%m', created_at) = ?", [$ym]
        )['c'];
        $matchesMade = Database::fetchOne(
            "SELECT COUNT(*) c FROM compatibility_matches WHERE strftime('%Y-%m', match_date) = ?", [$ym]
        )['c'];
        $transplantsDone = Database::fetchOne(
            "SELECT COUNT(*) c FROM transplants WHERE strftime('%Y-%m', surgery_date) = ?", [$ym]
        )['c'];
        $successCount = Database::fetchOne(
            "SELECT COUNT(*) c FROM transplants WHERE strftime('%Y-%m', surgery_date) = ? AND result = 'Successful'", [$ym]
        )['c'];
        $failedCount = Database::fetchOne(
            "SELECT COUNT(*) c FROM transplants WHERE strftime('%Y-%m', surgery_date) = ? AND result = 'Failed'", [$ym]
        )['c'];
        $avgScore = Database::fetchOne(
            "SELECT ROUND(AVG(match_score), 10) a FROM compatibility_matches WHERE strftime('%Y-%m', match_date) = ?", [$ym]
        )['a'];

        // City, Country breakdown (international edition: report groups by both)
        $byLocation = Database::fetchAll(
            "SELECT h.city, h.country, COUNT(*) AS transplant_count
             FROM transplants t
             JOIN hospitals h ON t.hospital_id = h.hospital_id
             WHERE strftime('%Y-%m', t.surgery_date) = ?
             GROUP BY h.city, h.country
             ORDER BY transplant_count DESC",
            [$ym]
        );

        return [
            'year' => $year, 'month' => $month,
            'new_donors' => (int) $newDonors, 'new_recipients' => (int) $newRecipients,
            'matches_made' => (int) $matchesMade, 'transplants_done' => (int) $transplantsDone,
            'successful' => (int) $successCount, 'failed' => (int) $failedCount,
            'success_rate' => $transplantsDone > 0 ? round($successCount / $transplantsDone * 100, 1) : 0.0,
            'success_rate_pct' => $transplantsDone > 0 ? round($successCount / $transplantsDone * 100, 1) : 0.0,
            'avg_match_score' => $avgScore !== null ? (float) $avgScore : 0.0,
            'by_location' => $byLocation,
        ];
    }

    // ════════════════════════════════════════════════════════════════════════
    // NEW: Donor-list filters for the global hybrid network
    // ════════════════════════════════════════════════════════════════════════

    /**
     * Haversine great-circle distance in kilometres between two lat/lng pairs.
     */
    public static function haversineKm(float $lat1, float $lng1, float $lat2, float $lng2): float
    {
        $earthRadiusKm = 6371.0;
        $dLat = deg2rad($lat2 - $lat1);
        $dLng = deg2rad($lng2 - $lng1);
        $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        return $earthRadiusKm * $c;
    }

    /**
     * Builds the candidate donor list for a recipient: every Available donor,
     * each with a computed compatibility score (Procedures::calculateCompatibility)
     * and the distance in km from the donor's hospital to the recipient's
     * hospital (null if either hospital has no lat/lng on file).
     *
     * Returns an array of rows shaped like:
     *   ['donor' => <donors row + hospital_name/country/city>, 'score' => <breakdown array>, 'distance_km' => float|null]
     */
    public static function donorsForRecipient(int $recipientId): array
    {
        $recipient = Database::fetchOne(
            'SELECT r.*, h.lat AS hosp_lat, h.lng AS hosp_lng, h.country AS hosp_country, h.name AS hosp_name
             FROM recipients r LEFT JOIN hospitals h ON r.hospital_id = h.hospital_id
             WHERE r.recipient_id = ?',
            [$recipientId]
        );
        if (!$recipient) {
            return [];
        }

        $donors = Database::fetchAll(
            "SELECT d.*, h.name AS hospital_name, h.country AS hospital_country, h.city AS hospital_city,
                    h.lat AS hospital_lat, h.lng AS hospital_lng
             FROM donors d LEFT JOIN hospitals h ON d.hospital_id = h.hospital_id
             WHERE d.status = 'Available'"
        );

        $results = [];
        foreach ($donors as $donor) {
            $score = self::calculateCompatibility((int) $donor['donor_id'], $recipientId);

            $distance = null;
            if ($donor['hospital_lat'] !== null && $donor['hospital_lng'] !== null
                && $recipient['hosp_lat'] !== null && $recipient['hosp_lng'] !== null) {
                $distance = self::haversineKm(
                    (float) $recipient['hosp_lat'], (float) $recipient['hosp_lng'],
                    (float) $donor['hospital_lat'], (float) $donor['hospital_lng']
                );
            }

            $results[] = [
                'donor'        => $donor,
                'score'        => $score,
                'distance_km'  => $distance,
                'same_country' => ($donor['hospital_country'] ?? $donor['country']) === ($recipient['hosp_country'] ?? $recipient['country']),
            ];
        }

        return $results;
    }

    /**
     * Filter 1 — "By Compatibility Score": highest score first, ties broken
     * by shortest distance, then by name.
     */
    public static function sortByCompatibility(array $rows): array
    {
        usort($rows, static function ($a, $b) {
            $cmp = $b['score']['total'] <=> $a['score']['total'];
            if ($cmp !== 0) {
                return $cmp;
            }
            $da = $a['distance_km'] ?? PHP_FLOAT_MAX;
            $db = $b['distance_km'] ?? PHP_FLOAT_MAX;
            $cmp = $da <=> $db;
            if ($cmp !== 0) {
                return $cmp;
            }
            return strcmp($a['donor']['name'], $b['donor']['name']);
        });
        return $rows;
    }

    /**
     * Filter 2 — "By Location Proximity":
     *   1. Donors in the recipient's OWN country are shown first as a group.
     *   2. Remaining donors are grouped by their hospital's country, and the
     *      country groups themselves are ordered by how close that country's
     *      *nearest* donor hospital is to the recipient's hospital (the
     *      closest country next, then the next-closest, and so on).
     *   3. Inside every country group (including the recipient's own
     *      country), donors are ordered by compatibility score, highest
     *      first — exactly as in Filter 1, just scoped to that group.
     *
     * Returns an array of groups: [['country' => ..., 'min_distance_km' => ...|null, 'donors' => [...]], ...]
     * so the view can render a country header above each block.
     */
    public static function sortByLocation(array $rows, string $recipientCountry): array
    {
        $byCountry = [];
        foreach ($rows as $row) {
            $country = $row['donor']['hospital_country'] ?? $row['donor']['country'];
            $byCountry[$country][] = $row;
        }

        // Compute each non-home country's "closeness" as the minimum distance
        // among its donors to the recipient's hospital. Countries with no
        // distance data (missing lat/lng) sort after countries that do.
        $countryOrder = [];
        foreach ($byCountry as $country => $countryRows) {
            if ($country === $recipientCountry) {
                continue; // handled separately, always first
            }
            $distances = array_filter(array_map(static fn($r) => $r['distance_km'], $countryRows), static fn($d) => $d !== null);
            $countryOrder[$country] = $distances ? min($distances) : PHP_FLOAT_MAX;
        }
        asort($countryOrder); // ascending distance = closest country next

        $groups = [];

        if (isset($byCountry[$recipientCountry])) {
            $homeRows = self::sortByCompatibility($byCountry[$recipientCountry]);
            $groups[] = [
                'country'         => $recipientCountry,
                'is_home_country' => true,
                'min_distance_km' => 0.0,
                'donors'          => $homeRows,
            ];
        }

        foreach ($countryOrder as $country => $minDist) {
            $groups[] = [
                'country'         => $country,
                'is_home_country' => false,
                'min_distance_km' => ($minDist === PHP_FLOAT_MAX) ? null : $minDist,
                'donors'          => self::sortByCompatibility($byCountry[$country]),
            ];
        }

        return $groups;
    }

    // ─── Score persistence and recalculation ───────────────────────────────
    public static function recalculateMatch(int $matchId): bool
    {
        $match = Database::fetchOne('SELECT donor_id, recipient_id FROM compatibility_matches WHERE match_id = ?', [$matchId]);
        if (!$match) {
            return false;
        }
        $s = self::calculateCompatibility((int)$match['donor_id'], (int)$match['recipient_id']);
        Database::execute(
            "UPDATE compatibility_matches SET
                match_score=?, blood_score=?, location_score=?, crossmatch_score=?, hla_score=?, medical_score=?,
                age_score=?, bmi_score=?, creatinine_score=?, gfr_score=?, blood_pressure_score=?, hemoglobin_score=?,
                diabetes_score=?, hypertension_score=?, pra_score=?, distance_km=?, age_difference_years=?,
                data_completeness=?, is_eligible=?, score_version=?, score_detail_json=?, tissue_hla_donor=?,
                tissue_hla_recipient=?, crossmatch_result=?
             WHERE match_id=?",
            [
                $s['total'], $s['blood_score'], $s['location_score'], $s['crossmatch_score'], $s['hla_score'], $s['medical_score'],
                $s['age_score'], $s['bmi_score'], $s['creatinine_score'], $s['gfr_score'], $s['blood_pressure_score'], $s['hemoglobin_score'],
                $s['diabetes_score'], $s['hypertension_score'], $s['pra_score'], $s['distance_km'], $s['age_difference_years'],
                $s['data_completeness'], $s['is_eligible'] ? 1 : 0, $s['score_version'],
                json_encode($s, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), $s['donor_hla'], $s['recipient_hla'],
                $s['crossmatch'], $matchId,
            ]
        );
        return true;
    }

    public static function recalculateMatchesForPerson(int $personId, string $personType): int
    {
        $field = $personType === 'Donor' ? 'donor_id' : 'recipient_id';
        $rows = Database::fetchAll("SELECT match_id FROM compatibility_matches WHERE {$field} = ?", [$personId]);
        foreach ($rows as $row) {
            self::recalculateMatch((int)$row['match_id']);
        }
        return count($rows);
    }

    public static function recalculateMatchesForHospital(int $hospitalId): int
    {
        $rows = Database::fetchAll(
            'SELECT DISTINCT cm.match_id
             FROM compatibility_matches cm
             JOIN donors d ON cm.donor_id = d.donor_id
             JOIN recipients r ON cm.recipient_id = r.recipient_id
             WHERE d.hospital_id = ? OR r.hospital_id = ?',
            [$hospitalId, $hospitalId]
        );
        foreach ($rows as $row) {
            self::recalculateMatch((int)$row['match_id']);
        }
        return count($rows);
    }

    public static function recalculateAllMatches(): int
    {
        $rows = Database::fetchAll('SELECT match_id FROM compatibility_matches ORDER BY match_id');
        foreach ($rows as $row) {
            self::recalculateMatch((int)$row['match_id']);
        }
        return count($rows);
    }

    private static function latestMedicalTest(int $personId, string $personType): ?array
    {
        return Database::fetchOne(
            "SELECT * FROM medical_tests
             WHERE person_id = ? AND person_type = ? AND is_valid = 1
             ORDER BY test_date DESC, test_id DESC LIMIT 1",
            [$personId, $personType]
        );
    }

    private static function emptyCompatibility(string $message): array
    {
        return [
            'total' => 0.0, 'raw_total' => 0.0, 'blood_score' => 0.0, 'location_score' => 0.0,
            'crossmatch_score' => 0.0, 'hla_score' => 0.0, 'medical_score' => 0.0,
            'age_score' => 0.0, 'bmi_score' => 0.0, 'creatinine_score' => 0.0,
            'gfr_score' => 0.0, 'blood_pressure_score' => 0.0, 'hemoglobin_score' => 0.0,
            'diabetes_score' => 0.0, 'hypertension_score' => 0.0, 'pra_score' => 0.0,
            'distance_km' => null, 'age_difference_years' => null, 'data_completeness' => 0.0,
            'crossmatch' => 'Pending', 'donor_hla' => '', 'recipient_hla' => '', 'is_eligible' => false,
            'hard_stops' => [$message], 'warnings' => [], 'missing_fields' => [], 'medical_values' => [],
            'score_version' => 'KDMS-2.0', 'detail' => $message,
        ];
    }

    /** ABO compatibility for kidney transplantation. Rh is intentionally ignored. */
    private static function bloodCompatibilityScore(string $donorBlood, string $recipientBlood): array
    {
        $d = preg_replace('/[+-]$/', '', strtoupper(trim($donorBlood))) ?: '';
        $r = preg_replace('/[+-]$/', '', strtoupper(trim($recipientBlood))) ?: '';
        $compatible = match ($d) {
            'O' => in_array($r, ['O', 'A', 'B', 'AB'], true),
            'A' => in_array($r, ['A', 'AB'], true),
            'B' => in_array($r, ['B', 'AB'], true),
            'AB' => $r === 'AB',
            default => false,
        };
        if (!$compatible) {
            return ['score' => 0.0, 'compatible' => false];
        }
        $score = $d === $r ? 15.0 : ($d === 'O' ? 14.0 : 13.5);
        return ['score' => self::round10($score), 'compatible' => true];
    }

    private static function locationCompatibility(array $donor, array $recipient): array
    {
        $distance = null;
        $method = 'fallback';
        if (self::number($donor['hospital_lat'] ?? null) !== null
            && self::number($donor['hospital_lng'] ?? null) !== null
            && self::number($recipient['hospital_lat'] ?? null) !== null
            && self::number($recipient['hospital_lng'] ?? null) !== null) {
            $distance = self::round10(self::haversineKm(
                (float)$donor['hospital_lat'], (float)$donor['hospital_lng'],
                (float)$recipient['hospital_lat'], (float)$recipient['hospital_lng']
            ));
            $score = self::scoreFromAnchors($distance, [
                [0.0, 20.0], [20.0, 20.0], [50.0, 15.0], [100.0, 10.0],
                [250.0, 5.0], [500.0, 2.0], [1000.0, 0.0],
            ]);
            $method = 'hospital_coordinates_haversine';
        } else {
            $sameCountry = strcasecmp((string)$donor['country'], (string)$recipient['country']) === 0;
            $sameCity = $sameCountry && strcasecmp((string)$donor['city'], (string)$recipient['city']) === 0;
            $score = $sameCity ? 20.0 : ($sameCountry ? 5.0 : 0.0);
            if ($sameCity) {
                $distance = 0.0;
            }
        }
        return ['score' => self::round10($score), 'distance_km' => $distance, 'method' => $method];
    }

    private static function hlaCompatibilityScore(string $donorHla, string $recipientHla): array
    {
        $d = self::parseHla($donorHla);
        $r = self::parseHla($recipientHla);
        if (!$d || !$r) {
            return ['score' => 0.0, 'similarity' => 0.0, 'matches' => 0, 'union_count' => count(array_unique(array_merge($d, $r)))];
        }
        $matches = count(array_intersect($d, $r));
        $similarity = (2.0 * $matches) / (count($d) + count($r));
        return [
            'score' => self::round10(15.0 * $similarity),
            'similarity' => self::round10($similarity),
            'matches' => $matches,
            'union_count' => count(array_unique(array_merge($d, $r))),
        ];
    }

    private static function parseHla(string $value): array
    {
        $value = strtoupper(trim($value));
        if ($value === '') {
            return [];
        }
        $value = str_replace(['HLA-', 'HLA '], '', $value);
        $tokens = preg_split('/[\s,;\/|]+/', $value) ?: [];
        $tokens = array_values(array_unique(array_filter(array_map(
            static fn(string $token): string => preg_replace('/[^A-Z0-9:*]/', '', trim($token)) ?? '',
            $tokens
        ))));
        sort($tokens);
        return $tokens;
    }

    private static function medicalCompatibilityScore(array $donor, array $recipient, ?array $dt, ?array $rt): array
    {
        $missing = [];
        $warnings = [];
        $values = [];

        $donorAge = self::ageYears($donor['dob'] ?? null);
        $recipientAge = self::ageYears($recipient['dob'] ?? null);
        $ageDiff = ($donorAge !== null && $recipientAge !== null) ? abs($donorAge - $recipientAge) : null;
        if ($donorAge === null) $missing[] = 'donor.dob';
        if ($recipientAge === null) $missing[] = 'recipient.dob';
        $ageScore = 0.0;
        if ($donorAge !== null && $recipientAge !== null) {
            $donorAgeFactor = self::scoreFromAnchors($donorAge, [
                [18.0, 0.80], [25.0, 1.00], [45.0, 1.00], [55.0, 0.85],
                [65.0, 0.60], [75.0, 0.25], [90.0, 0.00],
            ]);
            $differenceFactor = exp(-pow($ageDiff / 35.0, 1.25));
            $ageScore = 3.0 * $donorAgeFactor * (0.65 + 0.35 * $differenceFactor);
        }

        $donorBmi = self::testBmi($dt);
        $recipientBmi = self::testBmi($rt);
        if ($donorBmi === null) $missing[] = 'donor.bmi';
        if ($recipientBmi === null) $missing[] = 'recipient.bmi';
        $bmiScore = 0.0;
        if ($donorBmi !== null) {
            $bmiScore += 2.25 * self::scoreFromAnchors($donorBmi, [
                [14.0, 0.0], [18.5, 0.65], [20.0, 1.0], [25.0, 1.0],
                [30.0, 0.90], [35.0, 0.45], [40.0, 0.0],
            ]);
            if ($donorBmi >= 35.0) $warnings[] = 'Donor BMI is 35 or higher and requires individualized clinical assessment.';
        }
        if ($recipientBmi !== null) {
            $bmiScore += 0.75 * self::scoreFromAnchors($recipientBmi, [
                [14.0, 0.0], [18.5, 0.70], [20.0, 1.0], [30.0, 1.0],
                [35.0, 0.80], [40.0, 0.45], [50.0, 0.0],
            ]);
        }

        $donorCreat = self::number($dt['creatinine_level'] ?? null);
        $recipientCreat = self::number($rt['creatinine_level'] ?? null);
        $donorGfr = self::number($dt['gfr_numeric'] ?? null);
        $recipientGfr = self::number($rt['gfr_numeric'] ?? null);
        if ($donorCreat === null) $missing[] = 'donor.creatinine';
        if ($recipientCreat === null) $missing[] = 'recipient.creatinine';
        if ($donorGfr === null) $missing[] = 'donor.gfr';
        if ($recipientGfr === null) $missing[] = 'recipient.gfr';

        $creatinineScore = 0.0;
        if ($donorCreat !== null) {
            $upper = match ($donor['gender'] ?? 'Other') {
                'Male' => 1.30, 'Female' => 1.10, default => 1.20,
            };
            $ratio = $donorCreat / $upper;
            $creatinineScore += 3.2 * self::scoreFromAnchors($ratio, [
                [0.30, 0.80], [0.55, 1.00], [1.00, 1.00], [1.20, 0.75], [1.50, 0.35], [2.00, 0.00],
            ]);
        }
        if ($recipientCreat !== null && $recipientGfr !== null) {
            $creatSeverity = self::clamp(($recipientCreat - 1.0) / 7.0, 0.0, 1.0);
            $gfrSeverity = self::clamp((60.0 - $recipientGfr) / 60.0, 0.0, 1.0);
            $creatinineScore += 0.8 * (1.0 - abs($creatSeverity - $gfrSeverity));
        }

        $gfrScore = 0.0;
        if ($donorGfr !== null) {
            $gfrScore += 4.0 * self::scoreFromAnchors($donorGfr, [
                [0.0, 0.0], [60.0, 0.0], [75.0, 0.55], [90.0, 1.0], [120.0, 1.0], [150.0, 0.90],
            ]);
            if ($donorGfr >= 60.0 && $donorGfr < 90.0) $warnings[] = 'Donor GFR from 60 to 89 requires individualized risk assessment.';
        }
        if ($recipientGfr !== null) {
            $gfrScore += 1.0 * self::scoreFromAnchors($recipientGfr, [
                [0.0, 1.0], [15.0, 1.0], [30.0, 0.75], [45.0, 0.45], [60.0, 0.20], [90.0, 0.0],
            ]);
        }

        $donorSys = self::number($dt['systolic_bp'] ?? null);
        $donorDia = self::number($dt['diastolic_bp'] ?? null);
        $recipientSys = self::number($rt['systolic_bp'] ?? null);
        $recipientDia = self::number($rt['diastolic_bp'] ?? null);
        if ($donorSys === null || $donorDia === null) $missing[] = 'donor.blood_pressure';
        if ($recipientSys === null || $recipientDia === null) $missing[] = 'recipient.blood_pressure';
        $bpScore = 0.0;
        if ($donorSys !== null && $donorDia !== null) {
            $bpScore += 2.4 * self::bloodPressureFactor($donorSys, $donorDia);
            if ($donorSys > 140.0 || $donorDia > 90.0) $warnings[] = 'Donor blood pressure exceeds 140/90 mmHg.';
        }
        if ($recipientSys !== null && $recipientDia !== null) {
            $bpScore += 0.6 * self::bloodPressureFactor($recipientSys, $recipientDia);
        }

        $donorHb = self::number($dt['hemoglobin'] ?? null);
        $recipientHb = self::number($rt['hemoglobin'] ?? null);
        if ($donorHb === null) $missing[] = 'donor.hemoglobin';
        if ($recipientHb === null) $missing[] = 'recipient.hemoglobin';
        $hemoglobinScore = 0.0;
        if ($donorHb !== null) $hemoglobinScore += 2.4 * self::hemoglobinFactor($donorHb, (string)($donor['gender'] ?? 'Other'));
        if ($recipientHb !== null) $hemoglobinScore += 0.6 * self::hemoglobinFactor($recipientHb, (string)($recipient['gender'] ?? 'Other'));

        $donorDiabetes = self::binary($dt['diabetes'] ?? null);
        $recipientDiabetes = self::binary($rt['diabetes'] ?? null);
        if ($donorDiabetes === null) $missing[] = 'donor.diabetes';
        if ($recipientDiabetes === null) $missing[] = 'recipient.diabetes';
        $diabetesScore = ($donorDiabetes === null ? 0.0 : ($donorDiabetes ? 0.20 : 1.60))
            + ($recipientDiabetes === null ? 0.0 : ($recipientDiabetes ? 0.25 : 0.40));
        if ($donorDiabetes === true) $warnings[] = 'Donor diabetes requires individualized risk assessment.';

        $donorHypertension = self::binary($dt['hypertension'] ?? null);
        $recipientHypertension = self::binary($rt['hypertension'] ?? null);
        if ($donorHypertension === null) $missing[] = 'donor.hypertension';
        if ($recipientHypertension === null) $missing[] = 'recipient.hypertension';
        $hypertensionScore = ($donorHypertension === null ? 0.0 : ($donorHypertension ? 0.40 : 1.60))
            + ($recipientHypertension === null ? 0.0 : ($recipientHypertension ? 0.20 : 0.40));
        if ($donorHypertension === true) $warnings[] = 'Donor hypertension requires individualized risk assessment.';

        $pra = self::number($rt['pra_percentage'] ?? null);
        if ($pra === null) $missing[] = 'recipient.pra_percentage';
        $praScore = $pra === null ? 0.0 : 5.0 * pow(1.0 - self::clamp($pra / 100.0, 0.0, 1.0), 1.25);
        if ($pra !== null && $pra >= 80.0) $warnings[] = 'Recipient PRA is 80% or higher, indicating high sensitization.';

        $components = [
            'age' => self::round10($ageScore),
            'bmi' => self::round10($bmiScore),
            'creatinine' => self::round10($creatinineScore),
            'gfr' => self::round10($gfrScore),
            'blood_pressure' => self::round10($bpScore),
            'hemoglobin' => self::round10($hemoglobinScore),
            'diabetes' => self::round10($diabetesScore),
            'hypertension' => self::round10($hypertensionScore),
            'pra' => self::round10($praScore),
        ];
        $score = array_sum($components);

        $required = 17.0;
        $present = $required - count(array_unique($missing));
        $completeness = self::clamp($present / $required * 100.0, 0.0, 100.0);

        $values = [
            'donor_bmi' => $donorBmi, 'recipient_bmi' => $recipientBmi,
            'donor_creatinine' => $donorCreat, 'recipient_creatinine' => $recipientCreat,
            'donor_gfr' => $donorGfr, 'recipient_gfr' => $recipientGfr,
            'donor_systolic_bp' => $donorSys, 'donor_diastolic_bp' => $donorDia,
            'recipient_systolic_bp' => $recipientSys, 'recipient_diastolic_bp' => $recipientDia,
            'donor_hemoglobin' => $donorHb, 'recipient_hemoglobin' => $recipientHb,
            'donor_diabetes' => $donorDiabetes, 'recipient_diabetes' => $recipientDiabetes,
            'donor_hypertension' => $donorHypertension, 'recipient_hypertension' => $recipientHypertension,
            'recipient_pra_percentage' => $pra,
        ];

        return [
            'score' => self::round10(min(30.0, $score)),
            'components' => $components,
            'age_difference_years' => $ageDiff === null ? null : self::round10($ageDiff),
            'donor_age_years' => $donorAge === null ? null : self::round10($donorAge),
            'recipient_age_years' => $recipientAge === null ? null : self::round10($recipientAge),
            'completeness' => self::round10($completeness),
            'missing_fields' => array_values(array_unique($missing)),
            'warnings' => $warnings,
            'values' => $values,
        ];
    }

    private static function testBmi(?array $test): ?float
    {
        if (!$test) return null;
        $bmi = self::number($test['bmi'] ?? null);
        if ($bmi !== null) return self::round10($bmi);
        $height = self::number($test['height_cm'] ?? null);
        $weight = self::number($test['weight_kg'] ?? null);
        if ($height === null || $weight === null || $height <= 0.0) return null;
        return self::round10($weight / (($height / 100.0) ** 2));
    }

    private static function bloodPressureFactor(float $systolic, float $diastolic): float
    {
        $s = self::scoreFromAnchors($systolic, [
            [70.0, 0.0], [90.0, 0.80], [100.0, 1.0], [120.0, 1.0], [130.0, 0.90],
            [140.0, 0.65], [160.0, 0.25], [180.0, 0.0],
        ]);
        $d = self::scoreFromAnchors($diastolic, [
            [40.0, 0.0], [50.0, 0.80], [60.0, 1.0], [80.0, 1.0], [85.0, 0.90],
            [90.0, 0.65], [100.0, 0.25], [110.0, 0.0],
        ]);
        return self::round10(min($s, $d));
    }

    private static function hemoglobinFactor(float $value, string $gender): float
    {
        [$low, $high] = match ($gender) {
            'Male' => [13.8, 17.2],
            'Female' => [12.1, 15.1],
            default => [12.5, 16.5],
        };
        return self::scoreFromAnchors($value, [
            [$low - 4.0, 0.0], [$low - 2.0, 0.40], [$low, 1.0], [$high, 1.0],
            [$high + 2.0, 0.50], [$high + 4.0, 0.0],
        ]);
    }

    private static function ageYears(mixed $dob): ?float
    {
        if (!$dob) return null;
        try {
            $birth = new DateTimeImmutable((string)$dob);
            $today = new DateTimeImmutable('today');
            if ($birth > $today) return null;
            return self::round10(((float)$today->format('U') - (float)$birth->format('U')) / 31556952.0);
        } catch (Throwable) {
            return null;
        }
    }

    private static function scoreFromAnchors(float $value, array $anchors): float
    {
        usort($anchors, static fn(array $a, array $b): int => $a[0] <=> $b[0]);
        if ($value <= $anchors[0][0]) return (float)$anchors[0][1];
        $last = $anchors[count($anchors) - 1];
        if ($value >= $last[0]) return (float)$last[1];
        for ($i = 1, $n = count($anchors); $i < $n; $i++) {
            [$x2, $y2] = $anchors[$i];
            [$x1, $y1] = $anchors[$i - 1];
            if ($value <= $x2) {
                $ratio = ($value - $x1) / ($x2 - $x1);
                return self::round10($y1 + ($y2 - $y1) * $ratio);
            }
        }
        return (float)$last[1];
    }

    private static function number(mixed $value): ?float
    {
        if ($value === null || $value === '' || !is_numeric($value)) return null;
        return (float)$value;
    }

    private static function binary(mixed $value): ?bool
    {
        if ($value === null || $value === '') return null;
        if ($value === true || $value === 1 || $value === '1') return true;
        if ($value === false || $value === 0 || $value === '0') return false;
        return null;
    }

    private static function clamp(float $value, float $min, float $max): float
    {
        return max($min, min($max, $value));
    }

    private static function round10(float $value): float
    {
        return round($value, 10);
    }

    // ─── internal helpers ─────────────────────────────────────────────────────

    private static function notifyDoctorsFor(int $donorId, string $title, string $message, string $type): void
    {
        $donor = Database::fetchOne('SELECT hospital_id FROM donors WHERE donor_id = ?', [$donorId]);
        $doctorUserIds = Database::fetchAll(
            "SELECT u.user_id FROM users u JOIN roles r ON u.role_id = r.role_id
             WHERE r.role_name IN ('admin','superadmin','doctor') AND u.is_active = 1"
        );
        foreach ($doctorUserIds as $u) {
            Database::execute(
                'INSERT INTO notifications (user_id, title, message, type) VALUES (?, ?, ?, ?)',
                [$u['user_id'], $title, $message, $type]
            );
        }
    }

    private static function audit(int $userId, string $action, string $table, int $recordId, ?array $old, ?array $new, string $notes): void
    {
        Database::execute(
            'INSERT INTO audit_log (user_id, action, table_name, record_id, old_values, new_values, notes) VALUES (?, ?, ?, ?, ?, ?, ?)',
            [$userId, $action, $table, $recordId, $old ? json_encode($old) : null, $new ? json_encode($new) : null, $notes]
        );
    }
}
