<?php
/**
 * KDMS Pro — index.php
 * Entry point — redirect to dashboard or login
 */
declare(strict_types=1);
define('KDMS_ROOT', __DIR__);
require_once KDMS_ROOT . '/includes/auth.php';

if (is_logged_in()) {
    header('Location: ' . base_url('/pages/dashboard.php'));
} else {
    header('Location: ' . base_url('/login.php'));
}
exit;
