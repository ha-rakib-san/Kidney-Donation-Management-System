<?php
/**
 * KDMS Pro — logout.php
 */
declare(strict_types=1);
define('KDMS_ROOT', __DIR__);
require_once KDMS_ROOT . '/includes/auth.php';

if (is_logged_in()) {
    log_action('LOGOUT', 'users', (int)current_user()['user_id'], null, null, 'User logged out');
}

// Clear remember cookie
if (!empty($_COOKIE['kdms_remember'])) {
    $parts = explode(':', $_COOKIE['kdms_remember'], 2);
    if (count($parts) === 2) {
        Database::execute("UPDATE users SET remember_token = NULL WHERE user_id = ?", [(int)$parts[0]]);
    }
    setcookie('kdms_remember', '', ['expires' => time() - 3600, 'path' => '/kdms', 'httponly' => true]);
}

session_unset();
session_destroy();
session_start();
$_SESSION['flash'] = ['type' => 'success', 'msg' => 'You have been logged out successfully.'];
header('Location: ' . base_url('/login.php'));
exit;
