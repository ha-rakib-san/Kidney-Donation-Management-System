-- ╔══════════════════════════════════════════════════════════════════════╗
-- ║  KDMS PRO — 03_triggers.sql                                         ║
-- ║  Database Triggers — SQLite 3.35+                                    ║
-- ╚══════════════════════════════════════════════════════════════════════╝
--
-- SQLite triggers cannot DECLARE variables or use cursors/loops, so every
-- trigger below is written as a sequence of plain SQL statements using
-- correlated sub-selects in place of the MySQL DECLARE/SET pattern.
-- Cursor-based logic (auto-matching, waitlist re-prioritization, monthly
-- reports) has moved to lib/Procedures.php — see that file for the PHP
-- equivalents of sp_auto_match_donors_for_recipient(), sp_prioritize_waitlist()
-- and sp_generate_monthly_report().

PRAGMA foreign_keys = ON;

-- ─── TRIGGER 1: Notify reviewers after a scored match is inserted ────────────
-- The precision scoring engine lives in lib/Procedures.php because SQLite
-- triggers cannot reliably implement the continuous clinical formulas.
DROP TRIGGER IF EXISTS trg_match_after_insert;
CREATE TRIGGER trg_match_after_insert
AFTER INSERT ON compatibility_matches
FOR EACH ROW
BEGIN
  INSERT INTO notifications (user_id, title, message, type, link_url)
  SELECT u.user_id,
         'New compatibility match created',
         'Match #' || NEW.match_id || ' — Score: ' || printf('%.10f', NEW.match_score) ||
           '%. Review pending.',
         CASE WHEN NEW.is_eligible = 1 AND NEW.match_score >= 70
              THEN 'match' ELSE 'info' END,
         '/kdms/pages/matches/index.php'
  FROM users u
  JOIN roles r ON u.role_id = r.role_id
  WHERE r.role_name IN ('admin','superadmin','doctor') AND u.is_active = 1;
END;

-- ─── TRIGGER 2: Transplant marked Successful ─────────────────────────────────
DROP TRIGGER IF EXISTS trg_transplant_success;
CREATE TRIGGER trg_transplant_success
AFTER UPDATE ON transplants
FOR EACH ROW
WHEN NEW.result = 'Successful' AND OLD.result != 'Successful'
BEGIN
  UPDATE donors SET status = 'Transplanted'
  WHERE donor_id = (SELECT donor_id FROM compatibility_matches WHERE match_id = NEW.match_id);

  UPDATE recipients SET wait_status = 'Transplanted'
  WHERE recipient_id = (SELECT recipient_id FROM compatibility_matches WHERE match_id = NEW.match_id);

  UPDATE doctors SET transplants_done = transplants_done + 1
  WHERE doctor_id = NEW.doctor_id;

  DELETE FROM waitlist_queue
  WHERE recipient_id = (SELECT recipient_id FROM compatibility_matches WHERE match_id = NEW.match_id);

  INSERT INTO audit_log (action, table_name, record_id, old_values, new_values, notes)
  VALUES ('UPDATE', 'transplants', NEW.transplant_id,
          json_object('result', OLD.result),
          json_object('result', 'Successful'),
          'Auto-trigger: donor + recipient status updated to Transplanted');
END;

-- ─── TRIGGER 3: Transplant marked Failed ─────────────────────────────────────
DROP TRIGGER IF EXISTS trg_transplant_failed;
CREATE TRIGGER trg_transplant_failed
AFTER UPDATE ON transplants
FOR EACH ROW
WHEN NEW.result = 'Failed' AND OLD.result != 'Failed'
BEGIN
  UPDATE recipients SET wait_status = 'Waiting'
  WHERE recipient_id = (SELECT recipient_id FROM compatibility_matches WHERE match_id = NEW.match_id);

  INSERT INTO waitlist_queue (recipient_id, queue_position, priority_score, wait_since_date)
  VALUES ((SELECT recipient_id FROM compatibility_matches WHERE match_id = NEW.match_id), 9999, 50.00, DATE('now'))
  ON CONFLICT(recipient_id) DO UPDATE SET last_recalculated = CURRENT_TIMESTAMP;

  INSERT INTO notifications (user_id, title, message, type, link_url)
  SELECT u.user_id,
         'Transplant #' || NEW.transplant_id || ' — Outcome: Failed',
         'Organ rejection detected. Patient re-queued on waitlist. Immediate review required.',
         'urgent',
         '/kdms/pages/transplants/index.php'
  FROM users u JOIN roles r ON u.role_id = r.role_id
  WHERE r.role_name IN ('admin','superadmin') AND u.is_active = 1;
END;

-- ─── TRIGGER 4a: Validate donor age >= 18 on insert ──────────────────────────
DROP TRIGGER IF EXISTS trg_donor_before_insert_min_age;
CREATE TRIGGER trg_donor_before_insert_min_age
BEFORE INSERT ON donors
FOR EACH ROW
WHEN NEW.dob IS NOT NULL AND (julianday('now') - julianday(NEW.dob)) / 365.25 < 18
BEGIN
  SELECT RAISE(ABORT, 'Donor must be at least 18 years old');
END;

-- ─── TRIGGER 4b: Validate donor age <= 65 on insert ──────────────────────────
DROP TRIGGER IF EXISTS trg_donor_before_insert_max_age;
CREATE TRIGGER trg_donor_before_insert_max_age
BEFORE INSERT ON donors
FOR EACH ROW
WHEN NEW.dob IS NOT NULL AND (julianday('now') - julianday(NEW.dob)) / 365.25 > 65
BEGIN
  SELECT RAISE(ABORT, 'Donor age cannot exceed 65 years');
END;

-- ─── TRIGGER 5a: Prevent matching a non-Available donor ──────────────────────
DROP TRIGGER IF EXISTS trg_match_before_insert_donor;
CREATE TRIGGER trg_match_before_insert_donor
BEFORE INSERT ON compatibility_matches
FOR EACH ROW
WHEN (SELECT status FROM donors WHERE donor_id = NEW.donor_id) != 'Available'
BEGIN
  SELECT RAISE(ABORT, 'Cannot match: donor is not in Available status');
END;

-- ─── TRIGGER 5b: Prevent matching a recipient who is not Waiting/Matched ─────
DROP TRIGGER IF EXISTS trg_match_before_insert_recipient;
CREATE TRIGGER trg_match_before_insert_recipient
BEFORE INSERT ON compatibility_matches
FOR EACH ROW
WHEN (SELECT wait_status FROM recipients WHERE recipient_id = NEW.recipient_id) NOT IN ('Waiting','Matched')
BEGIN
  SELECT RAISE(ABORT, 'Cannot match: recipient is not in Waiting status');
END;

-- ─── TRIGGER 6: Critical follow-up alert ──────────────────────────────────────
DROP TRIGGER IF EXISTS trg_followup_critical;
CREATE TRIGGER trg_followup_critical
AFTER INSERT ON follow_ups
FOR EACH ROW
WHEN NEW.health_status = 'Critical' OR NEW.rejection_episode = 1
BEGIN
  INSERT INTO notifications (user_id, title, message, type, link_url)
  SELECT u.user_id,
         'URGENT: Critical Follow-Up Status',
         'Follow-up #' || NEW.followup_id || ' for transplant #' || NEW.transplant_id ||
         ' marked CRITICAL. Rejection episode: ' ||
         (CASE WHEN NEW.rejection_episode = 1 THEN 'YES' ELSE 'No' END) ||
         '. Immediate attention required.',
         'urgent',
         '/kdms/pages/followups/index.php'
  FROM users u JOIN roles r ON u.role_id = r.role_id
  WHERE r.role_name IN ('admin','superadmin','doctor') AND u.is_active = 1;
END;

-- ─── TRIGGER 7: Audit user creation ──────────────────────────────────────────
DROP TRIGGER IF EXISTS trg_user_after_insert;
CREATE TRIGGER trg_user_after_insert
AFTER INSERT ON users
FOR EACH ROW
BEGIN
  INSERT INTO audit_log (action, table_name, record_id, new_values, notes)
  VALUES ('CREATE', 'users', NEW.user_id,
          json_object('username', NEW.username, 'role_id', NEW.role_id, 'email', NEW.email),
          'New user account created');
END;

-- ─── TRIGGER 8: Prevent deletion of donor with active matches ────────────────
DROP TRIGGER IF EXISTS trg_donor_before_delete;
CREATE TRIGGER trg_donor_before_delete
BEFORE DELETE ON donors
FOR EACH ROW
WHEN EXISTS (
  SELECT 1 FROM compatibility_matches
  WHERE donor_id = OLD.donor_id AND review_result IN ('Pending','Approved')
)
BEGIN
  SELECT RAISE(ABORT, 'Cannot delete donor with active or approved compatibility matches');
END;

-- ─── NOTE: ON UPDATE CURRENT_TIMESTAMP emulation ─────────────────────────────
-- SQLite has no native "ON UPDATE CURRENT_TIMESTAMP" column behaviour, and a
-- same-table AFTER-UPDATE trigger that issues a second UPDATE on that same
-- table is fragile to reason about (self-referential trigger chains).
-- Instead, every UPDATE statement issued by the application explicitly sets
-- `updated_at = CURRENT_TIMESTAMP` itself (see lib/Procedures.php and the
-- edit.php pages for users/hospitals/doctors/donors/recipients/transplants).
