# 🏥 KDMS Pro — Setup Guide

**Kidney Donation Management System — Global Hybrid Edition**
69 Hospitals · 30 Countries · PHP 8.2 · **SQLite** · XAMPP

---

## 1. System Requirements

| Component | Minimum Version | Notes |
|---|---|---|
| XAMPP | 8.2.x | Apache + PHP. **You do not need to start MySQL at all.** |
| PHP | 8.2+ | `pdo_sqlite` extension enabled (bundled by default in XAMPP and virtually every PHP 8.2 install) |
| Database | None to install | SQLite is a single file, created automatically — no server, no service, no root password |
| Browser | Chrome 100+, Firefox 100+, Edge 100+ | WebGL support required for the Three.js DNA helix |
| RAM | 2 GB+ | SQLite is far lighter than MySQL |

> ✅ **Why this is simpler than the old MySQL setup:** there's no `my.ini`, no event scheduler to enable, no phpMyAdmin import. The whole database is one file at `storage/kdms.sqlite` that the app creates and seeds itself the first time it's needed.

---

## 2. Quick Start (2 Minutes)

1. **Install XAMPP** from [apachefriends.org](https://www.apachefriends.org/) if you don't already have it.
2. **Copy the project folder** into your XAMPP web root:
   ```
   Windows:  C:\xampp\htdocs\kdms\
   macOS:    /Applications/XAMPP/htdocs/kdms/
   Linux:    /opt/lampp/htdocs/kdms/
   ```
3. **Start Apache only** from the XAMPP Control Panel (MySQL is not used).
4. **Make `storage/` writable** by the web server (it already exists in the zip; on Linux/macOS you may need `chmod -R 775 storage`).
5. **Visit** `http://localhost/kdms/` — the database auto-creates and seeds itself on this very first request (you'll briefly see it building before redirecting to the login page). If you'd rather watch it happen with a progress report, visit `http://localhost/kdms/install.php` instead.
6. **Log in** with any demo account from Section 4.

That's it — no Section 3 "import via phpMyAdmin" step exists anymore, because there's no phpMyAdmin/MySQL involved.

---

## 3. Manual / Explicit Install (Optional)

If you ever need to start over (e.g. you want fresh seed data), either:

- Visit `http://localhost/kdms/install.php?reset=1` (with a confirmation prompt), **or**
- Delete `storage/kdms.sqlite` (and any `-wal`/`-shm`/`-journal` files next to it) and reload any page — `config/database.php` rebuilds it automatically.

Under the hood, both paths run the same six SQL files in this order (see `config/database.php`'s `DB_BOOTSTRAP_FILES` constant for why this exact order matters — seed data loads *before* the validation triggers, since it represents an already-resolved historical snapshot):

| Order | File | What it does |
|---|---|---|
| 1 | `01_schema.sql` | Creates all 16 application tables, indexes, and CHECK constraints |
| 2 | `02_procedures.sql` | No-op — documents where the 8 MySQL stored procedures went (`lib/Procedures.php`) |
| 3 | `04_views.sql` | Creates 10 views |
| 4 | `06_seed.sql` | Inserts all demo data — 69 hospitals across 30 countries, doctors, donors, recipients, tests, matches, transplants, follow-ups, notifications, audit log |
| 5 | `03_triggers.sql` | Creates 10 triggers (runs *after* seeding so historical seed rows don't trip the live-data validation triggers) |
| 6 | `05_events.sql` | No-op — documents where the 4 MySQL scheduled events went (`includes/scheduler.php` + `cron/maintenance.php`) |

If you ever want to run these by hand against a fresh file (e.g. for inspection in a SQLite browser like DB Browser for SQLite or the `sqlite3` CLI):

```bash
rm -f storage/kdms.sqlite
sqlite3 storage/kdms.sqlite < sql/01_schema.sql
sqlite3 storage/kdms.sqlite < sql/02_procedures.sql
sqlite3 storage/kdms.sqlite < sql/04_views.sql
sqlite3 storage/kdms.sqlite < sql/06_seed.sql
sqlite3 storage/kdms.sqlite < sql/03_triggers.sql
sqlite3 storage/kdms.sqlite < sql/05_events.sql
```

---

## 4. Default Login Credentials

All seed accounts share the password **`password`** for demo/grading convenience.

| Role | Username | Password | Linked Record |
|---|---|---|---|
| Superadmin | `superadmin` | `password` | — (full system access) |
| Doctor | `dr_aminul` | `password` | Dr. Aminul Islam (Doctor #1, Dhaka) |
| Donor | `donor_rakib` | `password` | Md. Rakibul Hasan (Donor #1, Dhaka) |
| Recipient | `recipient_kalam` | `password` | Md. Abul Kalam (Recipient #1, Dhaka) |
| Auditor | `auditor_user` | `password` | — (read-only audit access) |

> 🔒 **Production note:** change all default passwords immediately in a real deployment.

---

## 5. The Two Donor-List Filters (New in the Global Hybrid Edition)

1. Log in as `superadmin` or `dr_aminul`.
2. Go to **Donors**.
3. In the **"Match Donors for a Recipient"** panel, pick any Waiting recipient.
4. Toggle between:
   - **Compatibility Score** — every Available donor worldwide, highest score first.
   - **Location Proximity** — donors grouped by country, recipient's own country first, then the next-closest countries by hospital-to-hospital distance; scores rank donors within each group.

---

## 6. Scheduled Jobs (No Event Scheduler Needed)

The original 4 MySQL scheduled events now run as plain PHP, two ways:

- **Automatic (default):** `includes/scheduler.php`'s `Scheduler::runDueJobs()` runs near the top of `pages/dashboard.php`. Every time anyone loads the dashboard, any job whose interval has elapsed (1 hour / 1 day / 1 week / 30 days) runs once and records its own last-run timestamp in `system_settings`. Nothing to configure.
- **Real cron (optional):** if you want exact scheduling instead of "next time someone loads the dashboard," point cron/Task Scheduler at `cron/maintenance.php`:
  ```bash
  0  3  *  *  *   php /path/to/htdocs/kdms/cron/maintenance.php daily
  0  4  *  *  0   php /path/to/htdocs/kdms/cron/maintenance.php weekly
  0  5  1  *  *   php /path/to/htdocs/kdms/cron/maintenance.php monthly
  0  *  *  *  *   php /path/to/htdocs/kdms/cron/maintenance.php hourly
  ```

---

## 7. Troubleshooting

| Problem | Likely Cause | Solution |
|---|---|---|
| **"Database connection failed"** | `storage/` directory isn't writable | `chmod -R 775 storage` (Linux/macOS) or check folder permissions (Windows) |
| **Blank white page** | PHP error with display_errors off | Check `xampp/php/logs/php_error_log` or Apache error log |
| **"no such table"** | Database file exists but bootstrap didn't finish (e.g. process killed mid-import) | Delete `storage/kdms.sqlite*` and reload any page, or visit `install.php?reset=1` |
| **Login always fails** | Wrong password | Default seed password is `password` for every demo account (see Section 4) |
| **Three.js DNA helix doesn't render** | CDN blocked or WebGL disabled | Check internet connection (Three.js/GSAP/Chart.js load from CDN) and enable hardware acceleration in your browser |
| **Charts don't show data** | `api/stats.php` returns 401 | Make sure you're logged in; check the browser console for fetch errors |
| **"Account locked"** | 5 failed login attempts triggered the brute-force lockout | Wait 15 minutes, or reset via `sqlite3 storage/kdms.sqlite "UPDATE users SET failed_logins=0, locked_until=NULL WHERE username='your_username';"` |
| **CSRF token errors on form submit** | Session expired or `_csrf_token` field missing | Refresh and try again — sessions expire after 30 minutes of inactivity |
| **"database is locked"** | Two requests writing to SQLite at the exact same moment | Rare on localhost; the app sets `PRAGMA busy_timeout` to retry automatically — just resubmit if it happens |
| **Apache won't start (port 80 in use)** | Another service using port 80 | Change Apache's port in XAMPP config, or stop the conflicting service |

---

## 8. Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                     BROWSER (Client)                            │
│  HTML5 + CSS3 + Vanilla JS ES6+ + Three.js + GSAP + Chart.js    │
└───────────────────────────┬───────────────────────────────────────┘
                            │ HTTP/HTTPS
┌───────────────────────────▼───────────────────────────────────────┐
│                  APACHE + PHP 8.2 (XAMPP)                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ login.php     │  │ pages/*.php   │  │ api/*.php (AJAX)      │  │
│  │ register.php  │  │ (MVC views)   │  │ JSON responses        │  │
│  └──────┬────────┘  └──────┬───────┘  └──────────┬───────────┘  │
│         │                  │                      │              │
│  ┌──────▼──────────────────▼──────────────────────▼───────────┐  │
│  │       includes/auth.php (RBAC + CSRF + Sessions)             │  │
│  │       includes/scheduler.php (lazy job runner)                │  │
│  │       lib/Procedures.php (compat scoring, matching,           │  │
│  │         waitlist priority, donor-list filters)                 │  │
│  └──────────────────────────┬───────────────────────────────────┘  │
│  ┌──────────────────────────▼───────────────────────────────────┐  │
│  │         config/database.php (PDO SQLite Singleton)            │  │
│  └──────────────────────────┬───────────────────────────────────┘  │
└─────────────────────────────┼───────────────────────────────────────┘
                              │ PDO sqlite
┌─────────────────────────────▼───────────────────────────────────────┐
│             storage/kdms.sqlite — single file database              │
│  ┌─────────────┐ ┌──────────────────┐ ┌────────┐ ┌────────┐        │
│  │ 16 Tables    │ │ 10 Triggers      │ │10 Views│ │No procs│        │
│  │ (69 hospitals│ │ (cascades, audit, │ │        │ │/events │        │
│  │  30 countries│ │  age validation)  │ │        │ │(in PHP)│        │
│  └─────────────┘ └──────────────────┘ └────────┘ └────────┘        │
└───────────────────────────────────────────────────────────────────┘
```

---

## 9. Feature Index — What Each Role Can Do

| Role | Dashboard | Manage Hospitals/Doctors | Manage Donors/Recipients | Create Matches | Approve Matches | Manage Transplants | View Reports | Audit Log | User Mgmt |
|---|---|---|---|---|---|---|---|---|---|
| **Superadmin** | Full | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Admin** | Full | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Doctor** | Full | ❌ View only | ✅ | ✅ | ❌ | ✅ | Own dept | ❌ | ❌ |
| **Donor** | Own only | ❌ | Own profile (read-only) | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Recipient** | Own only | ❌ | Own profile + waitlist (read-only) | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Auditor** | Full (read-only) | ❌ View only | ❌ View only | ❌ | ❌ | ❌ View only | ✅ | ✅ | ❌ |

---

## 10. Next Steps After Setup

1. ✅ Log in as `superadmin` and explore the Dashboard — note the country count in the KPI grid.
2. ✅ Go to **Donors → Match Donors for a Recipient** and try both new filters (Section 5).
3. ✅ Visit **Matches → Create Match** to see the KDMS 2.0 precision compatibility calculator with ten-decimal scores.
4. ✅ Try the full workflow: Donor → Test → Match → Approve → Transplant → Follow-Up.
5. ✅ Check **Audit Log** to see every action automatically tracked.
6. ✅ Log in as `donor_rakib` or `recipient_kalam` to see the role-limited self-service views.
7. ✅ Visit **Reports** (as admin) for monthly analytics and city/country breakdowns.

**Welcome to KDMS Pro — now a global hybrid kidney donation network.** 🌍
