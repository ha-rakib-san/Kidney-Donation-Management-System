-- ╔══════════════════════════════════════════════════════════════════════╗
-- ║  KDMS PRO — 01_schema.sql                                           ║
-- ║  Kidney Donation Management System — SQLite 3.35+ Schema             ║
-- ║  Global Hybrid Edition — 60+ Hospitals · 30+ Countries · UTF-8        ║
-- ╚══════════════════════════════════════════════════════════════════════╝
--
-- This schema targets SQLite (PDO sqlite driver), not MySQL.
-- It is run once by install.php against a fresh database file at
-- storage/kdms.sqlite.
--
-- Notes on the MySQL → SQLite conversion:
--   • AUTO_INCREMENT          -> INTEGER PRIMARY KEY AUTOINCREMENT
--   • ENUM(...)               -> TEXT NOT NULL CHECK (col IN (...))
--   • TINYINT(1)/BOOLEAN      -> INTEGER (0/1)
--   • JSON                    -> TEXT (read/written via SQLite's built-in
--                                 json1 functions: json_extract, json_object,
--                                 etc. — available in PHP 8.2's bundled
--                                 SQLite3 library by default)
--   • ON UPDATE CURRENT_TIMESTAMP -> emulated with AFTER UPDATE triggers
--     (see 03_triggers.sql, trg_*_touch_updated_at)
--   • FULLTEXT INDEX          -> plain INDEX on the name column + LIKE-based
--     search in lib/Procedures.php::searchDonors(). (An FTS5 external-content
--     virtual-table approach was prototyped but triggered a reproducible
--     "database disk image is malformed" corruption bug when its sync
--     triggers fired from inside a cross-table cascade trigger on some
--     SQLite builds — LIKE search on an indexed column is the safer,
--     fully-portable choice for a localhost/XAMPP deployment.)
--   • Stored procedures       -> moved to lib/Procedures.php (SQLite has no
--     stored-procedure language at all)
--   • Scheduled EVENTs        -> moved to includes/scheduler.php (lazy,
--     runs due jobs on page load) + cron/maintenance.php (real cron entry
--     point for users who want a true OS-level schedule)
--
PRAGMA foreign_keys = ON;

-- ─── ROLES ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS roles (
  role_id     INTEGER PRIMARY KEY AUTOINCREMENT,
  role_name   TEXT NOT NULL UNIQUE
              CHECK (role_name IN ('superadmin','admin','doctor','donor','recipient','auditor')),
  description TEXT,
  permissions TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

-- ─── USERS ───────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  user_id        INTEGER PRIMARY KEY AUTOINCREMENT,
  username       TEXT NOT NULL UNIQUE,
  email          TEXT NOT NULL UNIQUE,
  password_hash  TEXT NOT NULL,
  role_id        INTEGER NOT NULL REFERENCES roles (role_id),
  linked_id      INTEGER DEFAULT NULL,
  linked_type    TEXT DEFAULT NULL CHECK (linked_type IN ('donor','recipient','doctor') OR linked_type IS NULL),
  full_name      TEXT NOT NULL,
  phone          TEXT,
  avatar_url     TEXT,
  is_active      INTEGER NOT NULL DEFAULT 1,
  is_verified    INTEGER NOT NULL DEFAULT 0,
  last_login_at  TEXT NULL,
  failed_logins  INTEGER NOT NULL DEFAULT 0,
  locked_until   TEXT NULL,
  remember_token TEXT NULL,
  created_at     TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at     TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_users_role   ON users (role_id);
CREATE INDEX IF NOT EXISTS idx_users_active ON users (is_active);
CREATE INDEX IF NOT EXISTS idx_users_email  ON users (email);

-- ─── USER SESSIONS ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_sessions (
  session_id    TEXT PRIMARY KEY,
  user_id       INTEGER NOT NULL REFERENCES users (user_id) ON DELETE CASCADE,
  ip_address    TEXT,
  user_agent    TEXT,
  last_activity TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  created_at    TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON user_sessions (user_id);

-- ─── PASSWORD RESETS ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS password_resets (
  reset_id   INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users (user_id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  used_at    TEXT NULL,
  created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);

-- ─── HOSPITALS (now global — country + city, free text) ─────────────────────
CREATE TABLE IF NOT EXISTS hospitals (
  hospital_id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name                 TEXT NOT NULL,
  short_code           TEXT NOT NULL UNIQUE,
  country              TEXT NOT NULL,
  city                 TEXT NOT NULL,
  address              TEXT,
  contact_phone        TEXT,
  contact_email        TEXT,
  license_no           TEXT,
  bed_count            INTEGER,
  transplant_certified INTEGER NOT NULL DEFAULT 0,
  lat                  REAL,
  lng                  REAL,
  is_active            INTEGER NOT NULL DEFAULT 1,
  created_at           TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at           TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_hospitals_country ON hospitals (country);
CREATE INDEX IF NOT EXISTS idx_hospitals_city    ON hospitals (city);


-- ─── DOCTORS ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS doctors (
  doctor_id        INTEGER PRIMARY KEY AUTOINCREMENT,
  name             TEXT NOT NULL,
  specialization   TEXT NOT NULL
                    CHECK (specialization IN ('Nephrology','Transplant Surgery','Urology',
                                               'Immunology','Anesthesiology','Pathology','Other')),
  bmdc_reg_no      TEXT UNIQUE,
  phone            TEXT,
  email            TEXT,
  hospital_id      INTEGER DEFAULT NULL REFERENCES hospitals (hospital_id) ON DELETE SET NULL,
  years_exp        INTEGER,
  transplants_done INTEGER NOT NULL DEFAULT 0,
  bio              TEXT,
  is_active        INTEGER NOT NULL DEFAULT 1,
  created_at       TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at       TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_doctors_hospital ON doctors (hospital_id);
CREATE INDEX IF NOT EXISTS idx_doctors_spec     ON doctors (specialization);


-- ─── DONORS (now global — country + city) ────────────────────────────────────
CREATE TABLE IF NOT EXISTS donors (
  donor_id          INTEGER PRIMARY KEY AUTOINCREMENT,
  nid               TEXT UNIQUE,
  name              TEXT NOT NULL,
  dob               TEXT,
  gender            TEXT NOT NULL CHECK (gender IN ('Male','Female','Other')),
  blood_group       TEXT NOT NULL CHECK (blood_group IN ('A+','A-','B+','B-','O+','O-','AB+','AB-')),
  country           TEXT NOT NULL,
  city              TEXT NOT NULL,
  address           TEXT,
  contact           TEXT,
  email             TEXT,
  emergency_contact TEXT,
  donor_type        TEXT NOT NULL DEFAULT 'Living' CHECK (donor_type IN ('Living','Deceased')),
  status            TEXT NOT NULL DEFAULT 'Available'
                     CHECK (status IN ('Available','Unavailable','Transplanted','Suspended')),
  hospital_id       INTEGER DEFAULT NULL REFERENCES hospitals (hospital_id) ON DELETE SET NULL,
  registered_by     INTEGER DEFAULT NULL REFERENCES users (user_id) ON DELETE SET NULL,
  consent_signed    INTEGER NOT NULL DEFAULT 0,
  consent_date      TEXT,
  medical_history   TEXT,
  notes             TEXT,
  risk_score        INTEGER NOT NULL DEFAULT 0,
  is_anonymous      INTEGER NOT NULL DEFAULT 0,
  created_at        TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at        TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_donors_blood   ON donors (blood_group);
CREATE INDEX IF NOT EXISTS idx_donors_country ON donors (country);
CREATE INDEX IF NOT EXISTS idx_donors_city    ON donors (city);
CREATE INDEX IF NOT EXISTS idx_donors_status  ON donors (status);
CREATE INDEX IF NOT EXISTS idx_donors_type    ON donors (donor_type);


-- ─── RECIPIENTS (now global — country + city) ────────────────────────────────
CREATE TABLE IF NOT EXISTS recipients (
  recipient_id      INTEGER PRIMARY KEY AUTOINCREMENT,
  nid               TEXT UNIQUE,
  name              TEXT NOT NULL,
  dob               TEXT,
  gender            TEXT NOT NULL CHECK (gender IN ('Male','Female','Other')),
  blood_group       TEXT NOT NULL CHECK (blood_group IN ('A+','A-','B+','B-','O+','O-','AB+','AB-')),
  country           TEXT NOT NULL,
  city              TEXT NOT NULL,
  address           TEXT,
  contact           TEXT,
  email             TEXT,
  emergency_contact TEXT,
  urgency_level     TEXT NOT NULL DEFAULT 'Medium' CHECK (urgency_level IN ('Low','Medium','High','Critical')),
  wait_status       TEXT NOT NULL DEFAULT 'Waiting' CHECK (wait_status IN ('Waiting','Matched','Transplanted','Withdrawn')),
  wait_since        TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  hospital_id       INTEGER DEFAULT NULL REFERENCES hospitals (hospital_id) ON DELETE SET NULL,
  registered_by     INTEGER DEFAULT NULL REFERENCES users (user_id) ON DELETE SET NULL,
  diagnosis         TEXT,
  dialysis_start    TEXT,
  gfr_level         REAL,
  medical_history   TEXT,
  insurance_info    TEXT,
  notes             TEXT,
  created_at        TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at        TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_recipients_blood   ON recipients (blood_group);
CREATE INDEX IF NOT EXISTS idx_recipients_country ON recipients (country);
CREATE INDEX IF NOT EXISTS idx_recipients_urgency ON recipients (urgency_level);
CREATE INDEX IF NOT EXISTS idx_recipients_status  ON recipients (wait_status);


-- ─── MEDICAL TESTS ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS medical_tests (
  test_id          INTEGER PRIMARY KEY AUTOINCREMENT,
  person_id        INTEGER NOT NULL,
  person_type      TEXT NOT NULL CHECK (person_type IN ('Donor','Recipient')),
  doctor_id        INTEGER DEFAULT NULL REFERENCES doctors (doctor_id) ON DELETE SET NULL,
  blood_test       TEXT,
  kidney_function  TEXT,
  gfr_numeric      NUMERIC,
  tissue_type_hla  TEXT,
  crossmatch       TEXT NOT NULL DEFAULT 'Pending' CHECK (crossmatch IN ('Positive','Negative','Pending')),
  infection_screen TEXT NOT NULL DEFAULT 'Clear' CHECK (infection_screen IN ('Clear','Flagged')),
  hepatitis_b      TEXT NOT NULL DEFAULT 'Negative' CHECK (hepatitis_b IN ('Negative','Positive')),
  hepatitis_c      TEXT NOT NULL DEFAULT 'Negative' CHECK (hepatitis_c IN ('Negative','Positive')),
  hiv              TEXT NOT NULL DEFAULT 'Negative' CHECK (hiv IN ('Negative','Positive')),
  creatinine_level NUMERIC,
  hemoglobin       NUMERIC,
  height_cm        NUMERIC CHECK (height_cm IS NULL OR (height_cm BETWEEN 100 AND 250)),
  weight_kg        NUMERIC CHECK (weight_kg IS NULL OR (weight_kg BETWEEN 20 AND 300)),
  bmi              NUMERIC CHECK (bmi IS NULL OR (bmi BETWEEN 8 AND 80)),
  systolic_bp      NUMERIC CHECK (systolic_bp IS NULL OR (systolic_bp BETWEEN 50 AND 300)),
  diastolic_bp     NUMERIC CHECK (diastolic_bp IS NULL OR (diastolic_bp BETWEEN 30 AND 200)),
  diabetes         INTEGER DEFAULT NULL CHECK (diabetes IS NULL OR diabetes IN (0,1)),
  hypertension     INTEGER DEFAULT NULL CHECK (hypertension IS NULL OR hypertension IN (0,1)),
  pra_percentage   NUMERIC CHECK (pra_percentage IS NULL OR (pra_percentage BETWEEN 0 AND 100)),
  test_date        TEXT NOT NULL DEFAULT (DATE('now')),
  result_notes     TEXT,
  lab_reference    TEXT,
  is_valid         INTEGER NOT NULL DEFAULT 1,
  verified_by      INTEGER DEFAULT NULL REFERENCES users (user_id) ON DELETE SET NULL,
  created_at       TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_tests_person ON medical_tests (person_id, person_type);
CREATE INDEX IF NOT EXISTS idx_tests_doctor ON medical_tests (doctor_id);
CREATE INDEX IF NOT EXISTS idx_tests_date   ON medical_tests (test_date);
CREATE INDEX IF NOT EXISTS idx_tests_cross  ON medical_tests (crossmatch);

-- ─── COMPATIBILITY MATCHES ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS compatibility_matches (
  match_id              INTEGER PRIMARY KEY AUTOINCREMENT,
  donor_id              INTEGER NOT NULL REFERENCES donors (donor_id) ON DELETE CASCADE,
  recipient_id          INTEGER NOT NULL REFERENCES recipients (recipient_id) ON DELETE CASCADE,
  match_score           NUMERIC NOT NULL DEFAULT 0 CHECK (match_score BETWEEN 0 AND 100),
  blood_score           NUMERIC NOT NULL DEFAULT 0,
  location_score        NUMERIC NOT NULL DEFAULT 0,
  crossmatch_score      NUMERIC NOT NULL DEFAULT 0,
  hla_score             NUMERIC NOT NULL DEFAULT 0,
  medical_score         NUMERIC NOT NULL DEFAULT 0,
  age_score             NUMERIC NOT NULL DEFAULT 0,
  bmi_score             NUMERIC NOT NULL DEFAULT 0,
  creatinine_score      NUMERIC NOT NULL DEFAULT 0,
  gfr_score             NUMERIC NOT NULL DEFAULT 0,
  blood_pressure_score  NUMERIC NOT NULL DEFAULT 0,
  hemoglobin_score      NUMERIC NOT NULL DEFAULT 0,
  diabetes_score        NUMERIC NOT NULL DEFAULT 0,
  hypertension_score    NUMERIC NOT NULL DEFAULT 0,
  pra_score             NUMERIC NOT NULL DEFAULT 0,
  distance_km           NUMERIC,
  age_difference_years  NUMERIC,
  data_completeness     NUMERIC NOT NULL DEFAULT 0,
  is_eligible           INTEGER NOT NULL DEFAULT 0 CHECK (is_eligible IN (0,1)),
  score_version         TEXT NOT NULL DEFAULT 'KDMS-2.0',
  score_detail_json     TEXT,
  tissue_hla_donor      TEXT,
  tissue_hla_recipient  TEXT,
  crossmatch_result     TEXT NOT NULL DEFAULT 'Pending' CHECK (crossmatch_result IN ('Positive','Negative','Pending')),
  review_result         TEXT NOT NULL DEFAULT 'Pending' CHECK (review_result IN ('Pending','Approved','Rejected')),
  reviewed_by           INTEGER DEFAULT NULL REFERENCES users (user_id) ON DELETE SET NULL,
  reviewed_at           TEXT NULL,
  review_notes          TEXT,
  match_date            TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  is_ai_suggested       INTEGER NOT NULL DEFAULT 0,
  priority_rank         INTEGER,
  UNIQUE (donor_id, recipient_id)
);
CREATE INDEX IF NOT EXISTS idx_match_donor     ON compatibility_matches (donor_id);
CREATE INDEX IF NOT EXISTS idx_match_recipient ON compatibility_matches (recipient_id);
CREATE INDEX IF NOT EXISTS idx_match_score     ON compatibility_matches (match_score);
CREATE INDEX IF NOT EXISTS idx_match_review    ON compatibility_matches (review_result);

-- ─── TRANSPLANTS (cost is now currency-agnostic: amount + ISO code) ──────────
CREATE TABLE IF NOT EXISTS transplants (
  transplant_id         INTEGER PRIMARY KEY AUTOINCREMENT,
  match_id              INTEGER NOT NULL UNIQUE REFERENCES compatibility_matches (match_id) ON DELETE RESTRICT,
  doctor_id             INTEGER NOT NULL REFERENCES doctors (doctor_id),
  assisting_doctor_id   INTEGER DEFAULT NULL REFERENCES doctors (doctor_id) ON DELETE SET NULL,
  hospital_id           INTEGER DEFAULT NULL REFERENCES hospitals (hospital_id) ON DELETE SET NULL,
  surgery_date          TEXT NOT NULL,
  surgery_start_time    TEXT,
  surgery_duration_min  INTEGER,
  result                TEXT NOT NULL DEFAULT 'Ongoing' CHECK (result IN ('Ongoing','Successful','Failed','Cancelled')),
  cold_ischemia_time    INTEGER,
  warm_ischemia_time    INTEGER,
  immunosuppression     TEXT,
  complications         TEXT,
  notes                 TEXT,
  cost_amount           REAL,
  currency              TEXT NOT NULL DEFAULT 'USD',
  insurance_covered     INTEGER NOT NULL DEFAULT 0,
  created_at            TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  updated_at            TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_tx_match    ON transplants (match_id);
CREATE INDEX IF NOT EXISTS idx_tx_doctor   ON transplants (doctor_id);
CREATE INDEX IF NOT EXISTS idx_tx_hospital ON transplants (hospital_id);
CREATE INDEX IF NOT EXISTS idx_tx_date     ON transplants (surgery_date);
CREATE INDEX IF NOT EXISTS idx_tx_result   ON transplants (result);

-- ─── FOLLOW-UPS ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS follow_ups (
  followup_id        INTEGER PRIMARY KEY AUTOINCREMENT,
  transplant_id      INTEGER NOT NULL REFERENCES transplants (transplant_id) ON DELETE CASCADE,
  doctor_id          INTEGER DEFAULT NULL REFERENCES doctors (doctor_id) ON DELETE SET NULL,
  person_type        TEXT NOT NULL DEFAULT 'Recipient' CHECK (person_type IN ('Donor','Recipient')),
  checkup_date       TEXT NOT NULL,
  health_status      TEXT NOT NULL CHECK (health_status IN ('Stable','Critical','Recovering','Discharged','Deceased')),
  creatinine_level   REAL,
  gfr_numeric        REAL,
  blood_pressure     TEXT,
  rejection_episode  INTEGER NOT NULL DEFAULT 0,
  rejection_grade    TEXT NOT NULL DEFAULT 'None'
                      CHECK (rejection_grade IN ('None','Borderline','IA','IB','IIA','IIB','III')),
  medication_notes   TEXT,
  notes              TEXT,
  next_checkup_date  TEXT,
  followup_month     INTEGER,
  created_at         TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_followup_tx     ON follow_ups (transplant_id);
CREATE INDEX IF NOT EXISTS idx_followup_date   ON follow_ups (checkup_date);
CREATE INDEX IF NOT EXISTS idx_followup_status ON follow_ups (health_status);

-- ─── NOTIFICATIONS ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notifications (
  notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id         INTEGER NOT NULL REFERENCES users (user_id) ON DELETE CASCADE,
  title           TEXT NOT NULL,
  message         TEXT NOT NULL,
  type            TEXT NOT NULL DEFAULT 'info'
                   CHECK (type IN ('info','success','warning','urgent','match','transplant')),
  link_url        TEXT,
  is_read         INTEGER NOT NULL DEFAULT 0,
  created_at      TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP),
  read_at         TEXT NULL
);
CREATE INDEX IF NOT EXISTS idx_notif_user_unread ON notifications (user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_notif_created     ON notifications (created_at);

-- ─── AUDIT LOG ────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS audit_log (
  log_id      INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER DEFAULT NULL REFERENCES users (user_id) ON DELETE SET NULL,
  action      TEXT NOT NULL CHECK (action IN ('CREATE','READ','UPDATE','DELETE','LOGIN','LOGOUT',
                                                'APPROVE','REJECT','EXPORT','SYSTEM')),
  table_name  TEXT,
  record_id   INTEGER,
  old_values  TEXT,
  new_values  TEXT,
  ip_address  TEXT,
  user_agent  TEXT,
  notes       TEXT,
  created_at  TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_audit_user    ON audit_log (user_id);
CREATE INDEX IF NOT EXISTS idx_audit_table   ON audit_log (table_name, record_id);
CREATE INDEX IF NOT EXISTS idx_audit_action  ON audit_log (action);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log (created_at);

-- ─── WAITLIST QUEUE ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS waitlist_queue (
  queue_id           INTEGER PRIMARY KEY AUTOINCREMENT,
  recipient_id       INTEGER NOT NULL UNIQUE REFERENCES recipients (recipient_id) ON DELETE CASCADE,
  queue_position     INTEGER NOT NULL,
  priority_score     REAL NOT NULL DEFAULT 0,
  urgency_weight     REAL NOT NULL DEFAULT 1,
  wait_since_date    TEXT NOT NULL DEFAULT (DATE('now')),
  last_recalculated  TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
CREATE INDEX IF NOT EXISTS idx_queue_pos      ON waitlist_queue (queue_position);
CREATE INDEX IF NOT EXISTS idx_queue_priority ON waitlist_queue (priority_score);

-- ─── SYSTEM SETTINGS ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS system_settings (
  setting_key   TEXT PRIMARY KEY,
  setting_value TEXT,
  setting_type  TEXT NOT NULL DEFAULT 'string' CHECK (setting_type IN ('string','integer','boolean','json')),
  description   TEXT,
  updated_by    INTEGER DEFAULT NULL REFERENCES users (user_id) ON DELETE SET NULL,
  updated_at    TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP)
);
