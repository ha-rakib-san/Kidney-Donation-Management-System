-- ╔══════════════════════════════════════════════════════════════════════╗
-- ║  KDMS PRO — 04_views.sql                                            ║
-- ║  Database Views — SQLite 3.35+                                       ║
-- ╚══════════════════════════════════════════════════════════════════════╝
--
-- Conversion notes vs. the original MySQL views:
--   • CREATE OR REPLACE VIEW -> DROP VIEW IF EXISTS + CREATE VIEW
--   • DATEDIFF(CURDATE(), x)  -> CAST(julianday('now') - julianday(x) AS INTEGER)
--   • DATE_SUB(CURDATE(), INTERVAL N DAY) -> DATE('now', '-N days')
--   • CONCAT(a,b)             -> a || b
--   • YEAR(x)/MONTH(x)        -> strftime('%Y', x) / strftime('%m', x)
--   • LPAD(mo,2,'0')          -> not needed; strftime('%m',x) is already 2-digit
--   • cost_bdt                -> cost_amount + currency (international edition)
--   • city only               -> city + country (international edition)

-- ─── 1. v_approved_matches ────────────────────────────────────────────────────
DROP VIEW IF EXISTS v_approved_matches;
CREATE VIEW v_approved_matches AS
SELECT
  cm.match_id,
  cm.match_score,
  cm.blood_score,
  cm.location_score,
  cm.crossmatch_score,
  cm.hla_score,
  cm.medical_score,
  cm.age_score,
  cm.bmi_score,
  cm.creatinine_score,
  cm.gfr_score,
  cm.blood_pressure_score,
  cm.hemoglobin_score,
  cm.diabetes_score,
  cm.hypertension_score,
  cm.pra_score,
  cm.distance_km,
  cm.age_difference_years,
  cm.data_completeness,
  cm.is_eligible,
  cm.score_version,
  cm.match_date,
  cm.reviewed_at,
  cm.review_notes,
  cm.is_ai_suggested,
  d.donor_id,
  d.name          AS donor_name,
  d.blood_group   AS donor_blood,
  d.city          AS donor_city,
  d.country       AS donor_country,
  d.donor_type,
  d.gender        AS donor_gender,
  r.recipient_id,
  r.name          AS recipient_name,
  r.blood_group   AS recipient_blood,
  r.city          AS recipient_city,
  r.country       AS recipient_country,
  r.urgency_level,
  h.name          AS hospital_name
FROM compatibility_matches cm
JOIN donors     d ON cm.donor_id     = d.donor_id
JOIN recipients r ON cm.recipient_id = r.recipient_id
LEFT JOIN hospitals h ON d.hospital_id = h.hospital_id
WHERE cm.review_result = 'Approved'
ORDER BY cm.match_score DESC;

-- ─── 2. v_waitlist_ranked ──────────────────────────────────────────────────────
DROP VIEW IF EXISTS v_waitlist_ranked;
CREATE VIEW v_waitlist_ranked AS
SELECT
  wq.queue_id,
  wq.queue_position,
  wq.priority_score,
  wq.urgency_weight,
  wq.wait_since_date,
  CAST(julianday('now') - julianday(wq.wait_since_date) AS INTEGER) AS wait_days,
  r.recipient_id,
  r.name,
  r.blood_group,
  r.country,
  r.city,
  r.urgency_level,
  r.gfr_level,
  r.diagnosis,
  h.name AS hospital_name
FROM waitlist_queue wq
JOIN recipients r ON wq.recipient_id = r.recipient_id
LEFT JOIN hospitals h ON r.hospital_id = h.hospital_id
ORDER BY wq.queue_position ASC;

-- ─── 3. v_donor_profiles ─────────────────────────────────────────────────────
DROP VIEW IF EXISTS v_donor_profiles;
CREATE VIEW v_donor_profiles AS
SELECT
  d.donor_id,
  d.name,
  d.gender,
  d.blood_group,
  d.country,
  d.city,
  d.status,
  d.donor_type,
  d.contact,
  d.email,
  d.consent_signed,
  d.risk_score,
  d.created_at,
  h.name           AS hospital_name,
  h.country        AS hospital_country,
  h.city           AS hospital_city,
  mt.tissue_type_hla,
  mt.crossmatch    AS latest_crossmatch,
  mt.gfr_numeric   AS latest_gfr,
  mt.creatinine_level AS latest_creatinine,
  mt.hemoglobin AS latest_hemoglobin,
  mt.bmi AS latest_bmi,
  mt.systolic_bp AS latest_systolic_bp,
  mt.diastolic_bp AS latest_diastolic_bp,
  mt.diabetes AS latest_diabetes,
  mt.hypertension AS latest_hypertension,
  mt.pra_percentage AS latest_pra_percentage,
  mt.infection_screen,
  mt.test_date     AS latest_test_date,
  (SELECT COUNT(*) FROM compatibility_matches cm WHERE cm.donor_id = d.donor_id) AS match_count,
  (SELECT COUNT(*) FROM compatibility_matches cm
   WHERE cm.donor_id = d.donor_id AND cm.review_result = 'Approved') AS approved_matches
FROM donors d
LEFT JOIN hospitals h ON d.hospital_id = h.hospital_id
LEFT JOIN (
  SELECT mt1.*
  FROM medical_tests mt1
  INNER JOIN (
    SELECT person_id, MAX(test_id) AS max_id
    FROM medical_tests WHERE person_type = 'Donor' AND is_valid = 1
    GROUP BY person_id
  ) mt2 ON mt1.test_id = mt2.max_id
) mt ON d.donor_id = mt.person_id;

-- ─── 4. v_recipient_profiles ─────────────────────────────────────────────────
DROP VIEW IF EXISTS v_recipient_profiles;
CREATE VIEW v_recipient_profiles AS
SELECT
  r.recipient_id,
  r.name,
  r.gender,
  r.blood_group,
  r.country,
  r.city,
  r.urgency_level,
  r.wait_status,
  r.wait_since,
  r.gfr_level,
  r.diagnosis,
  r.contact,
  r.email,
  r.created_at,
  CAST(julianday('now') - julianday(r.wait_since) AS INTEGER) AS days_waiting,
  h.name           AS hospital_name,
  h.country        AS hospital_country,
  wq.queue_position,
  wq.priority_score,
  mt.tissue_type_hla,
  mt.crossmatch    AS latest_crossmatch,
  mt.gfr_numeric AS latest_gfr,
  mt.creatinine_level AS latest_creatinine,
  mt.hemoglobin AS latest_hemoglobin,
  mt.bmi AS latest_bmi,
  mt.systolic_bp AS latest_systolic_bp,
  mt.diastolic_bp AS latest_diastolic_bp,
  mt.diabetes AS latest_diabetes,
  mt.hypertension AS latest_hypertension,
  mt.pra_percentage AS latest_pra_percentage,
  mt.test_date     AS latest_test_date,
  (SELECT COUNT(*) FROM compatibility_matches cm WHERE cm.recipient_id = r.recipient_id) AS match_count
FROM recipients r
LEFT JOIN hospitals    h  ON r.hospital_id   = h.hospital_id
LEFT JOIN waitlist_queue wq ON r.recipient_id = wq.recipient_id
LEFT JOIN (
  SELECT mt1.*
  FROM medical_tests mt1
  INNER JOIN (
    SELECT person_id, MAX(test_id) AS max_id
    FROM medical_tests WHERE person_type = 'Recipient' AND is_valid = 1
    GROUP BY person_id
  ) mt2 ON mt1.test_id = mt2.max_id
) mt ON r.recipient_id = mt.person_id;

-- ─── 5. v_transplant_summary ─────────────────────────────────────────────────
DROP VIEW IF EXISTS v_transplant_summary;
CREATE VIEW v_transplant_summary AS
SELECT
  t.transplant_id,
  t.surgery_date,
  t.surgery_duration_min,
  t.result,
  t.cost_amount,
  t.currency,
  t.cold_ischemia_time,
  t.warm_ischemia_time,
  t.notes,
  t.created_at,
  cm.match_id,
  cm.match_score,
  d.donor_id,
  d.name          AS donor_name,
  d.blood_group   AS donor_blood,
  d.country       AS donor_country,
  r.recipient_id,
  r.name          AS recipient_name,
  r.blood_group   AS recipient_blood,
  r.country       AS recipient_country,
  r.urgency_level,
  doc.doctor_id,
  doc.name        AS doctor_name,
  doc.specialization,
  h.name          AS hospital_name,
  h.country       AS hospital_country,
  h.city          AS hospital_city,
  (SELECT COUNT(*) FROM follow_ups fu WHERE fu.transplant_id = t.transplant_id) AS followup_count
FROM transplants t
JOIN compatibility_matches cm ON t.match_id      = cm.match_id
JOIN donors                d  ON cm.donor_id     = d.donor_id
JOIN recipients            r  ON cm.recipient_id = r.recipient_id
JOIN doctors               doc ON t.doctor_id    = doc.doctor_id
LEFT JOIN hospitals        h  ON t.hospital_id   = h.hospital_id;

-- ─── 6. v_doctor_workload ────────────────────────────────────────────────────
DROP VIEW IF EXISTS v_doctor_workload;
CREATE VIEW v_doctor_workload AS
SELECT
  doc.doctor_id,
  doc.name,
  doc.specialization,
  doc.transplants_done,
  doc.years_exp,
  h.name AS hospital_name,
  h.country,
  h.city,
  (SELECT COUNT(*) FROM transplants t
   WHERE t.doctor_id = doc.doctor_id AND t.result = 'Ongoing')  AS active_transplants,
  (SELECT COUNT(*) FROM follow_ups fu
   JOIN transplants t ON fu.transplant_id = t.transplant_id
   WHERE t.doctor_id = doc.doctor_id
     AND fu.checkup_date >= DATE('now', '-30 days')) AS recent_followups,
  (SELECT COUNT(*) FROM transplants t
   WHERE t.doctor_id = doc.doctor_id AND t.result = 'Successful') AS successful_transplants,
  ROUND(
    (SELECT COUNT(*) FROM transplants t WHERE t.doctor_id = doc.doctor_id AND t.result = 'Successful')
    * 100.0
    / NULLIF((SELECT COUNT(*) FROM transplants t
              WHERE t.doctor_id = doc.doctor_id AND t.result IN ('Successful','Failed')), 0),
    1
  ) AS success_rate_pct
FROM doctors doc
LEFT JOIN hospitals h ON doc.hospital_id = h.hospital_id
WHERE doc.is_active = 1;

-- ─── 7. v_hospital_stats ─────────────────────────────────────────────────────
DROP VIEW IF EXISTS v_hospital_stats;
CREATE VIEW v_hospital_stats AS
SELECT
  h.hospital_id,
  h.name,
  h.country,
  h.city,
  h.bed_count,
  h.transplant_certified,
  h.contact_phone,
  (SELECT COUNT(*) FROM donors     d WHERE d.hospital_id = h.hospital_id)              AS total_donors,
  (SELECT COUNT(*) FROM donors     d WHERE d.hospital_id = h.hospital_id AND d.status = 'Available') AS available_donors,
  (SELECT COUNT(*) FROM recipients r WHERE r.hospital_id = h.hospital_id)              AS total_recipients,
  (SELECT COUNT(*) FROM recipients r WHERE r.hospital_id = h.hospital_id AND r.wait_status = 'Waiting') AS waiting_recipients,
  (SELECT COUNT(*) FROM transplants t WHERE t.hospital_id = h.hospital_id)             AS total_transplants,
  (SELECT COUNT(*) FROM transplants t WHERE t.hospital_id = h.hospital_id AND t.result = 'Successful') AS successful_transplants,
  (SELECT COUNT(*) FROM doctors    d WHERE d.hospital_id = h.hospital_id AND d.is_active = 1)          AS doctor_count
FROM hospitals h
WHERE h.is_active = 1;

-- ─── 8. v_monthly_trends ─────────────────────────────────────────────────────
DROP VIEW IF EXISTS v_monthly_trends;
CREATE VIEW v_monthly_trends AS
SELECT
  yr, mo,
  yr || '-' || mo AS month_label,
  SUM(new_donors)      AS new_donors,
  SUM(new_recipients)  AS new_recipients,
  SUM(new_matches)     AS new_matches,
  SUM(new_transplants) AS new_transplants,
  SUM(successful_tx)   AS successful_transplants
FROM (
  SELECT strftime('%Y', created_at) AS yr, strftime('%m', created_at) AS mo,
         COUNT(*) AS new_donors, 0 AS new_recipients, 0 AS new_matches,
         0 AS new_transplants, 0 AS successful_tx
  FROM donors GROUP BY yr, mo

  UNION ALL
  SELECT strftime('%Y', created_at), strftime('%m', created_at),
         0, COUNT(*), 0, 0, 0
  FROM recipients GROUP BY 1, 2

  UNION ALL
  SELECT strftime('%Y', match_date), strftime('%m', match_date),
         0, 0, COUNT(*), 0, 0
  FROM compatibility_matches GROUP BY 1, 2

  UNION ALL
  SELECT strftime('%Y', surgery_date), strftime('%m', surgery_date),
         0, 0, 0, COUNT(*),
         SUM(CASE WHEN result = 'Successful' THEN 1 ELSE 0 END)
  FROM transplants GROUP BY 1, 2
) sub
GROUP BY yr, mo
ORDER BY yr DESC, mo DESC;

-- ─── 9. v_critical_cases ─────────────────────────────────────────────────────
DROP VIEW IF EXISTS v_critical_cases;
CREATE VIEW v_critical_cases AS
SELECT
  'recipient' AS case_type,
  r.recipient_id AS entity_id,
  r.name,
  r.blood_group,
  r.country,
  r.city,
  r.urgency_level AS severity,
  r.wait_status   AS current_status,
  CAST(julianday('now') - julianday(r.wait_since) AS INTEGER) AS days_in_status,
  h.name AS hospital_name
FROM recipients r
LEFT JOIN hospitals h ON r.hospital_id = h.hospital_id
WHERE r.urgency_level = 'Critical' AND r.wait_status = 'Waiting'

UNION ALL

SELECT
  'followup' AS case_type,
  fu.followup_id AS entity_id,
  'TX#' || fu.transplant_id || ' Follow-Up' AS name,
  '' AS blood_group,
  '' AS country,
  '' AS city,
  'Critical' AS severity,
  fu.health_status AS current_status,
  CAST(julianday('now') - julianday(fu.checkup_date) AS INTEGER) AS days_in_status,
  '' AS hospital_name
FROM follow_ups fu
WHERE fu.health_status = 'Critical'
  AND fu.checkup_date >= DATE('now', '-7 days')

ORDER BY days_in_status DESC;

-- ─── 10. v_compatibility_matrix ──────────────────────────────────────────────
DROP VIEW IF EXISTS v_compatibility_matrix;
CREATE VIEW v_compatibility_matrix AS
SELECT
  cm.match_id,
  cm.match_score,
  cm.blood_score,
  cm.location_score,
  cm.crossmatch_score,
  cm.hla_score,
  cm.medical_score,
  cm.age_score,
  cm.bmi_score,
  cm.creatinine_score,
  cm.gfr_score,
  cm.blood_pressure_score,
  cm.hemoglobin_score,
  cm.diabetes_score,
  cm.hypertension_score,
  cm.pra_score,
  cm.distance_km,
  cm.age_difference_years,
  cm.data_completeness,
  cm.is_eligible,
  cm.score_version,
  cm.review_result,
  cm.match_date,
  d.name AS donor_name, d.blood_group AS donor_blood, d.country AS donor_country, d.city AS donor_city,
  r.name AS recipient_name, r.blood_group AS recipient_blood, r.country AS recipient_country, r.city AS recipient_city,
  r.urgency_level
FROM compatibility_matches cm
JOIN donors     d ON cm.donor_id     = d.donor_id
JOIN recipients r ON cm.recipient_id = r.recipient_id
ORDER BY cm.match_score DESC;
