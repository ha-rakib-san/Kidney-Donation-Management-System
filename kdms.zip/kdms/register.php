<?php
/**
 * KDMS Pro — register.php
 * Self-registration page (Donor / Recipient roles only)
 */
declare(strict_types=1);
define('KDMS_ROOT', __DIR__);
require_once KDMS_ROOT . '/includes/auth.php';
require_once KDMS_ROOT . '/includes/constants.php';

if (is_logged_in()) { redirect('/pages/dashboard.php'); }

$errors = [];
$blood_groups = KDMS_BLOOD_GROUPS;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();

    $role_choice = trim($_POST['role_choice'] ?? 'donor'); // donor or recipient
    $username    = trim($_POST['username'] ?? '');
    $email       = trim($_POST['email'] ?? '');
    $password    = $_POST['password'] ?? '';
    $confirm     = $_POST['confirm_password'] ?? '';
    $full_name   = trim($_POST['full_name'] ?? '');
    $phone       = trim($_POST['phone'] ?? '');
    $blood       = trim($_POST['blood_group'] ?? '');
    $country     = trim($_POST['country'] ?? '');
    $city        = trim($_POST['city'] ?? '');
    $gender      = trim($_POST['gender'] ?? '');
    $dob         = trim($_POST['dob'] ?? '');

    if (!in_array($role_choice, ['donor','recipient'])) $errors[] = 'Invalid role selection.';
    if (strlen($username) < 4) $errors[] = 'Username must be at least 4 characters.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (strlen($password) < 8) $errors[] = 'Password must be at least 8 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';
    if (!$full_name) $errors[] = 'Full name is required.';
    if (!$blood || !in_array($blood, $blood_groups)) $errors[] = 'Valid blood group is required.';
    if (!$country) $errors[] = 'Country is required.';
    if (!$city)    $errors[] = 'City is required.';
    if (!$gender) $errors[] = 'Gender is required.';

    if (!$errors) {
        $existing = Database::fetchOne("SELECT user_id FROM users WHERE username=? OR email=?", [$username, $email]);
        if ($existing) $errors[] = 'Username or email already registered.';
    }

    if (!$errors) {
        try {
            Database::beginTransaction();

            // Create the donor or recipient record first
            if ($role_choice === 'donor') {
                $linked_id = Database::execute(
                    "INSERT INTO donors (name,dob,gender,blood_group,country,city,contact,email,donor_type,status)
                     VALUES (?,?,?,?,?,?,?,?,'Living','Available')",
                    [$full_name, $dob ?: null, $gender, $blood, $country, $city, $phone, $email]
                );
                $role_id = 4; // donor role
            } else {
                $linked_id = Database::execute(
                    "INSERT INTO recipients (name,dob,gender,blood_group,country,city,contact,email,urgency_level,wait_status)
                     VALUES (?,?,?,?,?,?,?,?,'Medium','Waiting')",
                    [$full_name, $dob ?: null, $gender, $blood, $country, $city, $phone, $email]
                );
                $role_id = 5; // recipient role
                // Add to waitlist
                Database::execute(
                    "INSERT INTO waitlist_queue (recipient_id,queue_position,priority_score,wait_since_date) VALUES (?,9999,40.00,DATE('now'))",
                    [(int)$linked_id]
                );
            }

            $user_id = Database::execute(
                "INSERT INTO users (username,email,password_hash,role_id,linked_id,linked_type,full_name,phone,is_active,is_verified)
                 VALUES (?,?,?,?,?,?,?,?,1,0)",
                [$username, $email, password_hash($password, PASSWORD_BCRYPT), $role_id, $linked_id, $role_choice, $full_name, $phone]
            );

            Database::commit();
            log_action('CREATE','users',(int)$user_id,null,['username'=>$username,'role'=>$role_choice],'Self-registration');
            flash('success', 'Registration successful! You can now log in.');
            redirect('/login.php');
        } catch (PDOException $e) {
            Database::rollback();
            $errors[] = 'Registration failed: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register — KDMS Pro</title>
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;700&family=Inter:wght@300;400;500;600&family=JetBrains+Mono&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="<?= base_url('/assets/css/main.css') ?>">
<link rel="stylesheet" href="<?= base_url('/assets/css/animations.css') ?>">
<script src="<?= base_url('/assets/js/app.js') ?>" defer></script>
</head>
<body style="display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;">
<div class="glass-card no-hover anim-fade-up" style="max-width:600px;width:100%;padding:40px;position:relative;">
    <div class="login-card-border"></div>
    <div class="login-logo">
        <h1>Create <span style="color:var(--accent-cyan);">Account</span></h1>
        <p>Register as a donor or recipient</p>
    </div>

    <?php if ($errors): ?>
    <div class="flash-message flash-danger" style="position:relative;top:0;right:0;margin-bottom:20px;" role="alert">
        <span class="flash-icon"><i class="fa-solid fa-circle-xmark"></i></span>
        <div><?php foreach ($errors as $e): ?><div class="flash-text"><?= e($e) ?></div><?php endforeach; ?></div>
    </div>
    <?php endif; ?>

    <form method="POST" class="kdms-form" novalidate>
        <?= csrf_field() ?>
        <div class="form-group mb-3">
            <label>I am registering as a <span class="req">*</span></label>
            <div class="toggle-btn-group">
                <button type="button" class="toggle-btn active-neg" id="roleDonor" onclick="setRole('donor')"><i class="fa-solid fa-heart-pulse"></i> Donor</button>
                <button type="button" class="toggle-btn" id="roleRecipient" onclick="setRole('recipient')"><i class="fa-solid fa-bed-pulse"></i> Recipient</button>
            </div>
            <input type="hidden" name="role_choice" id="roleChoiceInput" value="donor">
        </div>
        <div class="form-grid form-grid-2">
            <div class="form-group"><label>Full Name <span class="req">*</span></label><input type="text" name="full_name" value="<?= e($_POST['full_name'] ?? '') ?>" required></div>
            <div class="form-group"><label>Username <span class="req">*</span></label><input type="text" name="username" value="<?= e($_POST['username'] ?? '') ?>" required minlength="4"></div>
            <div class="form-group"><label>Email <span class="req">*</span></label><input type="email" name="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
            <div class="form-group"><label>Phone</label><input type="tel" name="phone" value="<?= e($_POST['phone'] ?? '') ?>"></div>
            <div class="form-group"><label>Date of Birth</label><input type="date" name="dob" value="<?= e($_POST['dob'] ?? '') ?>"></div>
            <div class="form-group"><label>Gender <span class="req">*</span></label><select name="gender" required><option value="">Select…</option><?php foreach(['Male','Female','Other'] as $g): ?><option value="<?=$g?>"><?=$g?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>Blood Group <span class="req">*</span></label><select name="blood_group" required><option value="">Select…</option><?php foreach($blood_groups as $bg): ?><option value="<?=$bg?>"><?=$bg?></option><?php endforeach; ?></select></div>
            <div class="form-group"><label>Country <span class="req">*</span></label><?= kdms_country_select('country', $_POST['country'] ?? null, 'onchange="kdmsCityCascade(\'country\',\'city\')"') ?></div>
            <div class="form-group"><label>City <span class="req">*</span></label><?= kdms_city_select('city', $_POST['country'] ?? null, $_POST['city'] ?? null) ?></div>
            <div class="form-group"><label>Password <span class="req">*</span></label><input type="password" name="password" minlength="8" required></div>
            <div class="form-group"><label>Confirm Password <span class="req">*</span></label><input type="password" name="confirm_password" minlength="8" required></div>
        </div>
        <button type="submit" class="btn btn-primary login-submit mt-3"><i class="fa-solid fa-user-plus"></i> Create Account</button>
    </form>
    <p style="text-align:center;margin-top:16px;font-size:.85rem;color:var(--text-secondary);">
        Already have an account? <a href="<?= base_url('/login.php') ?>">Sign in</a>
    </p>
</div>
<script>
window.KDMS_CITIES_BY_COUNTRY = <?= kdms_cities_json() ?>;
function setRole(role) {
    document.getElementById('roleChoiceInput').value = role;
    document.getElementById('roleDonor').classList.toggle('active-neg', role==='donor');
    document.getElementById('roleRecipient').classList.toggle('active-neg', role==='recipient');
}
</script>
</body>
</html>
