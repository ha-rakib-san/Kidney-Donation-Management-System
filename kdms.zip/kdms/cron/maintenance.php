<?php
/**
 * KDMS Pro — cron/maintenance.php
 *
 * Real OS-level cron entry point, for deployments that want the four
 * scheduled jobs to run on an exact schedule instead of the lazy page-load
 * trigger in includes/scheduler.php (which still works fine without this).
 *
 * Usage:
 *   php cron/maintenance.php daily      -> Procedures::prioritizeWaitlist()
 *   php cron/maintenance.php weekly     -> AI match suggestions for Critical recipients
 *   php cron/maintenance.php monthly    -> notification/password-reset cleanup
 *   php cron/maintenance.php hourly     -> cache dashboard stats snapshot
 *   php cron/maintenance.php all        -> run all four, ignoring their normal intervals
 *
 * Example crontab (Linux/macOS):
 *   0  3  *  *  *   php /path/to/htdocs/kdms/cron/maintenance.php daily
 *   0  4  *  *  0   php /path/to/htdocs/kdms/cron/maintenance.php weekly
 *   0  5  1  *  *   php /path/to/htdocs/kdms/cron/maintenance.php monthly
 *   0  *  *  *  *   php /path/to/htdocs/kdms/cron/maintenance.php hourly
 *
 * Windows Task Scheduler: run as a Basic Task —
 *   php.exe C:\xampp\htdocs\kdms\cron\maintenance.php daily
 */
declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    die("This script is intended for CLI / cron use only.\n");
}

define('KDMS_ROOT', dirname(__DIR__));
require_once KDMS_ROOT . '/config/database.php';
require_once KDMS_ROOT . '/lib/Procedures.php';

$job = $argv[1] ?? null;
$valid = ['daily', 'weekly', 'monthly', 'hourly', 'all'];

if (!$job || !in_array($job, $valid, true)) {
    echo "Usage: php cron/maintenance.php [" . implode('|', $valid) . "]\n";
    exit(1);
}

function run_daily(): void
{
    $n = Procedures::prioritizeWaitlist();
    echo "[daily] Reprioritized waitlist: {$n} recipients re-ranked.\n";
}

function run_weekly(): void
{
    $critical = Database::fetchAll("SELECT recipient_id, name FROM recipients WHERE urgency_level='Critical' AND wait_status='Waiting'");
    $total = 0;
    foreach ($critical as $r) {
        $created = Procedures::autoMatchDonorsForRecipient((int) $r['recipient_id'], 60);
        $total += count($created);
        echo "[weekly] {$r['name']}: " . count($created) . " AI-suggested match(es) created.\n";
    }
    echo "[weekly] Done. {$total} total matches created across " . count($critical) . " critical recipients.\n";
}

function run_monthly(): void
{
    $n1 = Database::execute("DELETE FROM notifications WHERE is_read=1 AND created_at < DATE('now','-90 days')");
    $n2 = Database::execute("DELETE FROM password_resets WHERE expires_at < CURRENT_TIMESTAMP");
    echo "[monthly] Cleaned up old notifications and expired password resets.\n";
}

function run_hourly(): void
{
    $stats = Procedures::getDashboardStats();
    echo "[hourly] Dashboard stats cached: " . json_encode($stats) . "\n";
}

match ($job) {
    'daily'   => run_daily(),
    'weekly'  => run_weekly(),
    'monthly' => run_monthly(),
    'hourly'  => run_hourly(),
    'all'     => [run_daily(), run_weekly(), run_monthly(), run_hourly()],
};

echo "Done.\n";
