# KDMS 2.0 Precision Compatibility Model

## Purpose

KDMS calculates a reproducible 0 to 100 compatibility score for educational clinical decision support. It does not diagnose patients, approve donors, or replace a transplant multidisciplinary team.

All numeric inputs and calculated score fields are rounded to 10 decimal places. Missing values are never assumed to be normal. A match cannot be approved until all required precision medical fields and HLA values are present.

## Total score

| Component | Maximum |
|---|---:|
| ABO compatibility | 15.0000000000 |
| Geographic distance | 20.0000000000 |
| Crossmatch | 20.0000000000 |
| HLA similarity | 15.0000000000 |
| Medical profile | 30.0000000000 |
| Total | 100.0000000000 |

## Medical profile, 30 points

| Factor | Maximum | Main interpretation |
|---|---:|---|
| Donor age and donor-recipient age difference | 3 | Continuous donor-age suitability and age-gap decay |
| Donor and recipient BMI | 3 | Continuous interpolation around healthier ranges |
| Creatinine | 4 | Donor creatinine suitability plus recipient creatinine and GFR consistency |
| GFR | 5 | Donor renal function receives the dominant weight. Recipient severity contributes one point |
| Blood pressure | 3 | Uses both systolic and diastolic values continuously |
| Hemoglobin | 3 | Uses sex-aware reference intervals and continuous interpolation |
| Diabetes | 2 | Donor risk receives the dominant weight |
| Hypertension | 2 | Donor risk receives the dominant weight |
| Recipient PRA/cPRA | 5 | Continuous sensitization penalty from 0 to 100 percent |

The exact continuous anchors and interpolation code are in `lib/Procedures.php`. Values between anchors are linearly interpolated, so the model does not jump in broad 5 percent intervals.

## Distance score

Distance uses the Haversine formula between the donor hospital and recipient hospital coordinates.

| Distance | Score |
|---:|---:|
| 0 to 20 km | 20 |
| 50 km | 15 |
| 100 km | 10 |
| 250 km | 5 |
| 500 km | 2 |
| 1,000 km or more | 0 |

Distances between anchor points receive an interpolated score. When coordinates are unavailable, the legacy city and country fallback remains so the existing workflow does not break.

## Eligibility rules

A score may be calculated for review, but approval is blocked when any of these conditions applies:

- ABO incompatible
- Either latest crossmatch result is positive
- Crossmatch is not verified negative on both donor and recipient records
- Donor GFR is below 60 mL/min/1.73 m²
- Donor infection screening, HIV, hepatitis B, or hepatitis C is flagged positive
- Required medical measurements are missing
- Donor or recipient HLA values are missing

## Recalculation

Compatibility scores automatically recalculate after:

- Adding, editing, or deleting a medical test
- Editing donor or recipient birth date, blood group, city, country, or hospital
- Editing hospital coordinates
- Opening a match review
- Installing or migrating the database

## Database fields

`medical_tests` now includes:

- `height_cm`
- `weight_kg`
- `bmi`
- `systolic_bp`
- `diastolic_bp`
- `diabetes`
- `hypertension`
- `pra_percentage`

`compatibility_matches` now persists the total, all five main components, all nine medical components, distance, age difference, completeness, eligibility, formula version, and JSON calculation details.

## Reference basis

The model's guardrails and input interpretation were informed by established transplant and laboratory guidance, including KDIGO living kidney donor guidance, NHS Blood and Transplant compatibility information, OPTN/HRSA cPRA information, NIDDK kidney-function information, and MedlinePlus hemoglobin references.

This project contains a deterministic educational model. It is not clinically validated against an outcome dataset and must not be described as a medical device or a true prediction of transplant success.
